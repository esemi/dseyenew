<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель игроков одного мира
 */ 
class Players extends Model
{

     /*
      * считываем данные по игрокам конкретного мира (не удалённые) 
      * (данные для идентификации + данные для отслеживания изменений)
      */
     protected function setItems()
     {
          $sql = "SELECT `id` , `id_rase` , `id_alliance` , `nik`, `ring`, `compl`, `sota`, `gate`
                 FROM `{$this->table}`
                 WHERE `status` != 'delete'
                 AND `id_world` = {$this->options['idW']}";
          foreach ($this->db->Query($sql) as $row)
          {
               $this->addValue($row);
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Считано из БД ".count($this->values)." игроков<br>";
          }

     }

     /*
      * добавляем значение игрока в список
      */
     protected function addValue($row)
     {
          $this->values[$row['nik']] = array(
                    'id' => $row['id'],
                    'id_alliance' => $row['id_alliance'],
                    'id_rase' => $row['id_rase'],
                    'ring' => $row['ring'],
                    'compl' => $row['compl'],
                    'sota' => $row['sota'],
                    'gate' => $row['gate']);
     }

     /*
      * добавляем игроков в базу и обновляем список
      */
     public function addItems($data)
     {
          $sql =  "INSERT INTO `{$this->table}`
                            (`id_world`, `id_rase`, `id_alliance`,
                             `nik`, `mesto`, `ring`, `compl`, `sota`, `gate`,
                             `level`, `liga`, `archeology`, `building`, `science`,
                             `dom_name`, `rank`, `bo`, `status`, `date_birth`)
                            VALUES ";
          $flag = 0;
          foreach($data as $key => $value)
          {
               $flag++;
               $sql .= "( '{$this->options['idW']}', '{$value['id_rase']}', '{$value['id_all']}',
               '{$value['nik']}', '{$value['mesto']}', '{$value['ring']}', '{$value['compl']}', '{$value['sota']}', '{$value['gate']}',
               '{$value['level']}', '{$value['liga']}', '{$value['archeology']}', '{$value['building']}', '{$value['science']}', 
               '{$value['dom_name']}','{$value['rank']}',
               '{$value['bo']}', 'active', '".TIME_START."') ,";

               if (config::${APPLICATION_ENV}['logMode'] == 'debug')
               {
                    echo "Игрок {$value['nik']} добавлен в базу<br>";
               }
          }
          
          if ($flag != 0)
          {
               $this->db->exec( substr($sql, 0, -1) );
               echo "$flag новых игроков добавлено<br>";
               $this->resetItems();
          }else{
               echo 'Новых игроков ненайдено<b>ХОЛОСТОЙ ХОД</b><br>';
          }
          
     }

     /*
      * обновляем параметры игроков в базe 
      */
     public function updateParams($data)
     {
         /*`level` = ?,`liga` = ?,`archeology` = ?,`building` = ?, `science` = ?,*/
          $res = $this->db->prepare("UPDATE {$this->table} SET
                                `delta_rank` = ? - CAST( rank AS SIGNED ),
                                `delta_bo` = ROUND( ? - bo ),
                                `id_alliance` = ?,    
                                `id_rase` = ?,                                
                                `mesto` = ?,
                                `ring` = ?,
                                `compl` = ?,
                                `sota` = ?,
                                `dom_name` = ?,
                                `gate` = ?,
                                `rank` = ?,
                                `bo` = ?,
                                `status` = 'active',
                                `date_upd` = " . TIME_START . "
                            WHERE id = ?");
          foreach ($data as $value)
          {
               $res->Execute(array(
                       $value['rank'],
                       $value['bo'],
                       $value['id_all'],
                       $value['id_rase'],
                       $value['mesto'],
                       $value['ring'],
                       $value['compl'],
                       $value['sota'],
                       $value['dom_name'],
                       $value['gate'],
                       $value['rank'],
                       $value['bo'],
                       $value['id']));
          }
         
          echo 'Параметры живых игроков актуализированны в БД<br>';
          //$this->resetItems();
     }

     /*
      * отмечаем не обновлённых игроков как удалённых
      */
     public function checkDeletedPlayers()
     {
          $sql = "UPDATE `{$this->table}`
                 SET `status` = 'delete', `date_delete` = '".TIME_START."'
                 WHERE `date_upd` != '".TIME_START."'  AND
                       `status` = 'active'  AND 
                       `date_delete` is NULL AND
                       `id_world` = {$this->options['idW']}";
                       
          $count = $this->db->exec($sql);
          echo $count.' игроков было помечено удалёнными<br>';
          return $count;
     }


     /*
      * обновление дельт игроков одного мира
      *
     public static function updateDelta( $idW )
     {
         if( is_null(self::$_db) ) self::$_db = DB::getInstance();

         //получаем данные
         $sql = "SELECT st.id_player, 
                    (CAST(pl.rank AS SIGNED) - CAST(st.rank AS SIGNED) ) AS del_rank,
                    ROUND(pl.bo - st.bo ) AS del_bo,
                    (CAST(pl.archeology AS SIGNED) - CAST(st.archeology AS SIGNED) ) AS del_arch,
                    (CAST(pl.building AS SIGNED) - CAST(st.building AS SIGNED) ) AS del_build,
                    (CAST(pl.science AS SIGNED) - CAST(st.science AS SIGNED) ) AS del_scien
                 FROM players pl, stat_players st
                 WHERE pl.id_world = {$idW} AND pl.status = 'active' AND st.id = (
                    SELECT MAX( id )
                    FROM stat_players
                    WHERE id_player = pl.id )";

         $res = self::$_db->prepare("UPDATE `players` SET
                                `delta_rank` = ?,
                                `delta_bo` = ?,
                                `delta_arch` = ?,
                                `delta_build` = ?,
                                `delta_scien` = ?
                            WHERE id = ? LIMIT 1");

          $count = 0;
          foreach (self::$_db->Query($sql) as $row)
          {
              $count++;
              //echo "{$row['del_rank']} {$row['del_bo']} {$row['del_arch']} {$row['del_build']} {$row['del_scien']} {$row['id_player']}<br/>";
              $res->Execute(array(
                  $row['del_rank'],
                  $row['del_bo'],
                  $row['del_arch'],
                  $row['del_build'],
                  $row['del_scien'],
                  $row['id_player']));
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Дельты {$count} игроков обновлены<br>";
          }
     }
/**/

     /*
      * обновление дельт игроков одного мира
      */
    /* public static function updateDelta2( $idW )
     {
         if( is_null(self::$_db) ) self::$_db = DB::getInstance();

         //получаем данные
         $sql = "SELECT st.id_player,
             (CAST( pl.rank AS SIGNED ) - CAST( st.rank AS SIGNED )) AS del_rank,
             ROUND( pl.bo - st.bo ) AS del_bo,
             (CAST( pl.archeology AS SIGNED ) - CAST( st.archeology AS SIGNED )) AS del_arch,
             (CAST( pl.building AS SIGNED ) - CAST( st.building AS SIGNED )) AS del_build,
             (CAST( pl.science AS SIGNED ) - CAST( st.science AS SIGNED )) AS del_scien
             FROM players pl, tmp_stat_players st
             WHERE pl.id_world = {$idW}
             AND pl.status = 'active'
             AND st.id_player = pl.id";

         $res = self::$_db->prepare("UPDATE `players` SET
                                `delta_rank` = ?,
                                `delta_bo` = ?,
                                `delta_arch` = ?,
                                `delta_build` = ?,
                                `delta_scien` = ?
                            WHERE id = ? LIMIT 1");

         $count = 0;
         foreach (self::$_db->Query($sql) as $row)
         {
             $count++;
             //echo "{$row['del_rank']} {$row['del_bo']} {$row['del_arch']} {$row['del_build']} {$row['del_scien']} {$row['id_player']}<br/>";
             $res->Execute(array(
                 $row['del_rank'],
                 $row['del_bo'],
                 $row['del_arch'],
                 $row['del_build'],
                 $row['del_scien'],
                 $row['id_player']));
         }
         
         if (config::${APPLICATION_ENV}['logMode'] != 'mini')
         {
             echo "Дельты {$count} игроков обновлены<br>";
         }
     }*/


}

?>
