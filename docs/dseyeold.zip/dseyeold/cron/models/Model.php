<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель 
 */ 
abstract class Model
{
  protected $db;
  protected static $_db = null;
  protected $options;
  protected $table;
  public $values = array();

  
  public function __construct($options = array())
  {
       $this->db = DB::getInstance();
       self::$_db =  $this->db;
       $this->options = $options;
       $this->table = strtolower(get_class($this));
       $this->setItems();
  }
  
  /*
   * сетерим итемы
   */
  abstract protected function setItems();

  /*
   * ресет данных
   */
  public function resetItems()
  {
       $this->values = array();
       echo "Данные по таблице {$this->table} ресетнуты<br>";
       $this->setItems();
  }

  /*
   * отмечаем удалённый итем
   */
  public function checkAsDelete($id)
  {
       $sql = "UPDATE `{$this->table}` 
              SET `status` = 'delete', `date_delete` = '".TIME_START."'
              WHERE `id` = '$id' ";
       $this->db->exec($sql);
  }

  /*
   * отмечаем релевантный итем
   */
  public function checkAsRelevant($id)
  {
       $sql = "UPDATE `{$this->table}`
              SET `date_upd` = '".TIME_START."'
              WHERE `id` = '$id' ";
       $this->db->exec($sql);
  }

  /*
   * отмечаем обновлённый итем
   */
  public function checkAsUpdate($id,$csvHash = null)
  {
       if (is_null($csvHash))
       {
            $sql = "UPDATE `{$this->table}`
                   SET `status` = 'active', `date_upd` = '".TIME_START."'
                   WHERE `id` = '$id' ";
       }else{
            $sql = "UPDATE `{$this->table}`
                   SET `status` = 'active',
                       `date_upd` = '".TIME_START."',
                       `main_csv_hash` = '$csvHash'
                   WHERE `id` = '$id' ";
       }
       $this->db->exec($sql);
  }

  /*
   * чистим таблу
   */
  public function clearTable()
  {
       $sql = "TRUNCATE TABLE `{$this->table}`";
       $this->db->exec($sql);
  }


  

}
?>