<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель миров         
 */ 
class Worlds extends Model
{
     /*
      * считываем данные по всем мирам (удалённые тоже)
      */
     protected function setItems()
     {
          $sql = "SELECT {$this->table}.`id` , {$this->table}.`name` , CONCAT( `main_csv_rep` , `main_csv_url` ) AS url, `main_csv_hash` , `main_csv_parser` , `status` FROM `{$this->table}` LEFT JOIN `game_versions` ON ( id_version = game_versions.id )";
          foreach ($this->db->Query($sql) as $row)
          {
               $this->values[$row['id']] = array(
                    'name' => $row['name'],
                    'url' => $row['url'],
                    'hash_csv' => $row['main_csv_hash'],
                    'type_parser' => $row['main_csv_parser'],
                    'status' => $row['status']);
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Считано из БД ".count($this->values)." миров<br>";
          }
     }

     /*
      * обновляем параметры игроков в базe и обновляем список
      */
     public function updateParams($data)
     {
          $res = $this->db->prepare("UPDATE `{$this->table}` SET
                                `compls_voran` = ?,`compls_liens` = ?,`compls_psol` = ?,`compls_mels` = ?,
                                `count_voran` = ?,`count_liens` = ?,`count_psol` = ?,
                                `rank_voran` = ?,`rank_liens` = ?,`rank_psol` = ?,
                                `bo_voran` = ?,`bo_liens` = ?,`bo_psol` = ?,
                                `nra_voran` = ?,`nra_liens` = ?,`nra_psol` = ?,
                                `ra_voran` = ?,`ra_liens` = ?,`ra_psol` = ?,
                                `count_colony` = ?,`count_alliance` = ?,
                                `avg_level_voran` = ?, `avg_level_liens` = ?, `avg_level_psol` = ?, 
                                `archeology_voran` = ?, `archeology_liens` = ?, `archeology_psol` = ?, 
                                `building_voran` = ?, `building_liens` = ?, `building_psol` = ?, 
                                `science_voran` = ?, `science_liens` = ?, `science_psol` = ?,
                                `status` = 'active',
                                `date_upd` = ".TIME_START."
                            WHERE `id` = ?");

          foreach ($data as $key => $value)
          {
               $res->Execute(
                       array(
                            $value['compls_voran'],$value['compls_liens'],$value['compls_psol'],$value['compls_mels'],
                            $value['count_voran'],$value['count_liens'],$value['count_psol'],
                            $value['rank_voran'],$value['rank_liens'],$value['rank_psol'],
                            $value['bo_voran'],$value['bo_liens'],$value['bo_psol'],
                            $value['nra_voran'],$value['nra_liens'],$value['nra_psol'],
                            $value['ra_voran'],$value['ra_liens'],$value['ra_psol'],
                            $value['count_colony'],$value['count_alliance'],
                            $value['avg_level_voran'],$value['avg_level_liens'],$value['avg_level_psol'],
                            $value['archeology_voran'],$value['archeology_liens'],$value['archeology_psol'],
                            $value['building_voran'],$value['building_liens'],$value['building_psol'],
                            $value['science_voran'],$value['science_liens'],$value['science_psol'],
                            $key)
                       );
               echo "Параметры мира c id = $key актуализированны в БД<br>";
          }

     }




}

?>
