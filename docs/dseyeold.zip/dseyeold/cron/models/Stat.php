<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель всей статистики (выборка и добавление)
 */ 
class Stat
{
     protected static $db = null;

     private static $worldPropColums = array( //колонки свойств миров                    
                     'compls_voran','compls_liens','compls_psol','compls_mels',
                     'count_colony','count_alliance',
                     'count_voran','count_liens','count_psol',
                     'rank_voran','rank_liens','rank_psol',
                     'bo_voran','bo_liens','bo_psol',
                     'nra_voran','nra_liens','nra_psol',
                     'ra_voran','ra_liens','ra_psol',
                     'avg_level_voran','avg_level_liens','avg_level_psol',
                     'archeology_voran','archeology_liens','archeology_psol',
                     'building_voran','building_liens','building_psol',
                     'science_voran','science_liens','science_psol');

     private static $alliancePropColums = array( //колонки свойств альянсов
                     'count_voran','count_liens','count_psol',
                     'rank_voran','rank_liens','rank_psol',
                     'bo_voran','bo_liens','bo_psol',
                     'nra_voran','nra_liens','nra_psol',
                     'ra_voran','ra_liens','ra_psol',
                     'avg_level_voran','avg_level_liens','avg_level_psol',
                     'archeology_voran','archeology_liens','archeology_psol',
                     'building_voran','building_liens','building_psol',
                     'science_voran','science_liens','science_psol');

     private static $generalItemStatColums =  array( //колонки статистики миров/алов
                     'input', 'output',
                     'count_colony','count_alliance',
                     'count_voran','count_liens','count_psol',
                     'rank_voran','rank_liens','rank_psol',
                     'bo_voran','bo_liens','bo_psol',
                     'nra_voran','nra_liens','nra_psol',
                     'ra_voran','ra_liens','ra_psol',
                     'avg_level_voran','avg_level_liens','avg_level_psol',
                     'archeology_voran','archeology_liens','archeology_psol',
                     'building_voran','building_liens','building_psol',
                     'science_voran','science_liens','science_psol');


     /*
      * возвращаем актуальные данные по мирам или миру
      */
     public static function getWorldParams($idW = null)
     {
          $data = array();

          //добавляем основные параметры
          self::addMainParams($data, $idW);

          //добавляем макс комплы на кольцах
          self::addCountCompls($data, $idW);

          //добавляем количество альянсов и колоний
          self::addOtherCount($data, $idW);

          //нулим не заданные значения 
          $cols = self::$worldPropColums;
          foreach($data as $id => $val)
          {
               foreach($cols as $name)
               {
                    if( !isset($val[$name]) || $val[$name] == '' ) $data[$id][$name] = 0;
               }
          }

          return $data;
     }

     /*
      * добавляем основные параметры миров
      * (ССЫЛКА!!)
      */
     private static function addMainParams(&$data, $idW=null)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $whereItem = (is_null($idW)) ? '' : "AND `id_world` = $idW" ;

          $sql = "SELECT `id_world` , `id_rase` ,
                         count( * ) as `count`,
                         SUM( `rank` ) as `rank`,
                         SUM( `bo` ) as `bo`,
                         SUM( `nra` ) as `nra`,
                         SUM( `ra` ) as `ra`,
                         AVG( `level` ) AS `avg_level` , 
                         SUM( `archeology` ) AS `archeology` , 
                         SUM( `building` ) AS `building` , 
                         SUM( `science` ) AS `science`
                 FROM `players`
                 WHERE `status` = 'active' $whereItem
                 GROUP BY `id_world` , `id_rase`
                 ORDER BY NULL";

          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               switch ($row["id_rase"])
               {
                    case 1:
                         $data[$row['id_world']]["count_voran"]=$row["count"];
                         $data[$row['id_world']]["rank_voran"]=$row["rank"];
                         $data[$row['id_world']]["bo_voran"]=$row["bo"];
                         $data[$row['id_world']]["nra_voran"]=$row["nra"];
                         $data[$row['id_world']]["ra_voran"]=$row["ra"];
                         $data[$row['id_world']]["avg_level_voran"]= (int)$row["avg_level"];
                         $data[$row['id_world']]["archeology_voran"]= (int)$row["archeology"];
                         $data[$row['id_world']]["building_voran"]= (int)$row["building"];
                         $data[$row['id_world']]["science_voran"]= (int)$row["science"];
                    break;
                    case 2:
                         $data[$row['id_world']]["count_liens"]=$row["count"];
                         $data[$row['id_world']]["rank_liens"]=$row["rank"];
                         $data[$row['id_world']]["bo_liens"]=$row["bo"];
                         $data[$row['id_world']]["nra_liens"]=$row["nra"];
                         $data[$row['id_world']]["ra_liens"]=$row["ra"];
                         $data[$row['id_world']]["avg_level_liens"]= (int)$row["avg_level"];
                         $data[$row['id_world']]["archeology_liens"]= (int)$row["archeology"];
                         $data[$row['id_world']]["building_liens"]= (int)$row["building"];
                         $data[$row['id_world']]["science_liens"]= (int)$row["science"];
                    break;
                    case 3:
                         $data[$row['id_world']]["count_psol"]=$row["count"];
                         $data[$row['id_world']]["rank_psol"]=$row["rank"];
                         $data[$row['id_world']]["bo_psol"]=$row["bo"];
                         $data[$row['id_world']]["nra_psol"]=$row["nra"];
                         $data[$row['id_world']]["ra_psol"]=$row["ra"];
                         $data[$row['id_world']]["avg_level_psol"]= (int)$row["avg_level"];
                         $data[$row['id_world']]["archeology_psol"]= (int)$row["archeology"];
                         $data[$row['id_world']]["building_psol"]= (int)$row["building"];
                         $data[$row['id_world']]["science_psol"]= (int)$row["science"];
                    break;
               }
          }
     }

     /*
      * добавляем к параметрам миров количество комплексов по кольцам
      * (ССЫЛКА!!)
      */
     private static function addCountCompls(&$data, $idW=null)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $whereItem = (is_null($idW)) ? '' : "AND `id_world` = $idW" ;

          //количество комплексов на кольцах расс
          $sql = "SELECT `id_world` , `id_rase` , MAX( `compl` ) AS `num`
                               FROM `players`
                               WHERE `status` = 'active' $whereItem
                               GROUP BY `id_world` , `id_rase`
                               ORDER BY NULL";
          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               switch ($row["id_rase"])
               {
                    case 1:  $data[$row['id_world']]["compls_voran"]=$row["num"];
                    break;
                    case 2:  $data[$row['id_world']]["compls_liens"]=$row["num"];
                    break;
                    case 3:  $data[$row['id_world']]["compls_psol"] =$row["num"];
                    break;
               }
          }

          //количество комплексов на мельсе
          $sql = "SELECT `id_world`, MAX(`compl`) AS `num`
                 FROM `players_colony`
                 WHERE 1 $whereItem
                 GROUP BY `id_world`
                 ORDER BY NULL" ;
          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $data[$row['id_world']]["compls_mels"]=$row["num"];
          }

     }

     /*
      * добавляем к параметрам миров количество альянсов и колоний
      * (ССЫЛКА!!)
      */
     private static function addOtherCount(&$data, $idW=null)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $whereItem = (is_null($idW)) ? '' : "AND `id_world` = $idW" ;

          //количество колоний
          $sql = "SELECT `id_world` , COUNT( * ) AS `num`
                 FROM `players_colony` 
                 WHERE 1 $whereItem";
          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $data[$row['id_world']]["count_colony"]=$row["num"];               
          }

          //количество альянсов
          $sql = "SELECT `id_world`, COUNT(*) AS num
                 FROM `alliances`
                 WHERE `status` = 'active' $whereItem";
          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $data[$row['id_world']]["count_alliance"]=$row["num"];
          }

     }


     /*
      * возвращаем актуальные данные по живым алам или алу конкретного мира
      */
     public static function getAllianceParams($idW, $idA = null)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $whereItem = (is_null($idA)) ? '' : "AND `id_alliance` = $idA" ;
          $temp = array();

          $sql = "SELECT `id_alliance` , `id_rase` ,
                         count( * ) as `count`,
                         SUM( `rank` ) as `rank`,
                         SUM( `bo` ) as `bo`,
                         SUM( `nra` ) as `nra`,
                         SUM( `ra` ) as `ra`,
                         AVG( `level` ) AS `avg_level` , 
                         SUM( `archeology` ) AS `archeology` , 
                         SUM( `building` ) AS `building` , 
                         SUM( `science` ) AS `science`
                 FROM `players`
                 WHERE `status` = 'active' AND
                       `id_world` = $idW
                       $whereItem
                 GROUP BY `id_alliance` , `id_rase`
                 ORDER BY NULL";

          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               switch ($row["id_rase"])
               {
                    case 1:
                         $temp[$row['id_alliance']]["count_voran"]= (int)$row["count"];
                         $temp[$row['id_alliance']]["rank_voran"]= (int)$row["rank"];
                         $temp[$row['id_alliance']]["bo_voran"]= (int)$row["bo"];
                         $temp[$row['id_alliance']]["nra_voran"]= (int)$row["nra"];
                         $temp[$row['id_alliance']]["ra_voran"]= (int)$row["ra"];
                         $temp[$row['id_alliance']]["avg_level_voran"]= (int)$row["avg_level"];
                         $temp[$row['id_alliance']]["archeology_voran"]= (int)$row["archeology"];
                         $temp[$row['id_alliance']]["building_voran"]= (int)$row["building"];
                         $temp[$row['id_alliance']]["science_voran"]= (int)$row["science"];
                    break;
                    case 2:
                         $temp[$row['id_alliance']]["count_liens"]= (int)$row["count"];
                         $temp[$row['id_alliance']]["rank_liens"]= (int)$row["rank"];
                         $temp[$row['id_alliance']]["bo_liens"]= (int)$row["bo"];
                         $temp[$row['id_alliance']]["nra_liens"]= (int)$row["nra"];
                         $temp[$row['id_alliance']]["ra_liens"]= (int)$row["ra"];
                         $temp[$row['id_alliance']]["avg_level_liens"]= (int)$row["avg_level"];
                         $temp[$row['id_alliance']]["archeology_liens"]= (int)$row["archeology"];
                         $temp[$row['id_alliance']]["building_liens"]= (int)$row["building"];
                         $temp[$row['id_alliance']]["science_liens"]= (int)$row["science"];
                    break;
                    case 3:
                         $temp[$row['id_alliance']]["count_psol"]= (int)$row["count"];
                         $temp[$row['id_alliance']]["rank_psol"]= (int)$row["rank"];
                         $temp[$row['id_alliance']]["bo_psol"]= (int)$row["bo"];
                         $temp[$row['id_alliance']]["nra_psol"]= (int)$row["nra"];
                         $temp[$row['id_alliance']]["ra_psol"]= (int)$row["ra"];
                         $temp[$row['id_alliance']]["avg_level_psol"]= (int)$row["avg_level"];
                         $temp[$row['id_alliance']]["archeology_psol"]= (int)$row["archeology"];
                         $temp[$row['id_alliance']]["building_psol"]= (int)$row["building"];
                         $temp[$row['id_alliance']]["science_psol"]= (int)$row["science"];
                    break;
               }
          }

          //нулим не заданные значения return
          $cols = self::$alliancePropColums;
          foreach($temp as $id => $val)
          {
               foreach($cols as $name)
               {
                    if( !isset($val[$name]) || $val[$name] == '' ) $temp[$id][$name] = 0;
               }
          }

          return $temp;
     }


     /*
      * возвращаем данные по живым игрокам конкретного мира
      * (для статистики игроков)
      */
     public static function getPlayerParams($idW)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $sql = "SELECT `id` , `mesto` , `rank` , `bo` , `nra` , `ra`,  `level`, `liga`, `archeology`, `building`, `science`, `delta_rank`, `delta_bo`
                 FROM `players`
                 WHERE `id_world` = {$idW} AND `status` = 'active' ";

          $data = array();

          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $data[] = $row;
          }

          return $data;
     }

     /*
      * добавляет в БД статистику по игрокам
      */
     public static function saveStatPlayers($idW = null,$data = null)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          if ( is_null($data) && is_null($idW) )
            return false;          

          //данные не переданы - получаем данные сами
          $data = ( is_null($data) ) ? self::getPlayerParams($idW) : $data;

          if (count($data) == 0)
               return false;          

          $sql =  "INSERT INTO `stat_players`
                  (`id_player`, `mesto`, `rank`, `bo`, `nra`, `ra`, `level`, `archeology`, `building`, `science`, `delta_rank`, `delta_bo`, `date_create`)
                  VALUES ";

          foreach($data as $key => $value)
          {
               $sql .= "('{$value['id']}',  '{$value['mesto']}',
                         '{$value['rank']}','{$value['bo']}',
                         '{$value['nra']}',
                         '{$value['ra']}',  '{$value['level']}',  
                         '{$value['archeology']}',  '{$value['building']}',
                         '{$value['science']}', '{$value['delta_rank']}', '{$value['delta_bo']}',
                         NOW()) ,";
          }

          $count = self::$db->exec( substr($sql, 0, -1) );
          echo "Статистика по {$count} игрокам добавлена в БД<br>";
          
          unset($sql);
          return true;
     }

     /*
      * добавляет в БД статистику по мирам и альянсам
      */
     public static function saveStatItems($statWorld,$statAlliance)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $sql =  "INSERT INTO `stat_general`
                  (`type`, `id_item`, `input`, `output`, 
                   `count_voran`, `count_liens`, `count_psol`,
                   `rank_voran`, `rank_liens`, `rank_psol`,
                   `bo_voran`, `bo_liens`, `bo_psol`,
                   `nra_voran`, `nra_liens`, `nra_psol`,
                   `ra_voran`, `ra_liens`, `ra_psol`,
                   `count_colony`, `count_alliance`,
                   `avg_level_voran`, `avg_level_liens`, `avg_level_psol`, 
                   `archeology_voran`, `archeology_liens`, `archeology_psol`, 
                   `building_voran`, `building_liens`, `building_psol`, 
                   `science_voran`, `science_liens`, `science_psol`,
                   `date_create`)
                  VALUES ";

          //добавляем статистику миров
          foreach($statWorld as $key => $value)
          {
               $sql .= "( 'w', '$key', '{$value['input']}', '{$value['output']}',
                         '{$value['count_voran']}', '{$value['count_liens']}', '{$value['count_psol']}',
                         '{$value['rank_voran']}', '{$value['rank_liens']}', '{$value['rank_psol']}',
                         '{$value['bo_voran']}', '{$value['bo_liens']}', '{$value['bo_psol']}',
                         '{$value['nra_voran']}', '{$value['nra_liens']}', '{$value['nra_psol']}',
                         '{$value['ra_voran']}', '{$value['ra_liens']}', '{$value['ra_psol']}',
                         '{$value['count_colony']}', '{$value['count_alliance']}',
                         '{$value['avg_level_voran']}','{$value['avg_level_liens']}','{$value['avg_level_psol']}',
                         '{$value['archeology_voran']}','{$value['archeology_liens']}','{$value['archeology_psol']}',
                         '{$value['building_voran']}','{$value['building_liens']}','{$value['building_psol']}',
                         '{$value['science_voran']}','{$value['science_liens']}','{$value['science_psol']}', 
                         NOW() ) ,";
          }

          //добавляем статистику альянсов
          foreach($statAlliance as $key => $value)
          {
               $sql .= "( 'a', '$key', '{$value['input']}', '{$value['output']}',
                         '{$value['count_voran']}', '{$value['count_liens']}', '{$value['count_psol']}',
                         '{$value['rank_voran']}', '{$value['rank_liens']}', '{$value['rank_psol']}',
                         '{$value['bo_voran']}', '{$value['bo_liens']}', '{$value['bo_psol']}',
                         '{$value['nra_voran']}', '{$value['nra_liens']}', '{$value['nra_psol']}',
                         '{$value['ra_voran']}', '{$value['ra_liens']}', '{$value['ra_psol']}',
                         '{$value['count_colony']}', '{$value['count_alliance']}',
                         '{$value['avg_level_voran']}','{$value['avg_level_liens']}','{$value['avg_level_psol']}',
                         '{$value['archeology_voran']}','{$value['archeology_liens']}','{$value['archeology_psol']}',
                         '{$value['building_voran']}','{$value['building_liens']}','{$value['building_psol']}',
                         '{$value['science_voran']}','{$value['science_liens']}','{$value['science_psol']}', 
                         NOW() ) ,";
          }

          $count = self::$db->exec( substr($sql, 0, -1) );
          echo "Статистика по $count итемам добавлена в БД<br>";

          return true;
     }

     

     /*
      * возвращаем статистику по мирам
      * @var type = 'w' || 'a'
      */
     public static function getItemStat($type = 'w')
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();


          if( !in_array($type,array('w','a')) )
          {
               return FALSE;
          }
          
          $data = array();

          //собираем статистику по мирам
          if( $type == 'w' )
          {
               //добавляем параметры из текущих данных
               self::addMainWorldsStat($data);

               //добавляем пришло-ушло по датам рождения-удаления игроков
               self::addInOutWorldsStat($data);

          //собираем статистику по альянсам
          }elseif( $type == 'a' ){
               //добавляем параметры из текущих данных
               self::addMainAlliancesStat($data);

               //добавляем пришло-ушло по датам рождения-удаления игроков
               //self::addInOutAlliancesStat($data);

          }
          
          $cols = self::$generalItemStatColums;
          
          //нулим не заданные значения
          foreach($data as $id => $val)
               foreach($cols as $name)
                    if( !isset($val[$name]) || $val[$name] == '' ) $data[$id][$name] = 0;
       
          return $data;
     }

     /*
      * добавляем основные статы миров
      */
     private static function addMainWorldsStat(&$data)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();
          
          $sql = "SELECT `id` , `count_voran` , `count_liens` , `count_psol` ,
                        `rank_voran` , `rank_liens` , `rank_psol` ,
                        `bo_voran` , `bo_liens` , `bo_psol` ,
                        `nra_voran` , `nra_liens` , `nra_psol` ,
                        `ra_voran` , `ra_liens` , `ra_psol` ,
                        `count_colony` , `count_alliance`, 
                        `avg_level_voran`, `avg_level_liens`, `avg_level_psol`, 
                        `archeology_voran`, `archeology_liens`, `archeology_psol`, 
                        `building_voran`, `building_liens`, `building_psol`, 
                        `science_voran`, `science_liens`, `science_psol`,
                        `date_create`
                 FROM `worlds`
                 WHERE `status` = 'active'
                 ORDER BY NULL";

          $result = self::$db->Query($sql);

          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $id = $row['id'];
               unset($row['id']);
               $data[$id] = $row;
          }

     }

     /*
      * добавляем основные статы альянсов
      */
     private static function addMainAlliancesStat(&$data)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $sql = "SELECT `id` , `count_voran` , `count_liens` , `count_psol` ,
                        `rank_voran` , `rank_liens` , `rank_psol` ,
                        `bo_voran` , `bo_liens` , `bo_psol` ,
                        `nra_voran` , `nra_liens` , `nra_psol` ,
                        `ra_voran` , `ra_liens` , `ra_psol`,
                        `avg_level_voran`, `avg_level_liens`, `avg_level_psol`, 
                        `archeology_voran`, `archeology_liens`, `archeology_psol`, 
                        `building_voran`, `building_liens`, `building_psol`, 
                        `science_voran`, `science_liens`, `science_psol`
                 FROM `alliances`
                 WHERE `status` = 'active'
                 ORDER BY NULL";

          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
               $id = $row['id'];
               unset($row['id']);
               $data[$id] = $row;
          }

     }

     /*
      * добавляем пришло-ушло в статы миров
      */
     private static function addInOutWorldsStat(&$data)
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          //определяем границы timestamp для текущих суток
          list($begin,$end) = self::getTimeBorders();
          //var_dump(date('Y-m-d H:i:s',$begin),date('Y-m-d H:i:s',$end));         // die;

          //пришедшие игроки
          $sql = "SELECT `id_world`,count(*) AS input
                 FROM `players`
                 WHERE status = 'active' AND
                       `date_birth` >=  {$begin}  AND
                       `date_birth` < {$end}
                 GROUP BY `id_world`
                 ORDER BY NULL";
//echo $sql; die;
          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
              //проверяем не сегодня ли добавлен мир (чтоб свечки в статистике не ловить)
               if( isset($data[$row['id_world']]) )
                        $data[$row['id_world']]['input'] = 
                                 ($data[$row['id_world']]['date_create'] < $begin) ?  $row['input'] : 0;
               
          }

          //ушедшие игроки
          $sql = "SELECT `id_world`,count(*) AS output
                 FROM `players`
                 WHERE status = 'delete' AND
                       date_delete IS NOT NULL AND
                       `date_delete` >=  $begin  AND
                       `date_delete` < $end
                 GROUP BY `id_world`
                 ORDER BY NULL";

          $result = self::$db->Query($sql);
          while ($row = $result->fetch(DB::FETCH_ASSOC))
          {
                if( isset($data[$row['id_world']]) )
                       $data[$row['id_world']]['output'] = $row['output'];
          }

     }

         
     /*
      * удалить старые записи статистики итемов (по периоду в конфигах)
      */
     public static function clearOldItemsStat()
     {
          if( is_null(self::$db) ) self::$db = DB::getInstance();

          $time = TIME_START - config::${APPLICATION_ENV}['trashItems']*24*60*60;

          $sql = "DELETE FROM `stat_general` WHERE `date_create` < {$time}";
          $count = self::$db->exec($sql);

          echo "{$count} записей статистики по итемам удалено из БД<br>";
     }

     /*
      * возвращает границы текущих суток
      */
     private static function getTimeBorders()
     {
          $begin = strtotime(date('Y-m-d 00:00:00'));
          $end = strtotime('+1 day',$begin);
          return array($begin, $end);
     }

     /*
      * обновлнеие макс дельт рейтинга за текущие сутки
      */
     public static function updMaxRankDelts($idW)
     {
         if( is_null(self::$db) ) self::$db = DB::getInstance();

         //удаляем старые дельты
         $sql = "DELETE FROM `players_max_rank_delta` WHERE `date` >= CURDATE() AND id_world = {$idW}";
         $count = self::$db->exec($sql);

         echo "{$count} записей максимальных дельт рейтинга удалено из БД<br>";

         //настройки
         $border = config::${APPLICATION_ENV}['deltaRankBorder'];
         $limit = config::${APPLICATION_ENV}['deltaRankLimit'];

         //добавляем новые записи
         $sql = "INSERT INTO players_max_rank_delta
                    SELECT NULL AS id, `id_world` , `id_player`, stat_players.delta_rank AS `delta`, `date_create`
                    FROM `stat_players`
                    LEFT JOIN players ON ( players.id = stat_players.id_player )
                    WHERE id_world = {$idW}
                    AND date_create >= CURDATE( )
                    AND ABS( stat_players.delta_rank ) >= {$border}
                    ORDER BY ABS( stat_players.delta_rank ) DESC
                    LIMIT {$limit}";

          $count = self::$db->exec($sql);
          echo "{$count} записей максимальных дельт рейтинга добавлено в БД<br>";
     }



     /*
      * обновлнеие макс дельт БО за текущие сутки
      */
     public static function updMaxBoDelts($idW)
     {
         if( is_null(self::$db) ) self::$db = DB::getInstance();

         //удаляем старые дельты
         $sql = "DELETE FROM `players_max_bo_delta` WHERE `date` >= CURDATE() AND id_world = {$idW}";
         $count = self::$db->exec($sql);

         echo "{$count} записей максимальных дельт БО удалено из БД<br>";

         //настройки
         $border = config::${APPLICATION_ENV}['deltaBoBorder'];
         $limit = config::${APPLICATION_ENV}['deltaBoLimit'];

         //добавляем новые записи
         $sql = "INSERT INTO players_max_bo_delta
                    SELECT NULL AS id, `id_world` , `id_player`, ROUND(stat_players.delta_bo) AS delta, `date_create`
                    FROM `stat_players`
                    LEFT JOIN players ON ( players.id = stat_players.id_player )
                    WHERE id_world = {$idW}
                    AND date_create >= CURDATE( )
                    AND stat_players.delta_bo >= {$border}
                    ORDER BY stat_players.delta_bo DESC
                    LIMIT {$limit}";
                    
          $count = self::$db->exec($sql);
          echo "{$count} записей максимальных дельт БО добавлено в БД<br>";
     }



}

?>
