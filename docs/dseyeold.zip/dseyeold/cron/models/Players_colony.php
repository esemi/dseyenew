<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель колоний игроков всех миров
 */ 
class Players_colony extends Model
{
     public $actualColony = array();

     /*
      * считываем данные по колониям
      */
     protected function setItems()
     {
          $sql = "SELECT `id_player`, `compl`, `sota`, `col_name`
                 FROM `{$this->table}`
                 WHERE `id_world` = {$this->options['idW']}";
          $count = 0;
          foreach ($this->db->Query($sql) as $row)
          {
               $this->values[$row['id_player']][] = array(
                    'compl' => $row['compl'],
                    'sota' => $row['sota'],
                    'col_name' => $row['col_name']);
               $count++;
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Считано из БД ".count($this->values)." игроков - колонизаторов и {$count} колоний<br>";
          }
     }

     /*
      * добавляем колонии игроков в актуальный список
      */
     public function addItems($data)
     {
          $flag = 0;
          foreach($data as $idP => $value)
          {
               $count = count($value['adr']);
               for($i=0;$i<$count;$i++)
               {
                    $flag++;
                    $adr = explode('.', $value['adr'][$i]);
                    $this->actualColony[$idP][] = array(
                          'compl' => $adr[1],
                          'sota' => $adr[2],
                          'col_name' => $value['name'][$i]);
               }
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Добавлено в актуальный список $flag колоний<br>";
          }
     }

     /*
      * чистка старых данных и вставка новых
      */
     public function updateParams($mode = null)
     {
          if(count($this->actualColony) <= 0) return false;
          $mode = (is_null($mode))? '' : 'DELAYED';

          $this->clearTable();

          $sql =  "INSERT $mode INTO `{$this->table}`
                  (`id_world`, `id_player`, `compl`,`sota`,`col_name`)
                  VALUES ";
          foreach($this->actualColony as $key => $cols)
          {
               foreach ($cols as $value)
               {
                    $sql .= "({$this->options['idW']}, '$key', '{$value['compl']}', '{$value['sota']}', '{$value['col_name']}') ,";
               }
          }
          $count = $this->db->exec( substr($sql, 0, -1) );
          echo "$count новых колоний добавлено<br>";
     }

     public function clearTable()
     {
          $sql = "DELETE FROM `{$this->table}`
                 WHERE `id_world` = {$this->options['idW']}";
          $count = $this->db->exec($sql);
          echo $count.' старых колоний удалено<br>';
     }

     
}

?>