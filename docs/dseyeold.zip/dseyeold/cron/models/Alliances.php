<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель альянсов одного мира
 */
class Alliances extends Model
{
     /*
      * считываем все альянсы одного мира (удалённые тоже)
      * (+добавляем альянс нейтралов, если таковой не задан)
      */
     protected function setItems()
     {
          $sql = "SELECT `id`, `name` 
                 FROM `{$this->table}`
                 WHERE `id_world` = {$this->options['idW']}";
          
          foreach ($this->db->Query($sql) as $row)
          {
               $this->values[$row['name']] = $row['id'];
          }

          //добавляем ал нейтралов
          if (!isset($this->values[config::${APPLICATION_ENV}['nameNeutrals']]))
          {
               $this->addItems( config::${APPLICATION_ENV}['nameNeutrals']);
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Считано из БД ".count($this->values)." альянсов<br>";
          }
     }

     /*
      * добавляем альянс
      * (можно добавлять сразу несколько - передавать массив имён)
      */
     public function addItems($name)
     {
          if (is_array($name))
          {
               foreach($name as $key => $value)
               {
                    $this->addItems($value);
               }
          }elseif( !isset($this->values[$name]) ){
               $this->db->exec(
                       "INSERT INTO `{$this->table}`
                       (`id_world`, `name`,`status`, `date_birth`)
                       VALUES
                       ('{$this->options['idW']}', '$name', 'active', '".TIME_START."')");
               $newId = $this->db->lastInsertId();
               $this->values[$name] = $newId;

               if (config::${APPLICATION_ENV}['logMode'] == 'debug')
               {
                    echo "Альянс $name добавлен в базу<br>";
               }
               
               return $newId;
          }else{
               return $this->values[$name];
          }
     }

     /*
      * отмечаем необновлённые альянсы как удалённые
      */
     public function checkDeletedAlliances()
     {
          $sql = "UPDATE `{$this->table}`
                 SET `status` = 'delete', `date_delete` = '".TIME_START."'
                 WHERE `status` = 'active'  AND 
                       `id_world` = {$this->options['idW']} AND
                       `date_upd` != ".TIME_START;
          $count = $this->db->exec($sql);
          echo $count.' альянсов было помечено удалёнными<br>';
          return $count;
     }

     /*
      * обновление параметров живых алов
      */
     public function updateParams($data)
     {
          $res = $this->db->prepare("UPDATE `{$this->table}` SET
                                `count_voran` = ?,`count_liens` = ?,`count_psol` = ?,
                                `rank_voran` = ?,`rank_liens` = ?,`rank_psol` = ?,
                                `bo_voran` = ?,`bo_liens` = ?,`bo_psol` = ?,
                                `nra_voran` = ?,`nra_liens` = ?,`nra_psol` = ?,
                                `ra_voran` = ?,`ra_liens` = ?,`ra_psol` = ?,
                                `avg_level_voran` = ?, `avg_level_liens` = ?, `avg_level_psol` = ?, 
                                `archeology_voran` = ?, `archeology_liens` = ?, `archeology_psol` = ?, 
                                `building_voran` = ?, `building_liens` = ?, `building_psol` = ?, 
                                `science_voran` = ?, `science_liens` = ?, `science_psol` = ?,
                                `status` = 'active',
                                `date_upd` = ".TIME_START."
                            WHERE `id` = ?");

          foreach ($data as $key => $value)
          {
               $res->Execute( 
                       array(
                            $value['count_voran'],$value['count_liens'],$value['count_psol'],
                            $value['rank_voran'],$value['rank_liens'],$value['rank_psol'],
                            $value['bo_voran'],$value['bo_liens'],$value['bo_psol'],
                            $value['nra_voran'],$value['nra_liens'],$value['nra_psol'],
                            $value['ra_voran'],$value['ra_liens'],$value['ra_psol'],
                            $value['avg_level_voran'],$value['avg_level_liens'],$value['avg_level_psol'],
                            $value['archeology_voran'],$value['archeology_liens'],$value['archeology_psol'],
                            $value['building_voran'],$value['building_liens'],$value['building_psol'],
                            $value['science_voran'],$value['science_liens'],$value['science_psol'],
                            $key)
                       );
          }

          echo 'Параметры живых альянсов актуализированны в БД<br>';
     }

}

?>
