<?php
defined('_CHEK') or die('Restricted access');
/*
 * модель рас
 */ 
class Rases extends Model
{
     /*
      * считываем все рассы
      */
     protected function setItems()
     {
          $sql = "SELECT `id`, `name` FROM `{$this->table}`";
          foreach ($this->db->Query($sql) as $row)
          {
               $this->values[$row['name']] = $row['id'];
          }
     }
  
  
}
