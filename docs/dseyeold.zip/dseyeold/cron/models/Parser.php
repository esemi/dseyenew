<?php

defined('_CHEK') or die('Restricted access');

/*
 * Наследник парсеров строчек CSV
 */

abstract class Parser
{
    protected 
        $_err = null,
        $_rases = null,
        $_uniqNiks = array();
    
    final public function __construct($rases)
    {
        $this->_rases = $rases;
    }


    final public static function factory($type, $rases)
    {
        switch($type)
        {
            case 'old_rank':
                return new OldRankParser($rases);
                break;
            case 'new_rank':
                return new NewRankParser($rases);
                break;

            default:
                throw new Exception('Undefined parser type', 100);
                break;
        }

    } 

    final public function isValid($str)
    {        
        $arr = explode(";", $str);
        
        if(count($arr) < 8)
        {
            $this->_err = 'count cols < 8';
            return false;
        }
        
        if( strlen($arr[1]) < 3 )
        {            
            $this->_err = 'short nik';
            return false;
        }
        
        if( !preg_match('/^[\wА-Яа-яёЁ\s.-]{3,50}$/ui',$arr[1]) )
        {
            $this->_err = 'invalid nik';
            return false;            
        }
        
        if( count(explode('.', $arr[3])) < 3 )
        {
            $this->_err = 'invalid adresses';
            return false;            
        }
        
        if( count(explode(',', $arr[2])) !== count(explode(',', $arr[3])) )
        {            
            $this->_err = 'invalid relative "adresses - name"';
            return false;    
        }
        
        if( !in_array(substr($arr[3], 0, 1), $this->_rases) )
        {
            $this->_err = 'invalid ring';
            return false;            
        }
        
        if( !in_array($arr[5], array( "Voraner", "Liensu", "Psolao", "Воранер", "Лиенсу", "Псолао")) )
        {
            $this->_err = 'invalid rase';
            return false;            
        }
        
        if( in_array($arr[1], $this->_uniqNiks) )
        {
            $this->_err = 'not unique nik';
            return false;            
        }else{
            $this->_uniqNiks[] = $arr[1];
        }
        
        return true;
    }
       
    public function getErr()
    {
        return $this->_err;
    }


    abstract public function parse($str);

}
?>