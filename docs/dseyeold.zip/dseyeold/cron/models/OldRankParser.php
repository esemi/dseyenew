<?php

defined('_CHEK') or die('Restricted access');

/*
 * Парсер старых рейтингов
 */

class OldRankParser extends Parser
{

    public function parse($str)
    {
        $result = array(
            'mesto' => null,
            'nik' => null,
            'ring' => null,
            'all' => null,
            'rase' => null,
            'rank' => null,
            'bo' => null,
            'gate' => null,
            'level' => 0,
            'liga' => '',
            'archeology' => 0,
            'building' => 0,
            'science' => 0,
            'compl' => null,
            'sota' => null,
            'dom_name' => null,
            'colonyAdr' => null,
            'colonyName' => null,
            'id_rase' => null,
            'new' => false );

        $arr = explode(";", $str);

        $result['mesto'] = intval($arr[0]);
        $result['nik'] = trim($arr[1]);
        $result['ring'] = substr(trim($arr[3]), 0, 1);
        $result['all'] = trim($arr[4]);

        $fake_rase = array( "Voraner", "Liensu", "Psolao" );
        $true_rase = array( "Воранер", "Лиенсу", "Псолао" );
        $result['rase'] = trim(str_replace($fake_rase, $true_rase, $arr[5]));
        $result['id_rase'] = $this->_rases[$result['rase']];
        
        
        $result['rank'] = intval($arr[6]);
        $result['bo'] = floatval($arr[7]);
        $result['gate'] = (substr(trim($arr[8]), -1) == '1') ? 1 : 0;

        //адреса и имена сот        
        $names = explode(',', trim($arr[2]));
        $adresses = explode(',', trim($arr[3]));
        
        //дом
        list($result['ring'], $result['compl'], $result['sota']) = explode('.', array_shift($adresses) );
        $result['dom_name'] = array_shift($names);
        
        //колонии
        $result['colonyAdr'] = $adresses;
        $result['colonyName'] = $names;
        
        return $result;
    }

}

?>