<?php

defined('_CHEK') or die('Restricted access');
/*
 * модель изменений игроков 
 */

class Players_trans
{

    public $dom = array( );   //массив переездов по дому
    public $col = array( );   //массив переездов по колонкам
    public $alliance = array( ); //массив переходов в алы
    public $gate = array( ); //массив изменений ворот

    /*
     * анализ переездов по домашкам
     */
    public function analiseDom( $oldData, $newData )
    {
        $count = 0;
        foreach($newData as $player)
        {
            $idP = $player['id'];

            //if( !isset($oldData[$player['nik']]) )
             //   continue; //новый игрок

                if( $player['compl'] != $oldData[$player['nik']]['compl'] ||
                    $player['sota'] != $oldData[$player['nik']]['sota'] ) {
                $count++;
                $this->addTransDom(
                        $idP,
                        $oldData[$player['nik']]['compl'],
                        $player['compl'],
                        $oldData[$player['nik']]['sota'],
                        $player['sota']);
            }
        }

        if( config::${APPLICATION_ENV}['logMode'] != 'mini' ) {
            echo "Найдено " . $count . " переездов по домашним сотам<br>";
        }
    }

    /*
     * анализ переездов по колонкам
     * сравнение каждого нового игрока со старыми данными
     */
    public function analiseCol( $oldColony, $newData )
    {
        $countDel = 0;
        $countNew = 0;
        $countUpd = 0;
        foreach($newData as $player)
        {
            $idP = $player['id'];
            //var_dump($player['nik']);

            //пропускаем новых игроков
            if( $player['new'] === true )
                continue;

            //подготовка массивов данных
            list($oldAdr, $oldName) = $this->_prepareOldCol( isset($oldColony[$idP]) ? $oldColony[$idP] : array() );
            $newAdr = $player['colonyAdr'];
            $newName = $player['colonyName'];


            //проверка на баг данных в БД
            if( count($oldAdr) != count($oldName) )
            {
                echo "<span style='color:red;'>COUNT COLONY BUG DB {$player['nik']}</span><br/>";
                continue;
            }

            //проверка на баг данных в csv
            if( count($newAdr) != count($newName) )
            {
                echo "<span style='color:red;'>COUNT COLONY BUG CSV {$player['nik']}</span><br/>";
                continue;
            }
          
            //сравниваем старые с новыми
                /*
                 * адрес имеет приоритет перед названием соты
                 * если название не найдено
                 * {
                 *      записываем удаление
                 * }иначе{
                 *      если адрес изменился
                 *      {
                 *          ЗАПИСЫВАЕМ изменение
                 *          исключаем обе соты
                 *      }иначе{
                 *          изменений нет
                 *          исключаем обе соты
                 *      }
                 * }
                 *
                 */
                foreach( $oldName as $keyOld => $oldCol )
                {
                    $keyNew = array_search($oldCol, $newName, true );

                    if( $keyNew === false ) //имя ненайдено?
                    {
                        //удалённая колония
                        $countDel++;
                        list(,$oldCompl, $oldSota) = explode('.', trim($oldAdr[$keyOld]) );
                        $this->addTransCol( $idP, $oldCompl, $oldSota, null, null );
                    }else{
                        if( $oldAdr[$keyOld] == $newAdr[$keyNew] ) //адрес не изменилсо
                        {
                            unset( $newAdr[$keyNew], $newName[$keyNew] );
                        }else{ //записываем изменение
                            $countUpd++;
                            list(,$oldCompl, $oldSota) = explode('.', trim($oldAdr[$keyOld]) );
                            list(,$newCompl, $newSota) = explode('.', trim($newAdr[$keyNew]) );
                            $this->addTransCol( $idP, $oldCompl, $oldSota, $newCompl, $newSota );
                            unset( $newAdr[$keyNew], $newName[$keyNew] );
                        }
                        
                    }
                }

                //все оставшиеся колонии в новых данных идут как новые
                foreach( $newAdr as $newCol )
                {
                    $countNew++;
                    list(,$newCompl, $newSota) = explode('.', trim($newCol) );
                    $this->addTransCol( $idP, null, null, $newCompl, $newSota );
                }                    
        }

        if( config::${APPLICATION_ENV}['logMode'] != 'mini' ) 
            echo "Найдено " . ($countDel + $countNew + $countUpd) . " изменений колоний (up:{$countUpd}; del:{$countDel}; new:{$countNew})<br>";
        
//var_dump($this->col);
//die;
    }

    /*
     * анализ переходов по альянсам
     */
    public function analiseAll( $oldData, $newData )
    {
        $count = 0;
        foreach($newData as $player)
        {
            $idP = $player['id'];

            //if( !isset($oldData[$player['nik']]) )
             //   continue; //новый игрок

                if( $player['id_all'] != $oldData[$player['nik']]['id_alliance'] ) {
                $count++;
                $this->addTransAlliance(
                        $idP,
                        $oldData[$player['nik']]['id_alliance'],
                        $player['id_all']);
            }
        }

        if( config::${APPLICATION_ENV}['logMode'] != 'mini' ) {
            echo "Найдено " . $count . " переходов по альянсам<br>";
        }
    }

    /*
     * анализ изменений ворот
     */
    public function analiseGate( $oldData, $newData )
    {
        $count = 0;
        foreach($newData as $player)
        {
            $idP = $player['id'];

            if( $player['gate'] != $oldData[$player['nik']]['gate'] )
            {
                $count++;
                $this->addTransGate(
                        $idP,
                        $oldData[$player['nik']]['gate'],
                        $player['gate']);
            }
        }

        if( config::${APPLICATION_ENV}['logMode'] != 'mini' ) {
            echo "Найдено " . $count . " изменений ворот<br>";
        }
    }

    /*
     * добавляем изменение ворот в список
     */
    protected function addTransGate( $idP, $old, $new )
    {
        $this->gate[] = array(
            'id_player' => (int)$idP,
            'old_gate' => (int)$old,
            'new_gate' => (int)$new );
    }

    /*
     * добавляем изменение ала в список
     */
    protected function addTransAlliance( $idP, $idOld, $idNew )
    {
        $this->alliance[] = array(
            'id_player' => (int)$idP,
            'old_alliance' => (int)$idOld,
            'new_alliance' => (int)$idNew );
    }

    /*
     * добавляем изменение домашки в список
     */
    protected function addTransDom( $idP, $oldComp, $newComp, $oldSota, $newSota )
    {
        $this->dom[] = array(
            'id_player' => (int)$idP,
            'old_compl' => (int)$oldComp,
            'old_sota' => (int)$oldSota,
            'new_compl' => (int)$newComp,
            'new_sota' => (int)$newSota );
    }

    /*
     * добавляем изменение колонки в список
     */
    protected function addTransCol( $idP, $oldComp, $oldSota, $newComp, $newSota )
    {
        $this->col[] = array(
            'id_player' => (int)$idP,
            'old_compl' => (is_null($oldComp)) ? 'NULL' : (int)$oldComp,
            'old_sota' => (is_null($oldSota)) ? 'NULL' : (int)$oldSota,
            'new_compl' => (is_null($newComp)) ? 'NULL' : (int)$newComp,
            'new_sota' => (is_null($newSota)) ? 'NULL' : (int)$newSota );
    }

    /*
     * добавляет все данные в базу
     */
    public function save()
    {
        $db = DB::getInstance();

        //добавляем переезды по домашкам
        if( count($this->dom) > 0 ) {
            $sql = "INSERT INTO `players_trans_dom`
                        (`id`, `id_player`, `old_compl`, `old_sota`, `new_compl`, `new_sota`, `date`)
                       VALUES ";
            foreach($this->dom as $value)
                $sql .= sprintf("(NULL, %d, %d, %d, %d, %d, FROM_UNIXTIME(%d)) ,", 
                     $value['id_player'],$value['old_compl'],$value['old_sota'], $value['new_compl'], $value['new_sota'], TIME_START);
            
            $db->exec(substr($sql, 0, -1));
            echo count($this->dom) . ' переездов по домашкам добавлено<br>';
        }

        //добавляем переезды по колониям
        if( count($this->col) > 0 ) {
            $sql = "INSERT INTO `players_trans_colony`
                        (`id`, `id_player`, `old_compl`, `old_sota`, `new_compl`, `new_sota`, `date`)
                       VALUES ";
            
            foreach($this->col as $value)
                $sql .= sprintf("(NULL, '%d', %s, %s, %s, %s, FROM_UNIXTIME(%d)) ,",
                    $value['id_player'],$value['old_compl'],$value['old_sota'],$value['new_compl'],$value['new_sota'], TIME_START);
            
            $db->exec(substr($sql, 0, -1));
            echo count($this->col) . ' переездов по колониям добавлено<br>';
        }

        //добавляем переходы по алам
        if( count($this->alliance) > 0 ) {
            $sql = "INSERT INTO `players_trans_alliance`
                        (`id`, `id_player`, `old_alliance`, `new_alliance`, `date`)
                       VALUES ";
            
            foreach($this->alliance as $value)
                $sql .= sprintf('( NULL,"%d","%d","%d",FROM_UNIXTIME(%d) ) ,', 
                        $value['id_player'], $value['old_alliance'], $value['new_alliance'], TIME_START  );
            
            $db->exec(substr($sql, 0, -1));
            echo count($this->alliance) . ' переходов по альянсам добавлено<br>';
        }

        //добавляем изменения ворот
        if( count($this->gate) > 0 ) {
            $sql = "INSERT INTO `players_trans_gate`
                        (`id`, `id_player`, `old_gate`, `new_gate`, `date`)
                       VALUES ";
            foreach($this->gate as $value)
            {
                $sql .= sprintf('( NULL,"%d","%d","%d",FROM_UNIXTIME(%d) ) ,', 
                        $value['id_player'],$value['old_gate'],$value['new_gate'], TIME_START);
            }
            $db->exec(substr($sql, 0, -1));
            echo count($this->gate) . ' изменений ворот добавлено<br>';
        }
    }


    /*
     * подготовка массива старых колоний и их имён из данных БД
     */
    protected function _prepareOldCol($data)
    {
        $adr = array();
        $name = array();

        foreach ($data as $col)
        {
            $adr[] = sprintf('4.%d.%d', trim($col['compl']), trim($col['sota']) );
            $name[] = $col['col_name'];
        }
        return array($adr,$name);
    }
    
}
?>
