<?php
defined('_CHEK') or die('Restricted access');
/*
 *  вся работа с CSV файлом
 */
class CSV
{
     public $data = array(); //массив данных
     protected $fid = null; //указатель на файл
     protected $url = '';   //юрл мира
     protected $_parser = null; //парсер данных

     public function __construct($url, $parser)
     {
          $this->_parser = $parser;
          $this->url = $url;
     }

     /*
      * возвращает md5 hash
      */
     public function getMD5()
     {
          return @md5_file($this->url);
     }
     
     /*
      *  сеттер данных
      */
     public function setData()
     {
          $this->fid = (substr($this->url, -2) === 'gz') ? @gzfile($this->url) : @file($this->url);
          if ( $this->fid == false || count($this->fid) == 0)
              return FALSE;
               
          foreach ($this->fid as $line_num => $str)
          {
              $str = iconv("Windows-1251", "UTF-8", $str);
              
              if( $this->_parser->isValid($str) === true )
                  $this->data[] = $this->_parser->parse($str);
              else
                  echo "invalid str " . $this->_parser->getErr() . " {$str}<br/>";                            
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
               echo "Успешно раскодированно ".count($this->data)." строк (csv)<br>";
          
          return (count($this->data) > 0) ? TRUE : FALSE;
     }

     
     /*
      * вернуть уникальные имена новых алов
      */
     public function getNewAllianceNames($curAlliances)
     {
          $names = array();
          foreach ($this->data as $num => $str)
          {
              if ( !isset($curAlliances[$str['all']]) && 
                   $str['all'] != '' &&
                   array_search( $str['all'], $names) === false)
              {
                   $names[] = $str['all'];
              }
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Найдено ".count($names)." новых альянсов (csv)<br>";
          }

          return (count($names) > 0) ? $names : false ;
     }

     /*
      * вернуть уникальные данные новых игроков
      */
     public function getNewPlayersData($curPlayers)
     {
          $names = array();
          $uniqNiks = array();
          foreach ($this->data as $num => $str)
          {
              if ( !isset($curPlayers[$str['nik']]) && 
                   array_search($str['nik'], $uniqNiks) === false )
              {
                   $uniqNiks[] = $str['nik'];
                   $names[] = $str;
                   //отмечаем нового игрока (для анализа переездов по колониям)
                   $this->data[$num]['new'] = true;
              }
          }
          
          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
          {
               echo "Найдено ".count($names)." новых игроков (csv)<br>";
               if(count($names) != count($uniqNiks) )
               {
                    echo "обнаруженна неуникальность игроков в csv:<br>";
                    print_r($names);
                    print_r($uniqNiks);
               }
          }
          return (count($names) > 0) ? $names : false ;
     }

     /*
      * вернуть актуальные колонии игроков
      */
     public function getPlayersColony()
     {
          $colonys = array();
          foreach ($this->data as $num => $str)
          {
              if ( count($str['colonyAdr']) != 0 || count($str['colonyName']) != 0 )
              {
                    $colonys[$str['id']] = array(
                        'adr'=>$str['colonyAdr'],
                        'name'=>$str['colonyName']
                    );
              }
          }

          if (config::${APPLICATION_ENV}['logMode'] != 'mini')
               echo "Найден ".count($colonys)." игрок - колонизатор (csv)<br>";

          return $colonys;
     }


     /*
      * устанавливает ид альянса
      * (+значения нейтралов и нулевые для неизвестных алов + ошибки с никами и алами)
      */
     public function setIdAlliances($alliances)
     {
         foreach ($this->data as $num => $str)
         {   
             if($str['all'] == '')
                 $this->data[$num]['id_all'] = $alliances[config::${APPLICATION_ENV}['nameNeutrals']];
             elseif( isset($alliances[$str['all']]) )
                 $this->data[$num]['id_all'] = $alliances[$str['all']];
             else
		 throw new Exception('Запрошен ID несуществующего альянса ' . $str['all']);
         }
     }

     /*
      * устанавливает ид игрока
      */
     public function setIdPlayers($players)
     {
          foreach ($this->data as $num => $str)
          {
               if( !isset($players[$str['nik']]) )
                   throw new Exception( 'Запрошен ID несуществующего игрока' );
               
               $this->data[$num]['id'] = $players[$str['nik']]['id'];               
          }
     }

}
