<?php

defined('_CHEK') or die('Restricted access');
/*
 * слой работы с БД
 */ 
class DB extends PDO
{
    private $queriesNum;
    private $queries;
    static private $instance = NULL;

    static public function getInstance()
    {
        if( self::$instance == NULL ) {
            self::$instance = new DB();
        }
        return self::$instance;
    }

    public function __construct()
    {
        try {
            $db = parent::__construct('mysql:host=' . config::${APPLICATION_ENV}['DBhost'] . ';dbname=' . config::${APPLICATION_ENV}['DBname'],
                            config::${APPLICATION_ENV}['DBlogin'],
                            config::${APPLICATION_ENV}['DBpass']);
            $this->queriesNum = 0;
            $this->queries = '';
            print('Соединение установлено<br>');
            $this->Serv();
            return $db;
        } catch( PDOException $e ) {
            print($e->getMessage());
            exit();
        }
    }

    public function getQueryCount()
    {
        return $this->queriesNum;
    }

    public function getQuerys()
    {
        return $this->queries;
    }

    /*
     * запрос на выборку
     */
    public function Query( $sql )
    {
        $this->queryNumInc($sql);
        $res = parent::query($sql, DB::FETCH_ASSOC);
        if( !$res ) {
            print(var_dump($sql, $this->errorInfo(), $this->getQuerys()));
            exit();
        } else {
            return $res;
        }
    }

    /*
     * запрос на исполнение
     */
    public function exec( $sql = '' )
    {
        $this->queryNumInc($sql);
        $res = parent::exec($sql);
        if( $res === FALSE ) {
            print( var_dump($sql, $this->errorInfo(), $this->getQuerys() ));
            exit();
        }
        return $res;
    }

    /*
     * настройка коннекта с БД
     */
    protected function Serv()
    {
        $this->setAttribute(DB::ATTR_ERRMODE, DB::ERRMODE_WARNING);
        $this->exec('set wait_timeout=' . config::${APPLICATION_ENV}['DBtimeout']);
        $this->exec('SET NAMES \'utf8\';');
        $this->exec('SET character_set_connection = utf8;');
        $this->exec('SET character_set_client = utf8;');
        $this->exec('SET character_set_results = utf8;');
        print('Соединение настроено<br>');
    }

    /*
     * инкремент номера текущего запроса
     */
    protected function queryNumInc( $sql )
    {
        $this->queriesNum++;
        $this->queries .= "<br>$sql";
        //echo $sql."<br>";
    }

    /*
     * лочим таблицу
     */
    public function lockTable( $tables = null )
    {
        if( !is_array($tables) || count($tables) == 0 ) {
            return false;
        }

        $sql = "LOCK TABLES ";
        foreach($tables as $table)
        {
            $sql .= "`$table` WRITE,";
        }
        $this->exec(substr($sql, 0, -1));
    }

    public function unlockTable()
    {
        $this->exec('UNLOCK TABLES');
    }

    public function __destruct()
    {
        $this->unlockTable();
    }

}
