<?php
/*
 * скрипт собирает и добавляет статистику по мирам/алам
 */
ob_start();

define('_CHEK', 6455454);
define('TIME_START',time());
define('MICROTIME_START',microtime(1));

require_once("inc/config.php");        //конфиги и настройки
require_once("inc/func.php");          //другие функции + autoload

echo date("d_F_Y__H:i",TIME_START).'<br>'.TIME_START.'<br>';
getStat('Начало работы');

//собираем статистику по мирам
$statWorld = Stat::getItemStat('w');
getStat('Статистика по мирам собрана');

//собираем статистику по алам
$statAlliance = Stat::getItemStat('a');
getStat('Статистика по альянсам собрана');

//добавляем статистику в базу
Stat::saveStatItems($statWorld, $statAlliance);
getStat('Статистика добавлена в БД');


echo '<br>';
getStat('Итого');

//пишем логи
$out = ob_get_clean();
switch (config::${APPLICATION_ENV}['logType'])
{
     case 'text':  $out = str_replace('<br>', "\n", $out); echo $out;  break;

     case 'html':  $out = str_replace("\n", '<br>', $out); echo $out;  break;

     case 'file':
          $handle = fopen( APPLICATION_PATH.'/'.config::${APPLICATION_ENV}['logPath'].'/DAY_'.date("d_F_Y__H-i",TIME_START).'.html' , 'w' );
          fwrite( $handle,  str_replace("\n", '<br>', $out));
          fclose( $handle );
          echo date("d_F_Y__H:i",TIME_START)." day log file has been wrote\n";
     break;

     case 'db':
          $db = DB::getInstance();
          $res = $db->prepare('INSERT INTO `cron_logs` (`id`, `type`, `text`, `date`) VALUES (NULL, "day", ?, NOW())');
          $e = $res->Execute(array($out));
          print_r(date("d_F_Y__H:i",TIME_START)." day log writen to DB {$e}\n");
     break;
 }


?>
