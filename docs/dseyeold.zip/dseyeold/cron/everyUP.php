<?php
/*
 * скрипт проверяет необходимость обновления и
 * 1 - обновляет текущие параметры игроков/миров/алов (исключая новые рейтинги, РА и НРА)
 * 2 - удаляет/добавляет миры/альянсы/игроков
 * 3 - обновляет колонии
 * 4 - анализирует переезды/переходы
 * 6 - добавляет статистику по игрокам
 * 7 - обновляет дельты игроков 
 * 8 - обновляет максимальные дельты за текущий день
 * 
 */

ob_start();

define('_CHEK', 6455454);
define('TIME_START',time());
define('MICROTIME_START',microtime(1));

require_once("inc/config.php");        //конфиги и настройки
require_once("inc/func.php");          //другие функции + autoload


echo date("d_F_Y__H:i",TIME_START).'<br>'.TIME_START.'<br>';
getStat('Начало работы');//счётчик времени выполнения


//init
$_worlds = new Worlds();  //миры в БД
$_rases = new Rases();    //рассы в БД
$_playersTrans = new Players_trans();   //переезды
getStat('Инициализация общих объектов');

//цикл по мирам
foreach ($_worlds->values as $idWorld => $WORLD)
{
     echo '<b>'.$WORLD['name'].'</b><br>';
          
     $_csv = new CSV($WORLD['url'], Parser::factory($WORLD['type_parser'], $_rases->values));

     //проверка на релевантность
     if ($_csv->getMD5() == $WORLD['hash_csv'])
     {
          $_worlds->checkAsRelevant($idWorld);
          getStat('Мир релевантен');echo'<br>';
          continue;
     }

     //проверка на доступность
     if ($_csv->setData() == false)
     {
          $_worlds->checkAsDelete($idWorld);
          getStat('Мир оказался недоступен либо игроков не найдено');echo'<br>';
          continue;
     }

     //инитим живых игроков, колонии и все алы
     $_alliances = new Alliances(array('idW'=>$idWorld));
     $_players = new Players(array('idW'=>$idWorld));
     $_playersColony = new Players_colony(array('idW'=>$idWorld)); 
     getStat('Инициализация объектов мира');

     /*ПОНЕСЛАСЬ**********************************************/
     //добавляем новые альянсы (в БД и список)
     $data = $_csv->getNewAllianceNames($_alliances->values);
     if($data !== false)
         $_alliances->addItems($data);     

     //устанавливаем айдишники альянсов
     $_csv->setIdAlliances($_alliances->values);

     //добавляем новых игроков (в БД и список) и отмечаем новых внутри CSV
     $data = $_csv->getNewPlayersData($_players->values);
     if($data !== false)
         $_players->addItems($data);     

     //устанавливаем айдишники игроков
     $_csv->setIdPlayers($_players->values);

     //анализ переездов по домашкам(в список)
     $_playersTrans->analiseDom($_players->values, $_csv->data);

     //анализ переходов по альянсам(в список)
     $_playersTrans->analiseAll($_players->values, $_csv->data);

     //анализ изменений статусов ворот(в список)
     $_playersTrans->analiseGate($_players->values, $_csv->data);
     
     //анализ переездов по колониям(в список)
     $_playersTrans->analiseCol($_playersColony->values, $_csv->data);



     //добавляем актуальные колонии игроков (в список)
     $_playersColony->addItems($_csv->getPlayersColony());
  
     //заменяем колонии мира на новые
     $_playersColony->updateParams();
     
     //VARIANT 3 DELTA UP (RANK & BO ONLY)
     //обновляем параметры игроков в базе + ОБНОВЛЕНИЕ ДЕЛЬТ СТАРОГО РЕЙТИНГА И БО
     $_players->updateParams($_csv->data);
     
     //отмечаем удалённых игроков (исходя из даты обновления)
     $_players->checkDeletedPlayers();

     //обновляем параметры альянсов (по данным живых игроков)
     $_alliances->updateParams(Stat::getAllianceParams($idWorld));

     //отмечаем удалённые альянсы (исходя из даты обновления)
     $_alliances->checkDeletedAlliances();

     //VARIANT 1 DELTA UP
     //обновляем дельты игроков мира (напрямую с таблицей статистики)
     //Players::updateDelta( $idWorld );
     

     //добавляем статистику по игрокам данного мира
     Stat::saveStatPlayers( $idWorld );
     
     
/*//VARIANT 2 DELTA UP
     //обновляем дельты игроков мира (временная таблица)
     //ЖДЁТ РОТАЦИИ ТАБЛИЧКИ СТАТИСТИКИ ИГРОКОВ, ИНАЧЕ УПИРАЕТСЯ В ДОЛГОЕ ЧТЕНИЕ С ДИСКА (ТАБЛИЦА НА 1 ГБ)
getStat('начало обновления дельт');
     Players::updateDelta2( $idWorld ); //опирается на временную табличку
getStat('конец обновления дельт');
     Stat::updTmpStatPlayers( $idWorld ); //обновляем временныю табличку
getStat('конец обновления временного слепка');
/**/

     //обновляем макс изменения рейтинга за сегодня
     Stat::updMaxRankDelts( $idWorld );

     //обновляем макс изменения БО за сегодня
     Stat::updMaxBoDelts( $idWorld );



     //обновляем параметры мира
     $_worlds->updateParams( Stat::getWorldParams($idWorld) );

     //отмечаем мир как обновлённый
     $_worlds->checkAsUpdate($idWorld, $_csv->getMD5());
     
     unset($_csv, $_alliances, $_players, $data, $_playersColony);

     getStat('Мир был обновлён');echo'<br>';

     //break;
}
//конец цикла по мирам

//добавляем все собранные переезды
$_playersTrans->save();

getStat('Итого');echo'<br>';


//пишем логи
$out = ob_get_clean();
switch (config::${APPLICATION_ENV}['logType'])
{
     case 'text':  $out = str_replace('<br>', "\n", $out); echo $out;  break;

     case 'html':  $out = str_replace("\n", '<br>', $out); echo $out;  break;

     case 'file':
          $handle = fopen( APPLICATION_PATH.'/'.config::${APPLICATION_ENV}['logPath'].'/UP_'.date("d_F_Y__H-i",TIME_START).'.html' , 'w' );
          fwrite( $handle,  str_replace("\n", '<br>', $out));
          fclose( $handle );          
          echo date("d_F_Y__H:i",TIME_START)." up log file has been wrote\n";
     break;

     case 'db':
          $db = DB::getInstance();
          $res = $db->prepare('INSERT INTO `cron_logs` (`id`, `type`, `text`, `date`) VALUES (NULL, "up", ?, NOW())');
          $e = $res->Execute(array($out));
          print_r(date("d_F_Y__H:i",TIME_START)." up log writen to DB {$e}\n");
     break;
 }
?>
