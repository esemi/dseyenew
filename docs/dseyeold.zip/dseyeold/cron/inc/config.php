<?php
defined('_CHEK') or die('Restricted access');

define('APPLICATION_ENV',( trim(`hostname`) == 'vm10420.majordomo.ru')? 'production' : 'development');

define('APPLICATION_PATH', realpath( dirname(__FILE__).'/../') ); 

echo 'APPLICATION_ENV:'.APPLICATION_ENV.'<br>APPLICATION_PATH: '.APPLICATION_PATH.'<br>';

date_default_timezone_set('Europe/Moscow');
set_time_limit(config::${APPLICATION_ENV}['phpExecTime']);
ini_set( "display_errors",       "1" );
ini_set( "memory_limit",       "60M" );
ini_set( "error_reporting", E_ALL | E_WARNING | E_NOTICE );

/*
var_dump(ini_get( "allow_url_fopen"),
ini_get( "memory_limit"),
ini_get( "display_errors"),
ini_get( "error_reporting"),
ini_get( "max_execution_time"));
die();
*/


/*
 * настройки конфигов для всех скриптов
 */
class config
{
     //конфигурация локальной машины
     static $development = array(
          'DBhost' => 'localhost',
          'DBlogin' => 'dseye_back',
          'DBpass' => 'XFYC4SczZvPpcnRY',
          'DBname' => 'dseye',
          'DBtimeout' => 2000,
          'phpExecTime' => 600,
          'logPath' => 'logs',
          'logType' => 'file', //file html text db
          'logMode' => 'full', //mini full debug
          'trashPlayers' => 30,
          'trashItems' => 180,
          'trashCron' => 15,
          'deltaRankBorder' => 30000,
          'deltaRankLimit' => 50,
          'deltaBoBorder' => 10,
          'deltaBoLimit' => 50,
          'nameNeutrals' => 'нейтралы',
          'curlUser' => "DSeyeBot/1.2; +http://dseye.ru/help.html#bot"
          );

     //конфигурация на боевом сервере
     static $production = array(
          'DBhost' => 'localhost',
          'DBlogin' => 'dseye_back',
          'DBpass' => 'XFYC4SczZvPpcnRY',
          'DBname' => 'dseye',
          'DBtimeout' => 10000,
          'phpExecTime' => 300,
          'logPath' => 'logs',
          'logType' => 'db',
          'logMode' => 'full',
          'trashPlayers' => 30,
          'trashItems' => 180,
          'trashCron' => 15,
          'deltaRankBorder' => 30000,
          'deltaRankLimit' => 50,
          'deltaBoBorder' => 10,
          'deltaBoLimit' => 50,
          'nameNeutrals' => 'нейтралы',
          'curlUser' => "DSeyeBot/1.2; +http://old.dseye.ru/help.html#bot"
          );
}
?>
