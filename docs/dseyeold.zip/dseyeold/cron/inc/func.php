<?php
defined('_CHEK') or die('Restricted access');

/*
 * выводим статистику
 */
function getStat($name = 'undef')
{
   $time_end=microtime(1);
   $memory = memory_get_usage()/1024/1024;
   $mem_peak = memory_get_peak_usage()/1024/1024;
   $time = $time_end - MICROTIME_START;
   $queres = DB::getInstance()->getQueryCount();
   print "<br>$name: time= $time sec; count(query)=$queres; memory= $memory Mb; memory peak= $mem_peak<br>";
}

/*
 * автолоад классов и моделей
 */
function __autoload($class)
{
    if (file_exists(APPLICATION_PATH.'/classes/'.$class.'.class.php'))
         require_once(APPLICATION_PATH.'/classes/'.$class.'.class.php');
    elseif (file_exists(APPLICATION_PATH.'/models/'.$class.'.php'))
         require_once(APPLICATION_PATH.'/models/'.$class.'.php');
    else
         exit("$class not found");
}

?>
