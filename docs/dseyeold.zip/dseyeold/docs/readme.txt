Миры удаляются только из админки (вместе с игроками и алами и статистикой)
Пометка о мире как удалённом присваивается в случае недоступности логов
Могут быть восстановленны
Статистика по удалённым мирам хранится всегда(просто не дополняется)


Альянсы не удаляются никогда
Пометка об але как удалённом присваивается в случае отсутствия в нём игроков
Альянсы, отмеченные как удалённые не отображаются в списках и рейтингах и не расчитываются
Могут быть восстановленны
Статистика по удалённым алам хранится всегда(просто не дополняется)


Игроки удаляются через определённое время вместе со статистиками, колониями и переездами
Не могут быть восстановлены, только новый игрок
Игроки, отмеченные как удалённые, не отображаются в списках и рейтингах и не расчитываются



Запускать скрипты следует в следующей последовательности:

10 04 * * * python2.6 /home/esemi/cron/clusters/main.py

10 05 * * * php /home/esemi/app/zfcli.php -a scavenger >> /home/esemi/logs/cron_log
00 * * * *  php /home/esemi/app/zfcli.php -a onlinestat >> /home/esemi/logs/cron_log
20 */2 * * * php /home/esemi/app/zfcli.php -a csv >> /home/esemi/logs/cron_log

10-55/5 0-3,6-23 * * * php /home/esemi/app/zfcli.php -a dshelpra >> /home/esemi/logs/cron_log
10-55/4 0-3,6-23 * * * php /home/esemi/app/zfcli.php -a newranks >> /home/esemi/logs/cron_log

02 */2 * * *  php /home/esemi/cron/everyUP.php >> /home/esemi/logs/cron_log
55 23 * * * php /home/esemi/cron/everyDAY.php >> /home/esemi/logs/cron_log
