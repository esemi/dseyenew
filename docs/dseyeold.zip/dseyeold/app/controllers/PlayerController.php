<?php
class PlayerController extends Zend_Controller_Action
{

    protected 
        $idW = null,
        $idP = null;

    public function init()
    {
        if( $this->_helper->modelLoad('Worlds')->validate((int) $this->_getParam('idW')) !== true )
                throw new Exception('World id is not valid');

        $this->view->idWorld = $this->idW = (int) $this->_getParam('idW');

        //имя мира
        $this->view->nameWorld =$this->_helper->modelLoad('Worlds')->getName($this->idW);
        
        //резиновый шаблон
        $this->view->rubberPage = true;
    }

    /*
     * главная страница игрока + графики
     */
    public function indexAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'player_page'), 'helpView', true );
        
        $this->view->idPlayer = $this->idP = (int) $this->_getParam('idP');
        if( $this->_helper->modelLoad('Players')->validate($this->idP, $this->idW) !== true ) 
            throw new Exception('Player id is not valid');
        
        //если не false - доступен график с хелпера
        $this->view->dshelp = $this->_helper->modelLoad('Worlds')->getDshelpName( $this->idW );

        //если true - доступен поиск сообщений на форуме
        $this->view->forum = ( !is_null($this->_helper->modelLoad('Worlds')->getForumSearchPattern( $this->idW )) );

        //доступен ли мониторинг
        if( $this->_helper->checkAccess('monitoring', 'manage', 'return') )
        {
            $user = Zend_Auth::getInstance()->getStorage()->read(); 
            $this->view->monitor = $this->_helper->modelLoad('MonitorItems')->issetByUser($this->idP, $user->id);
        }
        
        $this->view->mainProperty = $data = $this->_helper->modelLoad('Players')->getInfo($this->idP);             
                      
        
        $this->view->transAlliance = $this->_helper->modelLoad('TransAlliance')->getTransByPlayer($this->idP, 5);
        $this->view->transGate = $this->_helper->modelLoad('TransGate')->getTransByPlayer($this->idP, 10);
        $this->_helper->modelLoad('TransSots')->setPlayerRing($data['ring']);
        $this->view->transSots = $this->_helper->modelLoad('TransSots')->getTransByPlayer($this->idP, 5 );
        
        $this->view->otherWorlds = $this->_helper->modelLoad('Players')->playerWithoutWorld($data['nik'], $this->idW );
        $this->view->neighbors = $this->_helper->modelLoad('Players')->getNeighbors( $data );
        
        $this->view->title = "Игрок {$data['nik']}";
        $this->view->keywords = "{$data['nik']}, Игрок, {$this->view->nameWorld}";
        $this->view->description = "Страница игрока {$data['nik']}. Основные показатели и графики.";
    }    


    /*
     * быстрый переход к игроку по нику
     */
    public function quickAction()
    {
        //пробуем получить ник игрока
        $idP = $this->_helper->modelLoad('Players')->findByNik( trim($this->_getParam('nik')), $this->idW );

        if( $idP === false )
            throw new Exception('Игрок с данным ником не найден в заданном мире.');

        $this->_helper->redirector->gotoRoute(
                array( 'idW' => $this->idW, 'idP' => $idP ),
                'playerStat', true);
    }


    /*
     * поиск сообщений игрока на форуме
     */
    public function forumsearchAction()
    {
        $this->idP = (int) $this->_getParam('idP');
        if( $this->_helper->modelLoad('Players')->validate($this->idP, $this->idW) !== true )
            throw new Exception('Player id is not valid');

        //получить шаблон поиска
        $pattern = $this->_helper->modelLoad('Worlds')->getForumSearchPattern( $this->idW );
        if( is_null($pattern) )
            throw new Exception('Forum search pattern not found');

        //получить инфу (для подстановки в шаблон поиска)
        $info = $this->_helper->modelLoad('Players')->getInfo($this->idP);
        
        $url = str_replace('{-author-}', $info['nik'], $pattern);

        $this->_redirect($url);
    }

}


