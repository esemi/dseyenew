<?php

/*
 * контроллер логов
 *
 * сводка и подробный просмотр
 * 
 */
class LogsController extends Zend_Controller_Action
{
    /*
     * лог крона и подробные логи всех действий
     */
    public function indexAction()
    {
        $this->_helper->checkAccess('logs','view','redirect');
        
        $res = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('resources');
        $log = $res['log'];
        
        $this->view->excepLog =Mylib_Utils::tail(realpath($log['main']['writerParams']['stream']), 30);
        $this->view->csrfLog =Mylib_Utils::tail(realpath($log['csrf']['writerParams']['stream']), 30);
        $this->view->errorsLog =Mylib_Utils::tail(realpath($log['error']['writerParams']['stream']), 30);
        
        //$this->view->clustLog =Mylib_Utils::tail(realpath( APPLICATION_PATH . '/../logs/cluster_log'), 20);        
        $this->view->cronLog = Mylib_Utils::tail(realpath(  LOG_PATH . '/cron.log'), 20);
        $this->view->httpLog = Mylib_Utils::tail(realpath(  LOG_PATH . '/errorApache.log'), 20);
        $this->view->nginxLog =Mylib_Utils::tail(realpath(  LOG_PATH . '/errorNginx.log'), 20);

        $this->view->up = $this->_helper->modelLoad('CronLogs')->getLogsByType('up');
        $this->view->day = $this->_helper->modelLoad('CronLogs')->getLogsByType('day');
        $this->view->online = $this->_helper->modelLoad('CronLogs')->getLogsByType('onlineStatus');
        $this->view->scav = $this->_helper->modelLoad('CronLogs')->getLogsByType('scavenger');
        $this->view->dshelp = $this->_helper->modelLoad('CronLogs')->getLogsByType('dshelpRA');
        $this->view->newranks = $this->_helper->modelLoad('CronLogs')->getLogsByType('newRanks');
        $this->view->csv = $this->_helper->modelLoad('CronLogs')->getLogsByType('csv');       
    }

    /*
     * просмотр подробного лога
     */
    public function viewAction()
    {
        $this->_helper->checkAccess('logs','view','redirect');

        $this->_helper->layout->disableLayout();
        
        $log = $this->_helper->modelLoad('CronLogs')->find( (int) $this->_getParam('idL') )->current();        
        if( is_null($log) )
            throw new Exception('Log not found');
        
        $this->view->log = $log->text;
    }


}





