<?php

/*
 * контроллер аутентификации юзера
 *
 */
class AuthController extends Zend_Controller_Action
{

    protected $_recaptcha = null; //объект капчи

    public function init()
    {        
        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('recaptcha');
        $this->_recaptcha = new Zend_Service_ReCaptcha($conf['pubkey'],$conf['privkey']);
    }

    /*
     * вход
     */
    public function loginAction()
    {        
        $this->view->keywords = "Вход, Войти, Залогиниться, Форма входа, Личный кабинет";
        $this->view->description = "Вход в личный кабинет";
        $this->view->title = "Вход в личный кабинет";

        //спец ошибка для уже залогиненых юзеров (ну не эксепшн же кидать, правда?)
        $this->view->isAuth = Zend_Auth::getInstance()->hasIdentity();

        //с регистрации люди приходят с сообщением
        $mes = $this->_helper->flashMessenger->getMessages();
        if( count($mes) > 0 && is_array($mes) )
        {
            $mes = array_shift($mes);
            $keys = array_keys($mes);
            $this->view->messType = array_shift( $keys );
            $this->view->messText = array_shift( $mes );
        }
        
        $ip = $this->_request->getClientIp();        
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut');        
        if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'login', $ip, $prop['login']['try'], $prop['login']['minutes']) )
            $this->view->recaptcha = $recaptcha = $this->_recaptcha;

        if ($this->_request->isPost() && !$this->view->isAuth)
        {            
            $this->view->login = $login = $this->_request->getPost('login');
            
            //проверяем капчу (если надо)
            if( isset($recaptcha) )
            {                
                if( !$this->_helper->checkCaptcha($recaptcha) )
                {
                    $this->view->messType = 'error';
                    $this->view->messText = 'Текст с изображения введён неверно.';
                    return;
                }
            }      
            
            $dbUser = $this->_helper->modelLoad('Users')->findByLogin( $login );
            $auth = Zend_Auth::getInstance();

            $db = $this->getInvokeArg('bootstrap')->getResource('db');
            $adapter = new Zend_Auth_Adapter_DbTable($db);
            $adapter->setTableName('users')
                    ->setIdentityColumn('login')
                    ->setCredentialColumn('pass')
                    ->setCredentialTreatment('SHA1( CONCAT( ?, `salt` ) ) AND `approved` = "yes"')
                    ->setIdentity( $login )
                    ->setCredential( trim($this->_request->getPost('pass')) );

            if( !is_null($dbUser) && $dbUser->approved == 'no' )
            {
                $this->_helper->modelLoad('Antibrut')->addIP( 'login', $ip );
                
                if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'login', $ip, $prop['login']['try'], $prop['login']['minutes']) )
                    $this->view->recaptcha = $this->_recaptcha;
                
                $this->view->messType = 'error';
                $this->view->messText = 'Аккаунт ещё не активирован.';                                
                $this->_helper->modelLoad('UsersHistory')->add( $dbUser->id, 'Попытка входа неактивированным аккаунтом', $this->_request);                
                return;
            } 
            
            if ( $login == '' || !$auth->authenticate($adapter)->isValid() )
            {
                $this->_helper->modelLoad('Antibrut')->addIP( 'login', $ip ); 
                
                if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'login', $ip, $prop['login']['try'], $prop['login']['minutes']) )
                    $this->view->recaptcha = $this->_recaptcha;     
                
                $this->view->messType = 'error';
                $this->view->messText = 'Неверные логин или пароль';
                if( !is_null($dbUser) )
                    $this->_helper->modelLoad('UsersHistory')->add( $dbUser->id, 'Попытка входа в систему с неверным паролем', $this->_request);
                return;
            }
            
            $res = $adapter->getResultRowObject();
            $user = new stdClass();
            $user->id = $res->id;
            $user->login = $res->login;
            $user->role = $res->role;     
            $user->csrf = hash('sha256', uniqid( mt_rand(), true ));
            $auth->getStorage()->write($user);

            /*if( $this->_request->getPost('remember','off') == 'on' )
                Zend_Session::rememberMe();*/

            $this->_helper->modelLoad('Users')->updLastLogin( $user->id );
            $this->_helper->modelLoad('UsersHistory')->add( $user->id, 'Вход в систему', $this->_request);

            //умный редирект
            $this->_redirect( $this->_getParam('return', $this->_helper->url->url(array(),'userProfile',true) ) , array('exit') );            
        }

    }

    /*
     * выход
     */
    public function logoutAction()
    {
        $auth = Zend_Auth::getInstance();
        if( $auth->hasIdentity() )
        {
            $user = $auth->getStorage()->read();
            
            Zend_Auth::getInstance()->clearIdentity();
            Zend_Session::forgetMe();
            Zend_Session::expireSessionCookie();

            $this->_helper->modelLoad('UsersHistory')->add($user->id, 'Выход из системы', $this->_request);
        }
        
        $this->_redirect('/', array('exit') );
    }

    /*
     * Регистрация нового пользователя
     */
    public function registerAction()
    {
        $this->view->keywords = "Новый пользователь, Регистрация аккаунта, Регистрация";
        $this->view->description = "Регистрация нового пользователя для входа в личный кабинет";
        $this->view->title = "Регистрация нового пользователя";
          
        $ip = $this->_request->getClientIp();
        
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut');        
        if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'register', $ip, $prop['register']['try'], $prop['register']['minutes']) )
            $this->view->recaptcha = $recaptcha = $this->_recaptcha;
                
        if ( $this->_request->isPost() )
        {
            $this->view->post = $post = $this->_request->getPost();
            
            $result = $this->_helper->modelLoad('Users')->validateNewUser( $post, isset($recaptcha) ? $recaptcha : null );

            if( $result === true )
            {
                $scavProp = $this->getFrontController()->getParam('bootstrap')->getOption('scav');
                
                //добавляем успешную регистрацию в антибрут
                $this->_helper->modelLoad('Antibrut')->addIP( 'register', $ip );

                //заводим нового юзера
                $idUser = $this->_helper->modelLoad('Users')->addNew( $post );
                $this->_helper->modelLoad('UsersHistory')->add( $idUser, 'Регистрация аккаунта', $this->_request );
                                
                //генерим токен и шлём письмо с активацией                
                $token = $this->_helper->modelLoad('UsersApproved')->add( $idUser );
                
                //шлём письмо
                $mail = new Mylib_Mail('utf-8');
                $mail->setHeaderEncoding(Zend_Mime::ENCODING_BASE64);
                $mail->setSubject('Регистрация нового пользователя DSeye.ru');
                $mail->setBodyHtml( 
                        $this->view->partial( 
                            'Partials/mail/registration.phtml', 
                            array(
                                'email' => $post['email'],
                                'login' => $post['login'],
                                'token' => $token,
                                'scavProp' => $scavProp['users'],
                                'ip' => $ip
                                )) );
                $mail->addTo($post['email']);
                $mail->send();

                $this->_helper->flashMessenger->addMessage(  array( 'success' => "Вы успешно зарегистрировались под ником {$post['login']}.<br/>На указанный Вами адрес отправлено письмо с инструкцией по активации аккаунта. Неактивированный аккаунт будет удалён спустя {$scavProp['users']} дня с момента регистрации." ) );
                $this->_helper->redirector->gotoRoute(array(), 'staticLogin');
            }else{
                $this->view->messType = 'error';
                $this->view->messText = $result;
            }
        }

    }

    /*
     * Активация нового аккаунта по токену
     */
    public function registertokenAction()
    {
        $this->view->keywords = "Активация, Новый пользователь";
        $this->view->description = "Активация нового аккаунта";
        $this->view->title = "Активация нового аккаунта";

        $this->view->token = $token = $this->_getParam('token');
        $scavProp = $this->getFrontController()->getParam('bootstrap')->getOption('scav');
        $this->view->timeout = $scavProp['users'];
        
        if ( !is_null($token) )
        {            
            $idUser = $this->_helper->modelLoad('UsersApproved')->findAndUpdToken( $token );

            //юзер с таким токеном найден
            if( !is_null($idUser) )
            {
                $this->_helper->modelLoad('Users')->approve( $idUser );
                $this->_helper->modelLoad('UsersHistory')->add( $idUser, 'Активация аккаунта', $this->_request );                

                $this->_helper->flashMessenger->addMessage( array( 'success' => "Аккаунт успешно активирован и готов к использованию." ) );
                $this->_helper->redirector->gotoRoute(array(), 'staticLogin');
            }else{
                $this->view->messType = 'error';
                $this->view->messText = 'Код активации не верен или пользователь уже удалён.';
            }
        }
    }

    /*
     * Запрос повторной активации аккаунта
     */
    public function registerretryAction()
    {
        $this->view->keywords = "Активация, Новый пользователь, Повторная активация, Не пришло письмо";
        $this->view->description = "Запрос повторной активации нового пользователя для входа в личный кабинет";
        $this->view->title = "Запрос повторной активации нового пользователя";
                    
        $ip = $this->_request->getClientIp();
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut');        
                
        if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'registerretry', $ip, $prop['registerretry']['try'], $prop['registerretry']['minutes']) )
            $this->view->recaptcha = $recaptcha = $this->_recaptcha;
                
        if ( $this->_request->isPost() )
        {            
            $this->_helper->modelLoad('Antibrut')->addIP( 'registerretry', $ip );
            
            if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'registerretry', $ip, $prop['registerretry']['try'], $prop['registerretry']['minutes']) )
                $this->view->recaptcha = $this->_recaptcha;
            
            $this->view->login = $login = $this->_request->getPost('login','');
            $this->view->email = $email = $this->_request->getPost('email','');

            //проверяем капчу (если надо)
            if( isset($recaptcha) )
            {
                if( !$this->_helper->checkCaptcha($recaptcha) )
                {
                    $this->view->messType = 'error';
                    $this->view->messText = 'Текст с изображения введён неверно.';
                    return;
                }
            }        
                       
            $user = $this->_helper->modelLoad('Users')->findForApprove( $login, $email );            
            
            //юзер не найден (неактивированный по логину и мылу)
            if( is_null($user) )
            {
                $this->view->messType = 'error';
                $this->view->messText = "Пользователь не найден либо уже активирован.";
                
                $dbUser = $this->_helper->modelLoad('Users')->findByLogin( $login );
                if( !is_null($dbUser) )
                    $this->_helper->modelLoad('UsersHistory')->add( $dbUser->id, 'Запрос повторной активации аккаунта (неверный адрес либо уже активирован)', $this->_request);
                return;
            }
                        
            $token = $this->_helper->modelLoad('UsersApproved')->add( $user->id );                
            $this->_helper->modelLoad('UsersHistory')->add( $user->id, 'Запрос повторной активации аккаунта (письмо отправлено)', $this->_request);
            $scavProp = $this->getFrontController()->getParam('bootstrap')->getOption('scav');            


            //шлём письмо
            $mail = new Mylib_Mail('utf-8');
            $mail->setHeaderEncoding(Zend_Mime::ENCODING_BASE64);
            $mail->setSubject('Запрос повторной активации аккаунта DSeye.ru');                    
            $mail->setBodyHtml(
                    $this->view->partial( 
                            'Partials/mail/registrationRetry.phtml', 
                            array(
                                'email' => $user->email,
                                'login' => $user->login,
                                'token' => $token,
                                'scavProp' => $scavProp['users'],
                                'ip' => $ip
                                )) );
            $mail->addTo($user->email);
            $mail->send();

            //сообщение сохраняем и редиректим
            $this->_helper->flashMessenger->addMessage(  array( 'success' => "Заявка на повторную активацию аккаунта принята.<br/>В ближайшее время на указанный при регистрации email-адрес придёт письмо с инструкцией по активации. Неактивированный аккаунт будет удалён спустя {$scavProp['users']} дня с момента регистрации." ) );
            $this->_helper->redirector->gotoRoute(array(), 'staticLogin');            
        }
    }

    /*
     * Запрос восстановления пароля
     * (высылаем ссылку на подтверждение генерации нового пароля)
     */
    public function rememberAction()
    {
        $this->view->keywords = "Забыл пароль, Восстановление пароля, Remember password, Recovery password";
        $this->view->description = "Восстановление пароля в личный кабинет";
        $this->view->title = "Восстановление пароля";
                            
        $ip = $this->_request->getClientIp();
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut'); 
                        
        if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'remember', $ip, $prop['remember']['try'], $prop['remember']['minutes']) )
            $this->view->recaptcha = $recaptcha = $this->_recaptcha;
                
        if ( $this->_request->isPost() )
        {
            $this->_helper->modelLoad('Antibrut')->addIP( 'remember', $ip );
            
            if( true !== $this->_helper->modelLoad('Antibrut')->checkIP( 'remember', $ip, $prop['remember']['try'], $prop['remember']['minutes']) )
                $this->view->recaptcha = $this->_recaptcha;
            
            $this->view->login = $login = $this->_request->getPost('login');
            $this->view->email = $email = $this->_request->getPost('email');

            //проверяем капчу (если надо)
            if( isset($recaptcha) )
            {
                if( !$this->_helper->checkCaptcha($recaptcha) )
                {
                    $this->view->messType = 'error';
                    $this->view->messText = 'Текст с изображения введён неверно.';
                    return;
                }
            }    
            
            $user = $this->_helper->modelLoad('Users')->findForRemember( $login, $email );

            //юзер не найден (активированный по логину и мылу)
            if( is_null($user) )
            {
                $this->view->messType = 'error';
                $this->view->messText = 'Пользователь с указанными логином и адресом отсутствует или не активирован.';
                
                $dbUser = $this->_helper->modelLoad('Users')->findByLogin( $login );
                if( !is_null($dbUser) )
                    $this->_helper->modelLoad('UsersHistory')->add( $dbUser->id, 'Запрос восстановления пароля (неверный адрес или неактивный аккаунт)', $this->_request);
                return;
            }
                        
            $this->_helper->modelLoad('UsersHistory')->add($user->id, 'Запрос восстановления пароля (письмо отправлено)', $this->_request);
            $rememberProp = $this->getFrontController()->getParam('bootstrap')->getOption('remember');
            
            $token = $this->_helper->modelLoad('UsersRemember')->add( $user->id );

            //шлём письмо
            $mail = new Mylib_Mail('utf-8');
            $mail->setHeaderEncoding(Zend_Mime::ENCODING_BASE64);
            $mail->setSubject('Восстановление пароля DSeye.ru');
            $mail->setBodyHtml(
                    $this->view->partial( 
                            'Partials/mail/rememberLogin.phtml', 
                            array(
                                'login' => $user->login,
                                'token' => $token,
                                'scavProp' => $rememberProp['hours'],
                                'ip' => $ip
                                )) );
            $mail->addTo($user->email);
            $mail->send();

            $this->_helper->flashMessenger->addMessage(  array( 'success' => "Заявка на восстановление пароля принята.<br/>В ближайшее время на указанный Вами при регистрации email-адрес придёт письмо с инструкцией по восстановлению." ) );
            $this->_helper->redirector->gotoRoute(array(), 'staticLogin');
        }
    }

    /*
     * Попытка восстановления пароля
     * (заменяем пароль по токену и шлём новый на почту)
     */
    public function remembertokenAction()
    {
        $this->view->keywords = "Забыл пароль, Восстановление пароля, Подтверждение, Remember password, Recovery password";
        $this->view->description = "Подтверждение восстановления пароля в личный кабинет";
        $this->view->title = "Подтверждение восстановления пароля";

        $this->view->token = $token = $this->_getParam('token');
        $rememberProp = $this->getFrontController()->getParam('bootstrap')->getOption('remember');

        if ( !is_null($token) )
        {
            $idUser = $this->_helper->modelLoad('UsersRemember')->findAndUpdToken( $token, $rememberProp['hours'] );

            //юзер с таким токеном найден
            if( is_null($idUser) )
            {
                $this->view->messType = 'error';
                $this->view->messText = 'Код активации не верен либо устарел.';
                return;
            }
            
            //устанавливаем новый пароль
            $newPass = $this->_helper->modelLoad('Users')->updPass( $idUser );
            $user = $this->_helper->modelLoad('Users')->getInfo( $idUser );
         
            //шлём письмо
            $mail = new Mylib_Mail('utf-8');
            $mail->setHeaderEncoding(Zend_Mime::ENCODING_BASE64);
            $mail->setSubject('Восстановление пароля DSeye.ru');
            $mail->setBodyHtml(
                    $this->view->partial( 
                            'Partials/mail/rememberToken.phtml', 
                            array(
                                'login' => $user['login'],
                                'pass' => $newPass)) );
            $mail->addTo($user['email']);
            $mail->send();

            $this->_helper->modelLoad('UsersHistory')->add( $idUser, 'Смена пароля через восстановление', $this->_request);

            $this->_helper->flashMessenger->addMessage( array( 'success' => "Новый пароль успешно установлен и отправлен вам на почту." ) );
            $this->_helper->redirector->gotoRoute(array(), 'staticLogin');
            
        }
    }

    
}





