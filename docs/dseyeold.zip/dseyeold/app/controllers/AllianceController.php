<?php

class AllianceController extends Zend_Controller_Action
{

    protected 
        $idW = null,
        $idA = null;

    public function init()
    {
        if( $this->_helper->modelLoad('Worlds')->validate((int) $this->_getParam('idW')) !== true ) 
            throw new Exception('World id is not valid');        
        $this->view->idWorld = $this->idW = (int) $this->_getParam('idW');

        if( $this->_helper->modelLoad('Alliances')->validate((int) $this->_getParam('idA'), $this->idW) !== true ) {
            $this->_redirect($this->view->url(array( 'idW' => $this->idW ), 'worldAlliances', true));
            die();
        }
        $this->view->idAlliance = $this->idA = (int) $this->_getParam('idA');

        $this->view->nameAlliance = $this->_helper->modelLoad('Alliances')->getName($this->idA);
        $this->view->title = "Альянс {$this->view->nameAlliance}";
        
        $this->view->nameWorld = $this->_helper->modelLoad('Worlds')->getName($this->idW); 
        
        //резиновый шаблон
        $this->view->rubberPage = true;
    }

    /*
     * последние изменения и общие данные альянса
     */
    public function indexAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'alliance_page'), 'helpView', true );        
        $this->view->rubberPage = false;

        $this->view->keywords = "{$this->view->nameAlliance}, Альянс, Информация";
        $this->view->description = "Альянс {$this->view->nameAlliance}, общая информация";
        $this->view->actTitle = "Об альянсе";
        
        $data = $this->_helper->modelLoad('Alliances')->getCurProperty($this->idA);
        if( $data == false )
            throw new Exception('Alliance property not found');
        
        $this->view->mainProperty = $data;
                        
        $this->view->transAlliance = $this->_helper->modelLoad('TransAlliance')->getTransByAlliance($this->idA, 14);
        $this->view->transSots = $this->_helper->modelLoad('TransSots')->getTransByAlliance($this->idA, 10);
        $this->view->transGate = $this->_helper->modelLoad('TransGate')->getTransByAlliance($this->idA, 26);
    }

    /*
     * список игроков альянса
     */
    public function playersAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'lists'), 'helpView', true );        
        
        $page = (int) $this->_getParam('page', 1);
        $this->view->sort = $sort = $this->_getParam('sort');
        
        $this->view->paginator = $paginator =  $this->_helper->modelLoad('Players')->listAlliancePlayers(
                $this->idA, 
                $page,
                $this->_helper->modelLoad('Alliances')->getPlayersCount($this->idA),
                $sort,
                (int)$this->_getParam('count') );

        $page = $paginator->getCurrentPageNumber();
        
        $this->view->countPerPage = $paginator->getItemCountPerPage();
        $this->view->numbered = ($page - 1) * $paginator->getItemCountPerPage() + 1;

        $this->view->keywords = "{$this->view->nameAlliance}, Альянс, Игроки";
        $this->view->description = "Альянс {$this->view->nameAlliance}, список игроков (страница {$page})";
        $this->view->actTitle = "Список игроков, страница {$page}";

    }

    /*
     * статистика альянса
     */
    public function statAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'graph'), 'helpView', true );
        
        $this->view->idGraph = $idG = $this->_getParam('graph');
        
        $menu = array(
                'countP' => array(
                    'name' => 'Количество игроков',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'levelAvg' => array(
                    'name' => 'Средний уровень',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
                'rankSum' => array(
                    'name' => 'Общий рейтинг',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'rankAvg' => array(
                    'name' => 'Средний рейтинг',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'boSum' => array(
                    'name' => 'Общий БО',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'boAvg' => array(
                    'name' => 'Средний БО',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'raSum' => array(
                    'name' => 'Общий РА',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'raAvg' => array(
                    'name' => 'Средний РА',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'nraSum' => array(
                    'name' => 'Общий НРА',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'nraAvg' => array(
                    'name' => 'Средний НРА',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'archSum' => array(
                    'name' => 'Общая археология',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'archAvg' => array(
                    'name' => 'Средняя археология',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'buildSum' => array(
                    'name' => 'Общее строительство',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'buildAvg' => array(
                    'name' => 'Среднее строительство',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'scienSum' => array(
                    'name' => 'Общая наука',
                    'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true ),
                'scienAvg' => array(
                    'name' => 'Средняя наука',
                    'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                    'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                    'hideRase' => true )
        );

        if( !isset($menu[$idG]) ) 
            throw new Exception('Graph not found');        

        $this->view->keywords = "{$this->view->nameAlliance}, Альянс, Статистика, График, {$menu[$idG]['name']}";
        $this->view->description = "Альянс {$this->view->nameAlliance}, статистика - {$menu[$idG]['name']}";
        $this->view->actTitle = $menu[$idG]['name'];

        $this->view->opt = $menu[$idG];


        switch ($idG)
        {
            case 'countP':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getCountPlayers($this->idA, 'a');
                break;
            case 'levelAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgLevel($this->idA, 'a');
                break;
            case 'rankSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumRank($this->idA, 'a');
                break;
            case 'rankAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgRank($this->idA, 'a');
                break;
            case 'boSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumBO($this->idA, 'a');
                break;
            case 'boAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgBO($this->idA, 'a');
                break;
            case 'raSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumRA($this->idA, 'a');
                break;
            case 'raAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgRA($this->idA, 'a');
                break;
            case 'nraSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumNRA($this->idA, 'a');
                break;
            case 'nraAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgNRA($this->idA, 'a');
                break;
            case 'archSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumArch($this->idA, 'a');
                break;
            case 'archAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgArch($this->idA, 'a');
                break;
            case 'buildSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumBuild($this->idA, 'a');
                break;
            case 'buildAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgBuild($this->idA, 'a');
                break;
            case 'scienSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumScien($this->idA, 'a');
                break;
            case 'scienAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgScien($this->idA, 'a');
                break;
        }

        //сокращалка на "кк"
        if( is_null($this->view->opt['reduce']) ) {
            $reduce = Mylib_Utils::getReduce($this->view->data);

            if( $reduce != 0 )
                array_walk_recursive($this->view->data, 'Mylib_Utils::conversionReduce', $reduce);

            $this->view->opt['reduce'] = $reduce;
        }
    }

    /*
     * список колоний альянса
     */
    public function colonyAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'alliance_colony'), 'helpView', true );        
        
        $page = (int) $this->_getParam('page', 1);
        $this->view->sort = $sort = $this->_getParam('sort');

        $this->view->paginator = $paginator =  $this->_helper->modelLoad('Players')->listAllianceColony(
                $this->idA, $page, $sort, (int)$this->_getParam('count') );

        $page = $paginator->getCurrentPageNumber();
        
        $this->view->countPerPage = $paginator->getItemCountPerPage();
        $this->view->numbered = ($page - 1) * $paginator->getItemCountPerPage() + 1;

        $this->view->keywords = "{$this->view->nameAlliance}, Альянс, Колонии";
        $this->view->description = "Альянс {$this->view->nameAlliance}, список колоний (страница {$page})";
        $this->view->actTitle = "Список колоний, страница {$page}";

    }

    
}
