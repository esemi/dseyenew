<?php
/*
 * сборная солянка из экшенов для крона
 */
class CliController extends Zend_Controller_Action
{
    private 
        $_dshelpMap = null,
        $_onlineMap = null,
        $_log = null,
        $_csv = null,
        $_type = '', //тип лога, устанавливается каждый экшеном
        $_stopLog = false; //остановка логирования (true - остановить логи)
    
    public function init()
    {
        if ( APPLICATION_ENV != 'cli' )
            throw new Exception('Access denied');

        ob_start();
        
        $this->_log = new App_Model_CronlogMapper( );
        
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
    }

    /*
     * пишет логи куда надо
     */
    public function __destruct()
    {
        if( $this->_stopLog == false )
        {
            $this->_log->save( ob_get_clean(), $this->_type );
        }
    }
    

    /*
     * сборщик мусора и ротатор статистики
     */
    public function scavengerAction()
    {
        $this->_type = 'scavenger';
        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('scav');
        
        //удаляем старые логи антибрутфорса       
        $count = $this->_helper->modelLoad('Antibrut')->clearOld( $conf['antibrut'] );
        echo "Удалено {$count} логов антибрута";
        echo $this->_log->_getStat();        
        
        //удаляем старые логи крона
        $count = $this->_helper->modelLoad('CronLogs')->clearOld( $conf['cronlog'] );
        echo "Удалено {$count} логов крона";
        echo $this->_log->_getStat();

        //удаляем неактивированных юзеров и всё что с ними связано (внешние ключи InnoDB)
        $count = $this->_helper->modelLoad('Users')->clearOld( $conf['users'] );
        echo "Удалено {$count} неактивированных юзеров";
        echo $this->_log->_getStat();

        //удаляем старую статистику миров и альянсов
        $count = $this->_helper->modelLoad('StatGeneral')->clearOld( $conf['worldstat'] );
        echo "Удалено {$count} записей статистики альянсов и миров";
        echo $this->_log->_getStat();
        
        //удаляем старую статистику онлайна
        $count = $this->_helper->modelLoad('StatOnline')->clearOld( $conf['onlinestat'] );
        echo "Удалено {$count} записей статистики онлайна";
        echo $this->_log->_getStat();

        //удаляем переезды-переходы
        $countAll = $this->_helper->modelLoad('TransAlliance')->clearOld( $conf['worldstat'] );  
        $countGate = $this->_helper->modelLoad('TransGate')->clearOld( $conf['worldstat'] ); 
        list($countDom,$countMels) = $this->_helper->modelLoad('TransSots')->clearOld( $conf['worldstat'] );                
        printf("Удалено %d/%d/%d/%d записей переездов-переходов игроков (дом/мельс/ал/ворота)<br/>",
                $countDom, $countMels, $countAll, $countGate);
        echo $this->_log->_getStat();        
        
        //удаляем макс дельты игроков
        $countRank = $this->_helper->modelLoad('MaxDeltaRank')->clearOld( $conf['worldstat'] );
        $countBo = $this->_helper->modelLoad('MaxDeltaBo')->clearOld( $conf['worldstat'] );
        printf("Удалено %d/%d записей макс дельт игроков<br/>", $countRank, $countBo);
        echo $this->_log->_getStat();
               
        //удаляем старую статистику игроков
        $count = $this->_helper->modelLoad('StatPlayers')->clearOld( $conf['playerstat'] );
        echo "Удалено {$count} записей статистики игроков";
        echo $this->_log->_getStat();

        //запускаем ротацию статистики игроков
        $rotate = $this->getFrontController()->getParam('bootstrap')->getOption('rotate');

        //добавляем округлённые записи
        $count = $this->_helper->modelLoad('StatPlayers')->addRotated( $rotate['playerstat'] );
        echo "Добавлено " . $count->rowCount() . " округлённых записей статистики игроков";
        echo $this->_log->_getStat();

        //удаляем старые неокруглённые данные
        $count = $this->_helper->modelLoad('StatPlayers')->clearRotated( $rotate['playerstat'] );
        echo "Удалено {$count} неокруглённых записей статистики игроков";
        echo $this->_log->_getStat();

        //оптимизация таблиц
        $db = $this->getFrontController()->getParam('bootstrap')->getResource('db');
        $res = $db->query('OPTIMIZE TABLE 
            `alliances` , `cron_logs` , `feedback` ,  `form` , `news` , `players` , `players_colony` , 
            `players_trans_alliance` , `players_trans_colony` , `players_trans_dom` , `players_trans_gate` , 
            `rases` , `stat_general` , `stat_online` , `stat_players` , `todo` , `worlds`');
        echo "Таблицы оптимизированны";

    }
    

    /*
     * сборщик статистики по онлайну
     */
    public function onlinestatAction()
    {
        $this->_type = 'onlineStatus';

        $this->_onlineMap = new App_Model_OnlineMapper();

        $props = $this->_helper->modelLoad('GameVersions')->getAllForStat();
        
        foreach($props as $prop)
        {
            $count = $this->_onlineMap->getCurrentOnline($prop['id'], $prop['url']);            
            
            if($count === false)
            {
                var_dump($prop['url'], $this->_onlineMap->getErrors());
            }else{
                $this->_helper->modelLoad('StatOnline')->addStat($prop['id'], $count);
                echo "Версия {$prop['id']}, онлайн {$count} - данные добавлены<br>";                        
            }           
        }

    }


    /*
     * обновлялка собственных csv
     */
    public function csvAction()
    {
        $this->_type = 'csv';

        //получаем все живые миры
        $worlds = $this->_helper->modelLoad('Worlds')->getActive();

        //обновлять нечего
        if( is_null($worlds) )
            die('Миров для обновления не найдено.<br>');
        
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('csv');
        $this->_csv = new App_Model_MyCSV($prop['pagerlimit'], $prop['gziplevel']);

        foreach ($worlds as $world)
        {
            echo "Мир <b>{$world['name']}</b><br>";
            $nameW = mb_strtolower( str_replace(' ', '_', $world['name'] ), 'utf8');
            
            $this->_csv->createMain( $this->_helper->modelLoad('Players'), $world['id'], "{$nameW}_main" );
            echo "Основные csv обновлены<br/>";
            
            $this->_csv->createStat( $this->_helper->modelLoad('StatPlayers'), $world['id'], "{$nameW}_stat" );
            echo "Статистика в csv обновлена<br/>";
        }
    }
    
    
    
    /*
     * обновление РА игроков одого мира
     */
    public function dshelpraAction()
    {
        $this->_type = 'dshelpRA';        

        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('cronupd');

        //пробуем получить мир для обновения ()
        $world = $this->_helper->modelLoad('Worlds')->getOldRaWorld( $prop['ra'] );
        
        //обновлять нечего
        if( is_null($world) )
            die('Миров для обновления не найдено.<br>');
           
        
        echo "Мир <b>{$world['dshelp_name']}</b><br>";

        $this->_dshelpMap = new App_Model_DshelpMapper( $world['dshelp_name'] );
        
        $countUpd = 0; // количество обновлённых игроков
        $countParse = 0; // количество отпарсеных игроков
        
        //цикл по страницам, пока оные не кончатся (max = 200 pages)
        for($i=0;$i<200;$i++)
        {    
            echo "страница <b>{$i}</b><br>";
            
            //получаем исходник
            $source = $this->_dshelpMap->getPageSource($i);            
            if( $source === false )
            {
                echo "недоступна<br>";
                continue;
            }
            
            //парсим на строки с игроками
            $table = $this->_dshelpMap->parsePlayersPage($source);
            if( count($table) <= 4 )
            {
                echo "пуста и неинтересна<br>";
                break;                
            }
            $t = count($table);
            echo "получено {$t} строк таблички<br>";
            
            //построчно парсим на ник-ра
            for($j=2;$j<$t-2;$j++)
            {
                $res = $this->_dshelpMap->parsePlayersStr($table[$j]);                
                
                if( $res !== false )
                {
                    echo "игрок {$res[0]} ";

	            $countParse++;
                    //обновляем игрока в БД
                    $result = $this->_helper->modelLoad('Players')->updateRA( $res[0], $res[1], $world['id'] ); 
                    //проверка на обновление
                    
                    if( $result == 1 )
                    {
                        $countUpd++;
                        echo 'обновлён<br/>';
                    }else{
                        echo 'релевантен<br/>';
                    }
                }else{                    
                    var_dump(htmlentities($table[$j], ENT_COMPAT, 'UTF-8')); echo '<br>';
                }
            }            
            
        }

        //успешно завершили
        $this->_helper->modelLoad('Worlds')->raStatusUpd( $world['id'] );
        
        echo "Обновлено {$countUpd} из {$countParse} отпарсеных за {$i} страниц игроков. Всего в мире {$world['count']} игроков.<br> ";        
        echo 'Ошибки cURL<br>';
        var_dump($this->_dshelpMap->getErrors());
    }
        
    
    /*
     * обновление новых рейтинов игроков одного мира
     */
    public function newranksAction()
    {
        $this->_type = 'newRanks';        

        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('cronupd');

        //пробуем получить мир для обновения 
        $world = $this->_helper->modelLoad('Worlds')->getOldRanksWorld( (int)$prop['ranks'] );
                
        //обновляем у найденного дату и статус
        if( !is_null($world) )
            $this->_helper->modelLoad('Worlds')->newRanksStatusUpd( $world['id'], 'process' );
        else
            die('Миров для проверки не найдено.<br>');
                
           
        $this->_ranksMap = new App_Model_NewRanksMapper($world['url']);
        
        echo "Мир <b>{$world['name']}</b><br>";

        $countUpd = 0; // количество обновлённых игроков
        $countParse = 0; // количество отпарсеных игроков
        
        //цикл по страницам, пока оные не кончатся (max = 200 pages)
        for($i=1;$i<200;$i++)
        {    
            echo "страница <b>{$i}</b><br>";
            
            //получаем исходник
            $source = $this->_ranksMap->getPageSource($i);            
            if( $source === false )
            {
                echo "недоступна<br>";
                continue;
            }
                       
            //получаем строки с игроками
            $trs = $this->_ranksMap->parsePlayers($source);
            if( count($trs) == 0 )
            {
                echo "пуста и неинтересна<br>";
                break;                
            }
            echo "получено " . count($trs) . " строк с игроками<br>";
            
            //построчно парсим на параметры
            foreach($trs as $item)
            {
                $data = $this->_ranksMap->parsePlayerStr($item); 
               
                if( $data !== false )
                {
	            $countParse++;
                    //обновляем игрока в БД
                    $result = $this->_helper->modelLoad('Players')->updateNewRanks( $data, $world['id'] ); 
                    //проверка на обновление
                    if( $result == 1 ) 
                    {
                        $countUpd++;
                        echo 'обновлён <br/>';
                    }else{                        
                        echo 'релевантен <br/>';
                    }
                }else{
                    echo '<br/>';
                }
            }            
            
        }

        //успешно завершили
        $this->_helper->modelLoad('Worlds')->newRanksStatusUpd( $world['id'], 'wait' );
        
        echo "Обновлено {$countUpd} из {$countParse} отпарсеных за {$i} страниц игроков. Всего в мире {$world['count']} игроков.<br> ";        
        echo 'Ошибки cURL<br>';
        var_dump($this->_ranksMap->getErrors());
    }
    

    /*
     * обновление основных рейтингов игроков одного мира
     */
    public function mainupdateAction()
    {
        
    }
       
    
    /*
     * обновление статистики миров и альянсов
     */
    public function generalstatAction()
    {
        
    }
}
