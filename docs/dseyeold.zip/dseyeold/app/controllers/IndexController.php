<?php

class IndexController extends Zend_Controller_Action
{
    public function indexAction()
    {
        $this->view->title = "Главная";    

        //последние новости
        $this->view->lastNews = $this->_helper->modelLoad('News')->listAll();
        
        //живой график                
        $props = $this->_helper->modelLoad('GameVersions')->getByName(array('classic', 'unlim'));
        $this->view->liveGraph = new stdClass();
        foreach($props as $prop)
            $this->view->liveGraph->{$prop['name']} = $this->_helper->modelLoad('StatOnline')->getLastVal($prop['id']);                            
    }


    /*
     * мануал по проекту
     * можно передавать якорь на нужный раздел
     */
    public function helpAction()
    {
        $this->view->keywords = 'Справка, faq, вопросы, проблемы';
        $this->view->description = 'Краткий экскурс по основным возможностям и инстукция по использованию системы';
        $this->view->title = "Описание основных возможностей системы";

        //настройки системы
        $boot = $this->getFrontController()->getParam('bootstrap');
        $this->view->scav = $boot->getOption('scav');
        $this->view->delta = $boot->getOption('deltaMax');
        $this->view->limits = $boot->getOption('limits');
    }


    public function aboutAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'about'), 'helpView', true );
        
        $this->view->keywords = 'О проекте';
        $this->view->description = 'Описание проекта';
        $this->view->title = "О проекте";

        //todo список
        $this->view->todoList = $this->_helper->modelLoad('Todo')->listAll();

        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut'); 
        $this->view->expIP = $this->_helper->modelLoad('Antibrut')->checkIP( 'feedback', $this->_request->getClientIp(), $prop['feedback']['try'], $prop['feedback']['minutes']);        
        
        //feedback список
        $this->view->feedbackList = $this->_helper->modelLoad('Feedback')->listAll();        

        //настройки системы
        $boot = $this->getFrontController()->getParam('bootstrap');
        $this->view->botName = $boot->getOption('botname');
        $this->view->scav = $boot->getOption('scav');
        $this->view->rotate = $boot->getOption('rotate');
        $this->view->delta = $boot->getOption('deltaMax');
    }


    public function contactAction()
    {
        $this->view->keywords = 'Контакты';
        $this->view->description = 'Контакты';
        $this->view->title = "Контакты";
                 
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut'); 
        $this->view->expIP = $this->_helper->modelLoad('Antibrut')->checkIP( 'form', $this->_request->getClientIp(), $prop['form']['try'], $prop['form']['minutes']);        
    }

    
    /*
     * просмотр одной новости либо списка всех новостей
     * новости по дефолту скрыты
     * если передан параметр якоря то яваскрипт откроет нужную новость
     */
    public function newsAction()
    {
        $this->view->keywords = 'Новости';
        $this->view->description = 'Новости проекта';
        $this->view->title = "Новости проекта";
        
        $this->view->news = $this->_helper->modelLoad('News')->listAll();
    }

    /*
     * лента новостей в формате atom 
     */
    public function newsfeedAction()
    {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $news = $this->_helper->modelLoad('News')->listAll();

        //описание фида (для импорта отдельный формат)
        //http://framework.zend.com/manual/en/zend.feed.importing.html
        $feedArray = array(
            'title'       => 'Новости DSeye.ru',
            'link'        => $this->view->url(array( ), 'newsRss', true),
            'charset'     => 'UTF-8',
            'description' => 'Новости DSeye.ru - анализатора онлайн игры Destiny Sphere.',
            'email'       => 'support@dseye.ru',
            'entries'     => array()
        );

        //добавляем записи в фид
        foreach ($news as $item)
        {
            $feedArray['entries'][] = array(
                'title'       => $item['title'],
                'link'        => $this->view->url(array( 'idN' => $item['id'] ), 'newsView', true),
                'description' => $item['desc'],
                'content'     => $item['text'],
                'lastUpdate'  => $item['date_unix']
            );
        }

        Zend_Feed::importArray($feedArray, 'atom')->send();
    }

}





