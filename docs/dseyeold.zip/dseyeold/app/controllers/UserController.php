<?php

/*
 * контроллер профиля юзера
 * 
 */
class UserController extends Zend_Controller_Action
{

    protected 
        $_users = null,
        $_history = null,
        $_usersSearch = null;

    /*
     * профиль
     */
    public function profileAction()
    {
        $this->_helper->checkAccess('profile','view','redirect');
                
        $user = Zend_Auth::getInstance()->getStorage()->read();

        $this->view->title = "Личный кабинет пользователя {$user->login}";
        $this->view->keywords = "Профиль, Личный кабинет, {$user->login}";
        $this->view->description = "Личный кабинет пользователя {$user->login}";

        //доступ к изменению пароля
        $this->view->accessEdit = $this->_helper->checkAccess('profile','edit');        
        
        //Личные данные
        $this->view->user = $this->_helper->modelLoad('Users')->getInfo( $user->id );        
        
        //История юзера
        $this->view->history = $this->_helper->modelLoad('UsersHistory')->lastOf( $user->id, 5 );

        //Автопоиск юзера
        if( $this->_helper->checkAccess('autosearch','view') )
        {
            $this->view->autoSearchList = $this->_helper->modelLoad('UsersSearch')->lastOf( $user->id, 10 );
        }
    }


    /*
     * история действий юзера с пагинацией и полными данными
     */
    public function historyAction()
    {
        $this->_helper->checkAccess('profile','view','redirect');

        $this->view->user = $user = Zend_Auth::getInstance()->getStorage()->read();

        $this->view->title = "История действий пользователя {$user->login}";
        $this->view->keywords = "Профиль, Личный кабинет, История действий, {$user->login}";
        $this->view->description = "История действий пользователя {$user->login}";

        $this->view->paginator = $paginator =  $this->_helper->modelLoad('UsersHistory')->listAll(
                $user->id,
                (int) $this->_getParam('page'),
                (int) $this->_getParam('count') );

        $this->view->countPerPage = $paginator->getItemCountPerPage();



    }

    /*
     * все записи автопоиска юзера
     */
    public function autosearchAction()
    {
        $this->_helper->checkAccess('autosearch','view','redirect');

        $this->view->user = $user = Zend_Auth::getInstance()->getStorage()->read();

        $this->view->title = "Автопоиск пользователя {$user->login}";
        $this->view->keywords = "Автопоиск, Личный кабинет, История действий, {$user->login}";
        $this->view->description = "Автопоиск (сохранённые настройки поиска) пользователя {$user->login}";

        $this->view->accessDelete = $this->_helper->checkAccess('autosearch','del');

        $this->view->autoSearchList = $this->_helper->modelLoad('UsersSearch')->listAll( $user->id );
    }

    /*
     * редирект на поиск с сохранёнными настройками
     */
    public function autosearchfindAction()
    {
        $this->_helper->checkAccess('autosearch','view','redirect');

        $this->view->user = $user = Zend_Auth::getInstance()->getStorage()->read();

        //ищем данные по поиску (заодно проверяем принадлежность)
        $data = $this->_helper->modelLoad('UsersSearch')->getOne( $this->_getParam('idA'), $user->id  );

        if( is_null($data) )
            throw new Exception('Некорректный идентификатор поиска.');

        //подготовим данные
        $prop = unserialize($data['prop']);
        $sort = ($prop !== false ) ? $prop->sort : '';

        //редиректим
        $this->_helper->redirector->gotoRoute(
                array(
                    'idW' => $data['id_world'],
                    'save' => urlencode($data['prop']),
                    'sort' => $sort ),
                'worldSearch', true);
    }

    public function monitoringAction()
    {
        $this->_helper->checkAccess('autosearch','view','redirect');
        
    }
    
}





