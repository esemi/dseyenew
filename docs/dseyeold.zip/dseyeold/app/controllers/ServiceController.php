<?php

class ServiceController extends Zend_Controller_Action
{
    public function init()
    {
        $this->view->title = 'Сервисы';
    }

    /*
     * график онлайна за всё время
     */
    public function onlineAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'service_online'), 'helpView', true );
        
        $this->view->keywords = 'Сервисы, Статистика';
        $this->view->description = "Статистика игроков онлайн";        
        $this->view->actTitle = 'Статистика игроков онлайн';

        $this->view->menu = $this->_helper->modelLoad('GameVersions')->getAllForStat();

    }


    /*
     * глобальный поиск игроков по нику (во всех мирах)
     */
    public function searchAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'fast_search'), 'helpView', true );
        
        $this->view->keywords = 'Поиск, Поиск игроков';
        $this->view->description = 'Поиск игроков по всем мирам';
        $this->view->actTitle = 'Глобальный поиск игроков';

        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('limits');
        $this->view->limitFast = $conf['fastSearch'];
    }

    /*
     * инструменты для разработчиков
     */
    public function devAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'dev'), 'helpView', true );
        
        $this->view->keywords = 'Инструменты, Разработка, API';
        $this->view->description = 'Описание инструментов для сторонних разработчиков';
        $this->view->title = 'Инструменты разработчиков';


    }

    /*
     * кластеризация
     */
    public function clustersAction()
    {
        $this->view->keywords = 'Кластеры, Анализ, Кластеризация, Статистика, Выделение групп';
        $this->view->description = 'Кластерный анализ игроков по внутриигровым параметрам';
        $this->view->title = 'Кластерный анализ игроков';
    }

    
    /*
     * рассчёт веса армии и времени раунда
     */
    public function armyAction()
    {
        $this->view->keywords = 'Рассчёт, Вес армии, Время раунда, Время боя, Калькулятор';
        $this->view->description = 'Сервис рассчёта веса армии и времени раунда';
        $this->view->title = 'Военный калькулятор (вес армии, время раунда)';
    }
}
