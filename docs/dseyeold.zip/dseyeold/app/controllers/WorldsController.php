<?php

/*
 * контроллер основного меню (по мирам)
 */

class WorldsController extends Zend_Controller_Action
{

    protected $idW = null;

    public function init()
    {        
        if( $this->_helper->modelLoad('Worlds')->validate((int) $this->_getParam('idW')) !== true ) 
            throw new Exception('World id is not valid');        
        $this->view->idWorld = $this->idW = (int) $this->_getParam('idW');

        //имя мира
        $this->view->nameWorld = $this->_helper->modelLoad('Worlds')->getName($this->idW);
        $this->view->title = "Мир {$this->view->nameWorld}";
                
        $this->view->rubberPage = true;//резиновый шаблон
    }

    /*
     * вывод общей инфы по конкретному миру
     */
    public function indexAction()
    {        
        $this->view->keywords = "{$this->view->nameWorld}, Мир, Описание, Показатели";
        $this->view->description = "Мир {$this->view->nameWorld}, описание и основные показатели";
        $this->view->actTitle = 'О мире';

        //текущие параметры мира
        $this->view->dataWorld = $data = $this->_helper->modelLoad('Worlds')->getCurProperty($this->idW);     
        if( $data == false )
            throw new Exception('World property not found');
        
        $this->view->input = $this->_helper->modelLoad('Players')->getInputWorld($this->idW);
        $this->view->output = $this->_helper->modelLoad('Players')->getOutputWorld($this->idW);
        
        $this->view->transSots = $this->_helper->modelLoad('TransSots')->getTransByWorld($this->idW);
        $this->view->transGate = $this->_helper->modelLoad('TransGate')->getTransByWorld($this->idW);
        $this->view->transAlliance = $this->_helper->modelLoad('TransAlliance')->getTransByWorld($this->idW);
        $this->view->maxRankDelts = $this->_helper->modelLoad('MaxDeltaRank')->getDeltsByWorld($this->idW);
        $this->view->maxBoDelts = $this->_helper->modelLoad('MaxDeltaBo')->getDeltsByWorld($this->idW);
        
    }

    /*
     * История изменений параметров игроков мира по дням
     * @TODO DateTime php >= 5.3
     */
    public function historyAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'world_history'), 'helpView', true );
        
        $this->view->curDate = $selectDate = $this->_getParam('date');      
                
        $this->view->keywords = "{$this->view->nameWorld}, Мир, История, Изменения";
        $this->view->description = "Мир {$this->view->nameWorld}, изменения за {$selectDate}";
        $this->view->actTitle = "История изменений за {$selectDate}";

        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('scav');
        $this->view->minDate = $minDate = $this->_helper->modelLoad('Worlds')->getMinStatDate($this->idW, $conf['worldstat']);
        $this->view->maxDate = $maxDate = date('d-m-Y');
        
        $curDate = strtotime($selectDate);
        
        //слишком старая дата
        if( $curDate < strtotime($minDate) ) 
            $this->_redirect($this->view->url(array( 'idW' => $this->idW, 'date' => $minDate), 'worldHistory', true), array('code' => 301));            
                
        //дата из будущего
        if( $curDate > strtotime($maxDate) ) 
            $this->_redirect($this->view->url(array('idW' => $this->idW), 'worldHistory', true));            
        
        //есть ли куда двигаться в прошлое?
        if( strtotime('-1 day',$curDate) >= strtotime($minDate) )
            $this->view->prevDate = date('d-m-Y', strtotime('-1 day',$curDate));
        
        //можно ли двигаться в будущее?
        if( strtotime('+1 day',$curDate) <= strtotime($maxDate) )
            $this->view->nextDate = date('d-m-Y', strtotime('+1 day',$curDate));
        
        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('limits');
        $this->view->limit = $conf['history'];
   
        
        $this->view->input = $this->_helper->modelLoad('Players')->getInputWorld($this->idW, $selectDate, false, $conf['history']);
        $this->view->output = $this->_helper->modelLoad('Players')->getOutputWorld($this->idW, $selectDate, false, $conf['history']);
        
        $this->view->transSots = $this->_helper->modelLoad('TransSots')->getTransByWorld($this->idW, $selectDate, false, $conf['history']);
        $this->view->transGate = $this->_helper->modelLoad('TransGate')->getTransByWorld($this->idW, $selectDate, false, $conf['history']);
        $this->view->transAlliance = $this->_helper->modelLoad('TransAlliance')->getTransByWorld($this->idW, $selectDate, false, $conf['history']);
        $this->view->maxRankDelts = $this->_helper->modelLoad('MaxDeltaRank')->getDeltsByWorld($this->idW, $selectDate, false, $conf['history']);
        $this->view->maxBoDelts = $this->_helper->modelLoad('MaxDeltaBo')->getDeltsByWorld($this->idW, $selectDate, false, $conf['history']);
    }


    /*
     * вывод статистики по миру
     * graph - номер графика в меню, по умолчанию ноль
     */
    public function statAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'graph'), 'helpView', true );
        $this->view->idGraph = $idG = $this->_getParam('graph');        
        
        $menu = array(
            'InOutDay' => array(
                'name' => 'Пришли/ушли за месяц',
                'type' => 'bar', 'reduce' => 0, 'count' => 2, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Пришли', 'Ушли' ) ),
            'InOutAll' => array(
                'name' => 'Пришли/ушли за всё время',
                'type' => 'bar', 'reduce' => 0, 'count' => 2, 'dateFormat' => '%m.%Y',
                'series' => array( 'Пришли', 'Ушли' ) ),
            'levelAvg' => array(
                'name' => 'Средний уровень',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Общий', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'countP' => array(
                'name' => 'Количество игроков',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true ),
            'countC' => array(
                'name' => 'Количество колоний',
                'type' => 'line', 'reduce' => 0, 'count' => 1, 'dateFormat' => '%d.%m.%Y',
                'series' => array( ) ),
            'countA' => array(
                'name' => 'Количество альянсов',
                'type' => 'line', 'reduce' => 0, 'count' => 1, 'dateFormat' => '%d.%m.%Y',
                'series' => array( ) ),
             'rankSum' => array(
                'name' => 'Общий рейтинг',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true  ),
            'rankAvg' => array(
                'name' => 'Средний рейтинг',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'boSum' => array(
                'name' => 'Общий БО',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true  ),
            'boAvg' => array(
                'name' => 'Средний БО',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'raSum' => array(
                'name' => 'Общий РА',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true  ),
            'raAvg' => array(
                'name' => 'Средний РА',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'nraSum' => array(
                'name' => 'Общий НРА',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true ),
            'nraAvg' => array(
                'name' => 'Средний НРА',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'archSum' => array(
                'name' => 'Общая археология',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true ),
            'archAvg' => array(
                'name' => 'Средняя археология',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'buildSum' => array(
                'name' => 'Общее строительство',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true ),
            'buildAvg' => array(
                'name' => 'Среднее строительство',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) ),
            'scienSum' => array(
                'name' => 'Общая наука',
                'type' => 'line', 'reduce' => null, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ),
                'hideRase' => true ),
            'scienAvg' => array(
                'name' => 'Средняя наука',
                'type' => 'line', 'reduce' => 0, 'count' => 4, 'dateFormat' => '%d.%m.%Y',
                'series' => array( 'Всего', 'Воранеры', 'Лиенсу', 'Псолао' ) )        
        );        

        if( !isset($menu[$idG]) )
            throw new Exception('Graph not found');


        $this->view->keywords = "{$this->view->nameWorld}, Мир, Статистика, График, {$menu[$idG]['name']}";
        $this->view->description = "Мир {$this->view->nameWorld}, статистика - {$menu[$idG]['name']}";
        $this->view->actTitle = $menu[$idG]['name'];
        
        $this->view->opt = $menu[$idG];

        switch ($idG)
        {
            case 'InOutDay':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getLastIO($this->idW);
                break;
            case 'InOutAll':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAllIO($this->idW);
                break;
            case 'levelAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgLevel($this->idW);
                break;
            case 'countP':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getCountPlayers($this->idW);
                break;
            case 'countC':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getCountColonies($this->idW);
                break;
            case 'countA':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getCountAlliances($this->idW);
                break;
            case 'rankSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumRank($this->idW);
                break;
            case 'rankAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgRank($this->idW);
                break;
            case 'boSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumBO($this->idW);
                break;
            case 'boAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgBO($this->idW);
                break;
            case 'raSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumRA($this->idW);
                break;
            case 'raAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgRA($this->idW);
                break;
            case 'nraSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumNRA($this->idW);
                break;
            case 'nraAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgNRA($this->idW);
                break;
            case 'archSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumArch($this->idW);
                break;
            case 'archAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgArch($this->idW);
                break;
            case 'buildSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumBuild($this->idW);
                break;
            case 'buildAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgBuild($this->idW);
                break;
            case 'scienSum':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getSumScien($this->idW);
                break;
            case 'scienAvg':
                $this->view->data = $this->_helper->modelLoad('StatGeneral')->getAvgScien($this->idW);
                break;
        }

        //сокращалка на "кк"
        if( is_null($this->view->opt['reduce']) ) {
            $reduce = Mylib_Utils::getReduce($this->view->data);

            if( $reduce != 0 )
                array_walk_recursive($this->view->data, 'Mylib_Utils::conversionReduce', $reduce);

            $this->view->opt['reduce'] = $reduce;
        }
    }

    /*
     * листинг игроков мира
     */
    public function playersAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'lists'), 'helpView', true );
        $page = (int) $this->_getParam('page', 1);
        $this->view->sort = $sort = $this->_getParam('sort');
        $limit = (int)$this->_getParam('count');

        $count = $this->_helper->modelLoad('Worlds')->getPlayersCount($this->idW);
        $this->view->paginator = $paginator = $this->_helper->modelLoad('Players')->listWorldPlayers(
                $this->idW, $page, $count, $sort, $limit );

        $page = $paginator->getCurrentPageNumber();
        
        $this->view->countPerPage = $paginator->getItemCountPerPage();

        $this->view->numbered = ($page - 1) * $paginator->getItemCountPerPage() + 1;

        $this->view->keywords = "{$this->view->nameWorld}, Мир, Игроки";
        $this->view->description = "Мир {$this->view->nameWorld}, список игроков (страница {$page})";
        $this->view->actTitle = "Список игроков, страница {$page}";
    }

    /*
     * листинг алов мира
     */
    public function alliancesAction()
    {
        $this->view->helpLink = $this->view->url( array('id'=>'lists'), 'helpView', true );
        
        $page = (int) $this->_getParam('page', 1);
        $this->view->sort = $sort = $this->_getParam('sort');

        $count = $this->_helper->modelLoad('Worlds')->getAllianceCount($this->idW);
        $this->view->paginator = $paginator = $this->_helper->modelLoad('Alliances')->listWorldAlliances(
                $this->idW, $page, $count, $sort, (int)$this->_getParam('count'));

        $page = $paginator->getCurrentPageNumber();
        
        $this->view->countPerPage = $paginator->getItemCountPerPage();
        $this->view->numbered = ($page - 1) * $paginator->getItemCountPerPage() + 1;

        $this->view->keywords = "{$this->view->nameWorld}, Мир, Альянсы";
        $this->view->description = "Мир {$this->view->nameWorld}, список альянсов (страница {$page})";
        $this->view->actTitle = "Список альянсов, страница {$page}";
    }

    /*
     * форма поиска и расширенного поиска + запоминалка ссылки
     * @TODO рассы в форме из БД
     *
     */
    public function searchAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'full_search'), 'helpView', true );        
        $this->view->rubberPage = false;

        $this->view->keywords = "{$this->view->nameWorld}, Мир, Игроки, Поиск, Кормушки";
        $this->view->description = "Мир {$this->view->nameWorld}, поиск игроков и кормушек по миру";
        $this->view->actTitle = "Поиск игроков";

        $this->view->searchProp = new stdClass();
        
        //получаем максимальные значения критериев (для слайдера)
        $maxParams = array();
        $maxParams = $this->_helper->modelLoad('Players')->getMaxRanks( $this->idW );
        $maxParams['compl'] = $this->_helper->modelLoad('Worlds')->getGreatCompl( $this->idW );
        $this->view->maxParams = $maxParams;

        $conf = $this->getFrontController()->getParam('bootstrap')->getOption('limits');
        $this->view->limitFast = $conf['fastSearch'];


        //получаем id-name альянсов для фильтра
        $this->view->filterAlliances = $this->_helper->modelLoad('Alliances')->getFilterAlliance( $this->idW, 20 );
        
        
        if( $this->_request->isPost() )
        {
            $searchProp = $this->_parseForm();
        }elseif( $this->_getParam('save') != 'new' ){        
            $save = @urldecode($this->_getParam('save'));
            $save = @unserialize($save);
            
            if( $save === false ||  $this->_helper->modelLoad('Players')->issetValues($save) !== true )
            {
                $this->view->error = 'Ваша ссылка испортилась =( Надо поиск повторить и новую ссылку сохранить.';
            }else{
                $searchProp = $save;
            }        
        }


        //настройки откуда то взялись
        if( isset($searchProp) )
        {
            //сворачиваем настройки
            $this->view->post = true;
            
            //валидируем объект настроек
            if( $this->_helper->modelLoad('Players')->validateForm( $searchProp ) === false )
            {
                $this->view->error = 'Некоторые поля заполненны ошибочно. Повторите поиск или сообщите разработчикам.';
            }else{
                //лимит игроков
                $this->view->limitFull = $limit = ($this->_helper->checkAccess('others','searchLimitX2'))
                        ? 2 * $conf['fullSearch'] : $conf['fullSearch'];

                //сортировка
                $this->view->sort = $sort = $this->_getParam('sort');

                //выполняем поиск
                $this->view->players = $this->_helper->modelLoad('Players')->fullSearch( $this->idW, $searchProp, $sort, $limit );

                //передаём настройки для построения формы
                $this->view->searchProp = $searchProp;

                //создаём ссылку для запоминания
                $this->view->saveLink = urlencode(serialize($searchProp));


                //ссылка для запоминания в автопоиске игрока
                if( $this->_helper->checkAccess('autosearch','add') )
                {
                    $user = Zend_Auth::getInstance()->getStorage()->read();

                    //составим хеш для хранения в автопоиске
                    $tmp = $searchProp;
                    $tmp->sort = $sort;
                    $this->view->autoSearchProp = urlencode(serialize($tmp));

                    //получим записи
                    $this->view->autoSearchNames = $this->_helper->modelLoad('UsersSearch')->getUserList( $user->id, $this->idW );

                    //var_dump($this->view->autoSearchNames);
                }

            }
        }
        
    }


    /*
     * вывод карты мира
     */
    public function mapAction()
    {        
        $this->view->helpLink = $this->view->url( array('id'=>'world_map'), 'helpView', true );        
        
        $this->view->keywords = "{$this->view->nameWorld}, Мир, Карта, Кольца, Карта колец";
        $this->view->description = "Мир {$this->view->nameWorld}, интерактивная карта колец";
        $this->view->actTitle = "Карта колец";

        //получаем макс компл на этом кольце
        $this->view->numMax = $maxNum = $this->_helper->modelLoad('Worlds')->getMaxComple($this->idW, 4);
        if( $maxNum == 0 || $maxNum === false ) 
            throw new Exception('Max compl for this world is undefined.');      
        
        //получаем значения раскрасски по умолчанию
        $this->view->ranks = $ranks = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('map');
        if( count($ranks) != 5)
            throw new Exception( 'Ranks unvalid' );        
    }



    /*
     * парсим форму поиска в объект настроек (без валидации)      
     * @return stdClass of saved preferences search
     */
    protected function _parseForm()
    {
        $saveProp = new stdClass();
        $saveProp->gate = $this->_request->getPost('gate');
        $saveProp->ring = $this->_request->getPost('ring');
        $saveProp->liga = $this->_request->getPost('liga');
        $saveProp->rase = $this->_request->getPost('rase');

        $saveProp->alliance = $this->_request->getPost('alliance');
        $saveProp->filterAlliance = $this->_request->getPost('filter_alliance');
        $saveProp->filterAllianceMod = $this->_request->getPost('filter_alliance_mod');
        
        $saveProp->complMin = $this->_request->getPost('compl_min');
        $saveProp->complMax = $this->_request->getPost('compl_max');

        $saveProp->rankMin  = $this->_request->getPost('rank_min');
        $saveProp->rankMax  = $this->_request->getPost('rank_max');

        $saveProp->boMin    = $this->_request->getPost('bo_min');
        $saveProp->boMax    = $this->_request->getPost('bo_max');

        $saveProp->raMin    = $this->_request->getPost('ra_min');
        $saveProp->raMax    = $this->_request->getPost('ra_max');

        $saveProp->nraMin   = $this->_request->getPost('nra_min');
        $saveProp->nraMax   = $this->_request->getPost('nra_max');

        $saveProp->levelMin = $this->_request->getPost('level_min');
        $saveProp->levelMax = $this->_request->getPost('level_max');

        $saveProp->archMin  = $this->_request->getPost('arch_min');
        $saveProp->archMax  = $this->_request->getPost('arch_max');

        $saveProp->buildMin = $this->_request->getPost('build_min');
        $saveProp->buildMax = $this->_request->getPost('build_max');

        $saveProp->scienMin = $this->_request->getPost('scien_min');
        $saveProp->scienMax = $this->_request->getPost('scien_max');

        return $saveProp;
    }


}
