<?php

/*
 * хелпер для передачи списка миров во вьюшник
 * 
 */
class Action_Helper_WorldsListing extends Zend_Controller_Action_Helper_Abstract
{
    public function preDispatch()
    {
        if( !$this->getRequest()->isXmlHttpRequest() )
        {
            $worlds = new App_Model_DbTable_Worlds();
            $this->getActionController()->view->listWorlds = $worlds->listing();
        }
    }

}
