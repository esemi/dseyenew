<?php

/*
 * контроллер для всех ajax запросов
 *
 */

class AjaxController extends Zend_Controller_Action
{

    protected 
        $_onlineMap = null,
        $_dshelpMap = null;
    
    private 
        $_notLoggedActions = array('userpassedit'),
        $_log = null;
    

    public function init()
    {   
        $this->_log = $this->getInvokeArg('bootstrap')->getResource('Log');        
        
        //только аякс запросы
        if( !$this->_request->isXmlHttpRequest() )
            throw new Exception('AJAX only');

        //проверка на реферер
        $url = $this->view->serverUrl();
        if( $url !== substr($this->_request->getServer('HTTP_REFERER', ''), 0, strlen($url) ) )
            throw new Exception('AJAX referer');

        //логирование всех запросов, кроме секурных
        if( !in_array($this->_request->getActionName(), $this->_notLoggedActions) )
            $this->_addAjaxLog();
       

        $this->_helper->getHelper('AjaxContext')
                            ->addActionContext('map', 'json')
                            ->addActionContext('feedback', 'json')
                            ->addActionContext('form', 'json')
                            ->addActionContext('online', 'json')
                            ->addActionContext('playerinfo', 'json')
                            ->addActionContext('userpassedit', 'json')
                            ->addActionContext('monitoradd', 'json')
                            ->addActionContext('monitordel', 'json')
                            ->addActionContext('autosearchsavenew', 'json')
                            ->addActionContext('autosearchsaveas', 'json')
                            ->addActionContext('autosearchdel', 'json')
                            ->addActionContext('search', 'html')
                            ->addActionContext('graphplayer', 'json')
                            ->addActionContext('graphonline', 'json')
                            ->initContext();                            
    }


    /*
     * добавление лога запроса
     */
    private function _addAjaxLog()
    {        
        $this->_log->ajax(
                  $this->_request->getClientIp()
                . ' '
                . $this->_request->getRequestUri()
                . ' '
                . $this->_request->getServer('HTTP_REFERER', '')
                . ' '
                . serialize($this->_request->getPost())
                . ' '
                . $this->_request->getServer('HTTP_USER_AGENT', '')
                );
    }

    /*
     * добавление лога ошибки CSRF токена
     */
    private function _addCsrfLog()
    {        
        $this->_log->csrf(
                  $this->_request->getClientIp()
                . ' '
                . $this->_request->getRequestUri()
                . ' '
                . $this->_request->getServer('HTTP_REFERER', '')
                . ' '
                . serialize($this->_request->getPost())
                . ' '
                . $this->_request->getServer('HTTP_USER_AGENT', '')
                );
    }
    
    /*
     * добавление лога странной ошибки
     */
    private function _addErrorLog()
    {     
        $error = (isset($this->view->error)) ? $this->view->error : 'Undefined error';
        $this->_log->error(
                  $this->_request->getClientIp()
                . ' '
                . $this->_request->getRequestUri()
                . ' '
                . $error
                . ' '
                . $this->_request->getServer('HTTP_REFERER', '')
                . ' '
                . serialize($this->_request->getPost())
                . ' '
                . $this->_request->getServer('HTTP_USER_AGENT', '')
                );
    }

    /*
     * Добавление игрока в мониторинг
     */
    public function monitoraddAction()
    {
        if( !$this->_helper->checkAccess('monitoring','manage') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }

        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }
        
        //проверим ид игрока
        $idP = (int)$this->_request->getPost('idP');
        if( !$this->_helper->modelLoad('Players')->validate($idP) )
        {
            $this->view->error = 'Некорректный идентификатор игрока.';
            $this->_addErrorLog();
            return;
        }
        
        //добавляем игрока в мониторинг, если его там нет
        $player = $this->_helper->modelLoad('Players')->getInfo($idP);                
        $user = Zend_Auth::getInstance()->getStorage()->read();
                               
        if( $this->_helper->modelLoad('MonitorItems')->issetByUser($idP, $user->id) )
        {
            $this->view->error = 'Данный игрок уже добавлен в мониторинг';
            $this->_addErrorLog();
            return;
        }       
        
        $this->_helper->modelLoad('MonitorItems')->add( $idP, $user->id );
        
        $this->_helper->modelLoad('UsersHistory')->add( 
                $user->id, 
                $this->view->partial( 'Partials/history/monitorAddPlayer.phtml', array( 'player' => $player ) ), 
                $this->_request);
        $this->view->html = $this->view->partial( 'Partials/message/monitorAddPlayer.phtml', array( 'idP' => $idP ) );        
    }
  
    
    /*
     * Удаление игрока из мониторинга
     */
    public function monitordelAction()
    {
        if( !$this->_helper->checkAccess('monitoring','manage') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }
        
        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }

        $idP = (int)$this->_request->getPost('idP',0);
        $user = Zend_Auth::getInstance()->getStorage()->read();        
        
        if( !$this->_helper->modelLoad('MonitorItems')->issetByUser($idP, $user->id) )
        {
            $this->view->error = 'Данный игрок не найден в вашем мониторинге';
            $this->_addErrorLog();
            return;
        }       
        
        $this->_helper->modelLoad('MonitorItems')->del( $idP, $user->id );
        
        $player = $this->_helper->modelLoad('Players')->getInfo($idP);  
        
        $this->_helper->modelLoad('UsersHistory')->add( 
                $user->id, 
                $this->view->partial( 'Partials/history/monitorDelPlayer.phtml', array( 'player' => $player ) ), 
                $this->_request);
        $this->view->html = $this->view->partial( 'Partials/message/monitorDelPlayer.phtml', array( 'idP' => $idP ) );        
    }
  
    
    /*
     * Добавление нового автопоиска
     */
    public function autosearchsavenewAction()
    {
        if( !$this->_helper->checkAccess('autosearch','add') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }
        
        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }
        
        //проверим мир
        $idW = (int)$this->_request->getPost('idW', 0);
        if( $this->_helper->modelLoad('Worlds')->validate( (int)$idW ) !== true )
        {
            $this->view->error = 'Некорректный идентификатор мира.';
            $this->_addErrorLog();
            return;
        }

        //проверим имя
        $name = $this->_request->getPost('newname');
        if( strlen($name) <= 0 || strlen($name) > 150 )
        {
            $this->view->error = 'Некорректное имя.';
            $this->_addErrorLog();
            return;
        }

        //проверим настройки
        $prop = @urldecode($this->_request->getPost('prop'));
        $prop = @unserialize($prop);
        if( $prop === false ||
            $this->_helper->modelLoad('Players')->issetValues($prop) !== true ||
            $this->_helper->modelLoad('Players')->validateForm( $prop ) !== true )
        {
            $this->view->error = 'Некорректные настройки поиска.';
            $this->_addErrorLog();
            return;
        }


        //сохраняем
        $user = Zend_Auth::getInstance()->getStorage()->read();

        try{
            $idA = $this->_helper->modelLoad('UsersSearch')->add( $user->id, $idW, $name, $prop );
        }catch (Exception $e){
            $this->view->error = $e->getMessage();
            return;
        }

        $this->_helper->modelLoad('UsersHistory')->add( 
                    $user->id, 
                    $this->view->partial( 'Partials/history/autosearchAdd.phtml', array( 'idA' => $idA, 'name' => $name ) ), 
                    $this->_request);
        $this->view->success = 'Новый автопоиск успешно добавлен.';        
    }

    /*
     * Редактирование записи старого автопоиска
     */
    public function autosearchsaveasAction()
    {
        if( !$this->_helper->checkAccess('autosearch','add') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }

        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }
        
        $user = Zend_Auth::getInstance()->getStorage()->read();

        //проверим ид поиска и принадлежность
        $idA = (int)$this->_request->getPost('idA');
        if( !$this->_helper->modelLoad('UsersSearch')->validateAccess( $idA, $user->id ) )
        {
            $this->view->error = 'Некорректный идентификатор поиска.';
            $this->_addErrorLog();
            return;
        }

        //проверим настройки
        $prop = @urldecode($this->_request->getPost('prop'));
        $prop = @unserialize($prop);
        if( $prop === false ||
            $this->_helper->modelLoad('Players')->issetValues( $prop ) !== true ||
            $this->_helper->modelLoad('Players')->validateForm( $prop ) !== true )
        {
            $this->view->error = 'Некорректные настройки поиска.';
            $this->_addErrorLog();
            return;
        }


        //сохраняем
        try{
            $this->_helper->modelLoad('UsersSearch')->upd( $idA, $prop );
        }catch (Exception $e){
            $this->view->error = $e->getMessage();
            $this->_addErrorLog();
            return;
        }
        
        $search = $this->_helper->modelLoad('UsersSearch')->getOne( $idA, $user->id );
        $this->_helper->modelLoad('UsersHistory')->add( 
                $user->id, 
                $this->view->partial( 'Partials/history/autosearchEdit.phtml', array( 'idA' => $idA, 'name' => $search['name'] ) ), 
                $this->_request);
        $this->view->success = 'Автопоиск успешно изменён.';        
    }

    /*
     * Удаление записи старого автопоиска
     */
    public function autosearchdelAction()
    {
        if( !$this->_helper->checkAccess('autosearch','del') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }

        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }
        
        $user = Zend_Auth::getInstance()->getStorage()->read();
        
        //проверим ид поиска и принадлежность
        $idA = (int)$this->_request->getPost('idA');
        if( !$this->_helper->modelLoad('UsersSearch')->validateAccess( $idA, $user->id  ) )
        {
            $this->view->error = 'Некорректный идентификатор поиска.';
            $this->_addErrorLog();
            return;
        }        
        
        $search = $this->_helper->modelLoad('UsersSearch')->getOne( $idA, $user->id );
        try{
            $this->view->del = $this->_helper->modelLoad('UsersSearch')->del( $idA );
        }catch (Exception $e){
            $this->view->error = $e->getMessage();
            $this->_addErrorLog();
            return;
        }

        $this->_helper->modelLoad('UsersHistory')->add( 
                $user->id, 
                $this->view->partial( 'Partials/history/autosearchDel.phtml', array( 'name' => $search['name'] ) ),
                $this->_request);
        $this->view->success = 'Автопоиск успешно удалён.';        
    }

    /*
     * редактирование пароля пользователя
     */
    public function userpasseditAction()
    {
        if( !$this->_helper->checkAccess('profile','edit') )
        {
            $this->view->error = 'Сессия устарела. Перезайдите в систему и попробуйте снова.';
            $this->_addErrorLog();
            return;
        }

        if( !$this->_helper->tokenCheck($this->_request->getPost('csrf')) )
        {
            $this->view->error = 'Токен устарел. Перезагрузите исходную страницу.';
            $this->_addCsrfLog();
            return;
        }
        
        $user = Zend_Auth::getInstance()->getStorage()->read();
        $newPass = $this->_request->getPost('pass');
        
        $res = $this->_helper->modelLoad('Users')->validatePass( 
                $newPass, 
                $this->_request->getPost('repass'),
                $user->id, 
                $this->_request->getPost('oldpass') );
        
        
        if( $res !== true ){
            $this->view->error = $res;
        }else{
            try{
                $this->_helper->modelLoad('Users')->updPass( $user->id, $newPass );
                $this->view->success = 'Пароль успешно изменён.';
            }catch (Exception $e){
                $this->view->error = $e->getMessage();
            }
        }
        
        if( isset( $this->view->error ) )
        {                                   
            $this->_addErrorLog();
            $this->_helper->modelLoad('UsersHistory')->add( 
                    $user->id, 
                    "Попытка смены пароля из личного кабинета ({$this->view->error})",
                    $this->_request);
        }else{
            $this->_helper->modelLoad('UsersHistory')->add( 
                    $user->id, 
                    'Смена пароля из личного кабинета',
                    $this->_request);
        }
    }


    /*
     * фидбек +1
     * @todo error field and $this->_addErrorLog();
     */
    public function feedbackAction()
    {        
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut');                
       
        if( $this->_helper->modelLoad('Antibrut')->checkIP( 'feedback', $this->_request->getClientIp(), $prop['feedback']['try'], $prop['feedback']['minutes']) )
        {
            $this->_helper->modelLoad('Antibrut')->addIP('feedback', $this->_request->getClientIp());
            
            $this->_helper->modelLoad('Feedback')->incRank($this->_request->getPost('idF'));
            
            $this->view->result = 'Ваш голос был учтён';
        }else{
            $this->view->result = 'С вашего IP уже производилось голосование в течении последних суток';
        }
    }

    /*
     * форма обратной связи
     * @todo error field and $this->_addErrorLog();
     */
    public function formAction()
    {        
        $prop = $this->getFrontController()->getParam('bootstrap')->getOption('antibrut');           
        if( !$this->_helper->modelLoad('Antibrut')->checkIP( 
                'form', 
                $this->_request->getClientIp(), 
                $prop['form']['try'], 
                $prop['form']['minutes']) )
        {
            $this->view->result = 'С вашего IP уже отправлялось сообщение в течении последних 10-ти минут.';
            return;
        }

        $contact = $this->_request->getPost('contact');
        if( $this->_helper->modelLoad('Form')->validate( $contact ) === true )
        {
            $this->_helper->modelLoad('Antibrut')->addIP('form', $this->_request->getClientIp());
            $this->_helper->modelLoad('Form')->addPost(  $contact, $this->_request->getPost('text')  );
            $this->view->result = 'Ваше сообщение было получено. Спасибо за интерес к проекту =)';
        }else{
            $this->view->result = 'Некорректные контактные данные.';
        }


    }


    /*
     * возвращает текущий онлайн игроков класики и анлима
     */
    public function onlineAction()
    {        
        $this->_onlineMap = new App_Model_OnlineMapper();  
        $props = $this->_helper->modelLoad('GameVersions')->getByName(array('classic', 'unlim'));        
        
        foreach( $props as $prop )
        {
            $res = $this->_onlineMap->getCurrentOnline($prop['id'], $prop['url']);
            if($res === false)
            {
                $this->view->error = $this->_onlineMap->getErrors();                
                $res = 0;
            }
            $this->view->{$prop['name']} = $res;
        }
        
        
    }


    /*
     * поиск игроков по нику (по миру или глобальный)
     * @var term = ник%
     */
    public function searchAction()
    {
        $term = $this->_request->getPost('term','');
        $idW = $this->_request->getPost('idW', 0);
                
        if( ($this->_helper->modelLoad('Worlds')->validate( (int)$idW ) === true || $idW == 0  ) && preg_match('/^[\wА-ЯЁа-яё.-\s]{3,100}$/ui', $term) )
        {
            $conf = $this->getFrontController()->getParam('bootstrap')->getOption('limits');

            $this->view->players = $this->_helper->modelLoad('Players')->fastSearch( $term, $conf['fastSearch'], $idW );
        }else{
            $this->view->error = 'Некорректные параметры.';            
            $this->_addErrorLog();
        }
    }

  

    /*
     * генерим карту кольца
     */
    public function mapAction()
    {
        $this->view->idWorld  = $idW = (int) $this->_request->getPost('idW');
        $this->view->ring     = $ring = (int) $this->_request->getPost('ring');
        
        $this->view->first    = $first = (int) $this->_request->getPost('first');
        $this->view->last     = $last = (int) $this->_request->getPost('last');
        

        //проверки
        if( ($ring < 1) || ($ring > 4) || $this->_helper->modelLoad('Worlds')->validate( $idW ) !== true )  //кольцо левое или мир хз какой
        {
            $this->view->error = 'Invalid main params';            
            $this->_addErrorLog();
            return;
        } elseif( $first < 1 || $last < 1 || $first == $last) { //параметры карты не дошли
            $this->view->error = 'Invalid step params [physical]';
            $this->_addErrorLog();
            return;
        }

        //получаем границы деления на стадии развития по основным параметрам
        $ranks = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('map');    
        if( count($ranks) != 5 ) {
            $this->view->error = 'Ranks unvalid';
            $this->_addErrorLog();
            return;
        }        

        //получаем макс компл на этом кольце
        $this->view->numMax = $maxNum = $this->_helper->modelLoad('Worlds')->getMaxComple($idW, $ring);
        if( $maxNum == 0 || $maxNum === false ) {
            $this->view->error = 'Undefined max compl for this ring';
            $this->_addErrorLog();
            return;
        }


        $this->view->map = $this->view->partial(
                'Partials/map.phtml',
                array( 
                    'map' => $this->_helper->modelLoad('Players')->getRingMap($idW, $first, $last, $ring), 
                    'first' => $first, 'last' => $last,  'ring' => $ring, 
                    'idW' => $idW, 'max' => $maxNum, 
                    'ranks' => $ranks ));
        

    }


    /*
     * подробная инфа по игроку для карты
     */
    public function playerinfoAction()
    {
        //получаем инфу по игроку
        $info = $this->_helper->modelLoad('Players')->getInfo((int) $this->_request->getPost('idP'));
        if( $info === false )
        {
            $this->view->error = 'Некорректный идентификатор игрока';
            $this->_addErrorLog();
            return;
        }
            
        $this->view->html = $this->view->partial( 'Partials/mapPlayer.phtml', array( 'player' => $info ) );
    }


    /*
     * получение данных для графиков игроков
     */
    public function graphplayerAction()
    {
        $idP = (int) $this->_request->getPost('idP');
        $type = $this->_request->getPost('type');

        switch( $type )
        {
            case 'summary':
                $res = $this->_helper->modelLoad('StatPlayers')->getSummaryStat( $idP );
                if( $res === false )
                {
                    $this->view->error = 'Данные отсутствуют';
                    $this->_addErrorLog();
                }else{
                    $this->view->borders = $res->borders;
                    $this->view->series = $this->_helper->modelLoad('StatPlayers')->prepareForSummaryGraph($res->data);                
                }

                break;

            case 'dshelp':
                $info = $this->_helper->modelLoad('Players')->getInfo( $idP );
                if( $info === false )
                {
                    $this->view->error = 'Игрок не найден';
                    $this->_addErrorLog();
                    return;
                }

                $nameDshelp = $this->_helper->modelLoad('Worlds')->getDshelpName( $info['id_world'] );
                if( $nameDshelp === false )
                {
                    $this->view->error = 'Данный график недоступен для выбранного мира';
                    $this->_addErrorLog();
                    return;
                }

                $this->_dshelpMap = new App_Model_DshelpMapper($nameDshelp);
                $url = $this->_dshelpMap->getUrl( $info['nik'], $idP );
                if( $url === false )
                {
                    $this->view->error = 'График временно недоступен';
                    $this->_addErrorLog();
                    return;
                }
                $this->view->url = $url;

                break;
                
            case 'mesto':
            case 'rank':
            case 'bo':
            case 'nra':
            case 'ra':
            case 'level':
            case 'archeology':
            case 'building':
            case 'science':                
                $data = $this->_helper->modelLoad('StatPlayers')->getStat( $type, $idP );
                if( count($data) == 0 )
                {
                    $this->view->error = 'Данные отсутствуют';
                    $this->_addErrorLog();
                }else{
                    $this->view->series = $this->_helper->modelLoad('StatPlayers')->prepareForSingleGraph($type, $data);
                }          
                break;

            default:
                $this->view->error = 'Не выбран тип графика';
                $this->_addErrorLog();
                break;
        }
    }

    
    /*
     * данные для графиков статистики игроков онлайн
     */
    public function graphonlineAction()
    {        
        $idV = (int) $this->_request->getPost('idV');
        $type = $this->_request->getPost('type');
                        
        switch( $type )
        {
            case 'hour':
                $data = $this->_helper->modelLoad('StatOnline')->getAllOnline($idV);                
                $this->view->series = $this->_helper->modelLoad('StatOnline')->prepareForHourGraph($data);        
                break;
            
            case 'day':
                $data = $this->_helper->modelLoad('StatOnline')->getDayOnline($idV);  
                $this->view->series = $this->_helper->modelLoad('StatOnline')->prepareForDayGraph($data);               
                break;
            
            default:
                $this->view->error = 'Неверный тип графика';
                $this->_addErrorLog();                
                return;
                break;
        }
        
        if(count($data) == 0)
        {
            $this->view->error = 'Данные отсутствуют';
            $this->_addErrorLog();            
            return;
        }
    
    }
}
