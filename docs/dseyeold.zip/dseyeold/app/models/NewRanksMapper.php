<?php

/* 
 * мапер для парсинга данных о новых рейтингах (постранично по миру)
 */

class App_Model_NewRanksMapper
{
    protected $_url = '';
    protected $_errorData = '';
    protected $_userAgent = null;
    protected $_parser = null;


    public function __construct( $url )
    {
        $this->_url = $url;
        $this->_userAgent = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('botname');
        $this->_parser = new Zend_Dom_Query();
    }

    public function getErrors()
    {
        return $this->_errorData;
    }

    /*
     * получить страницу со списком игроков
     * @return false | html-source
     */
    public function getPageSource( $num )
    {
        $url = $this->_prepareLink( $num );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->_userAgent);
        $response = iconv("Windows-1251", "UTF-8",curl_exec($ch));
        $err = curl_error($ch);
        curl_close($ch);
        
        if( $err != '' )
        {
            $this->_errorData .= "{$url} - {$err}<br>";
            return false;
        }else{
            return $response;
        }

    }

    
    /*
     * парсинг страницы игроков на строки
     */
    public function parsePlayers( $source )
    {                
        //ищем наш кусочек таблички
        $pos = strpos( $source, '<table width="100%" border="0" cellpadding="0" cellspacing="1" class=ranking_table>');
        $offset = strpos( $source, '</table>', $pos+8) - $pos;
        $table = substr($source, $pos, $offset);
var_dump($pos, $offset);
        
        $this->_parser->setDocumentHtml("<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">{$table}");
        return $this->_parser->query('tr.ranking_table_01, tr.ranking_table_02');
        //$doc = new DOMDocument('1.0', 'UTF-8');        
        //@$doc->loadHTML("<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">{$table}");
        //$path = new DOMXPath($doc);
        //return $path->query("//tr[contains(concat(' ', normalize-space(@class), ' '), ' ranking_table_01 ')]|//tr[contains(concat(' ', normalize-space(@class), ' '), ' ranking_table_02 ')]");
    }

    /*
     * парсинг строки на ник и новые рейтинги
     */
    public function parsePlayerStr( $domElement )
    {
        $items = $domElement->getElementsByTagName('td');
        
        $data=array();
        
        $tmpData=array();
        foreach ($items as $item)
        {
            $tmpData[] = trim($item->nodeValue);
        }
                
        //не битая ли строка
        if( count($tmpData) != 14 )
        {
            var_dump($tmpData);
            echo "строка битая";
            return false;
        }
        
        echo "игрок <b>{$tmpData[1]}</b> ";
        
        $data['nik'] = $tmpData[1];
        if( !preg_match('/^[\wА-Яа-яёЁ\s.-]{3,50}$/ui',$data['nik']) )
        {
            echo "стрёмный ник {$data['nik']}";
            return false;
        }

        //выдираем рейтинг
        $data['rank'] = $tmpData[6];
        if( !preg_match('/^\d+$/',$data['rank']) )
        {
            echo "стрёмный рейтинг {$data['rank']}";
            return false;
        }
        
        //выдираем уровень
        $data['level'] = ($tmpData[7] != '') ? $tmpData[7] : 0;
        if( !preg_match('/^\d+$/',$data['level']) )
        {
            echo "стрёмный уровень {$data['level']}";
            return false;
        }
        
        //выдираем лигу
        $data['liga'] = $tmpData[8];
        if( !in_array($data['liga'], array('I','II','III') ) )
        {
            echo "стрёмная лига {$data['liga']}";
            return false;
        }
        
        //археология        
        $data['arch'] = $tmpData[9];
        if( !preg_match( '/^\d+$/',$data['arch']) )
        {
            echo "стрёмная археология {$data['arch']}";
            return false;
        }
        
        //стройка        
        $data['build'] = $tmpData[10];
        if( !preg_match( '/^\d+$/',$data['build']) )
        {
            echo "стрёмная стройка {$data['build']}";
            return false;
        }
        
        //наука        
        $data['scien'] = $tmpData[11];
        if( !preg_match( '/^\d+$/',$data['scien']) )
        {
            echo "стрёмная наука {$data['scien']}";
            return false;
        }
        
        return $data;
    }


    /*
     * составляем ссылку для запроса страницы с игроками
     */
    protected function _prepareLink( $num )
    {
        $offset=( $num - 1 ) * 25;
        return "{$this->_url}&offset={$offset}";
    }


    


}
