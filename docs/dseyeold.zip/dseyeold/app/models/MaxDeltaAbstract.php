<?php

/*
 * абстрактный класс для всех моделей максимальных изменений показателей (дельты)
 */
abstract class App_Model_MaxDeltaAbstract extends Mylib_DbTable_Cached
{

    final public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date < NOW() - INTERVAL ? DAY', $days ) );
    }
    
    
    /*
     * максимальные дельты игроков мира
     */
    final protected function _getDeltsByWorld( $idW, $date = null, $returnCount = true, $limit = 10 )
    {
        $data = array( "delts" => array( ), "count" => 0 );
        
        $select = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array(
                    'delta',
                    'date' => "DATE_FORMAT({$this->_name}.date , '%H:%i')",
                    'sort_delta' => "ABS({$this->_name}.delta)" ))
                ->join('players', "players.id = id_player", array( 'id', 'nik', 'id_rase', 'id_alliance' ))                
                ->join('alliances', "players.id_alliance = alliances.id", array( 'alliance' => 'name' ))                
                ->where("{$this->_name}.id_world = ?", $idW)
                ->order("{$this->_name}.date DESC")
                ->order('sort_delta DESC')
                ->limit($limit);

        if(is_null($date))
            $select->where("DATE({$this->_name}.date) = CURRENT_DATE");
        else
            $select->where("DATE_FORMAT({$this->_name}.date, '%d-%m-%Y') = ?", $date);        
                
        if( $returnCount === true ) 
        {   
            $adapter = new Zend_Paginator_Adapter_DbSelect($select);
            $count = (int) $adapter->count();
        }

        if( ($returnCount === true && $count > 0) || $returnCount === false )
        {
            if( isset($count) ) 
                $data["count"] = $count - $limit;            
            
            $data["delts"] = $this->fetchAll($select)->toArray();
        }

        return $data;
    }

   
}
