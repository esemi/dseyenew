<?php
/* 
 * Модель работы с сосбтвенными csv файлами.
 */
class App_Model_MyCSV
{
    protected $_path = null;
    protected $_limit = null;
    protected $_gzLevel = null;

    public function __construct($limit, $gzLevel)
    {
        $this->_path = WWW_PATH . '/csv';
        $this->_limit = $limit;
        $this->_gzLevel = $gzLevel;
    }

    public function createMain( $resource, $idW, $filename )
    {        
        $handle = fopen('php://temp', 'w+');        
        $params = array(
            'id','nik','dom_adr','dom_name','gate','colony_adr',
            'colony_name','alliance','rase','level','liga','rank',
            'bo','archeology','building','science','nra','ra',
            'delta_rank','delta_bo');        
        fputcsv($handle, $params, ';', '"');
        
        $players = $resource->getDataForCsv($idW);
        foreach($players as $player)
        {
            //билиать, надо было писать на питоне (:
            $data = array();
            foreach($params as $key)
                $data[] = $player[$key];
            fputcsv($handle, $data, ';', '"');   
        }
        rewind($handle);
        file_put_contents("{$this->_path}/{$filename}.csv.gz", gzencode(stream_get_contents($handle), $this->_gzLevel));        
        fclose($handle);
    }
    
    public function createStat( $resource, $idW, $filename )
    {
        $pager = $resource->getDataForCsv($idW, $this->_limit);
        
        $count = $pager->count();
        if($count == 0)
            return false;
        
        $handle = fopen("php://temp", 'w+');
        for($page=1; $page <= $count; $page++)
        {
            $data = $pager->getItemsByPage($page)->toArray();
            if($page==1)
                fputcsv($handle, array_keys($data[0]), ';', '"');
                
            foreach($data as $str)
                fputcsv($handle, array_values($str), ';', '"');
            unset($data);
        }
        rewind($handle);
        file_put_contents("{$this->_path}/{$filename}.csv.gz", gzencode(stream_get_contents($handle), $this->_gzLevel));
        fclose($handle); 
        
        return true;
    }

}

?>
