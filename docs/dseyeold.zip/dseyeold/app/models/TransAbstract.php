<?php

/*
 * абстрактный класс для всех моделей аналитики (переходы/переезды)
 */
abstract class App_Model_TransAbstract extends Mylib_DbTable_Cached
{

    public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date < NOW() - INTERVAL ? DAY', $days ) );
    }
    
    
    protected abstract function _getTransByPlayer( $idP, $limit );
    protected abstract function _getTransByAlliance( $idA, $limit);
    protected abstract function _getTransByWorld($idW, $date = null, $returnCount = false, $limit = 10);

   
}
