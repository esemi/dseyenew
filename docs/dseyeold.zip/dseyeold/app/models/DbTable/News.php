<?php

/*
 * модель новостей
 */
class App_Model_DbTable_News extends Mylib_DbTable_Cached
{

    protected $_name = 'news';
    protected $_cacheName = 'default';

    /*
     * получить список новостей
     */
    public function listAll()
    {   
        $select = $this->select()
                ->from($this, array( 
                    'id', 'cat', 'title', 'desc', 'text',
                    'date' => 'DATE_FORMAT(`date` , \'%H:%i %d.%m.%Y\')',
                    'date_unix' => 'UNIX_TIMESTAMP(`date`)' ))
               ->order('news.date DESC')
               ->limit(50);

        return $this->fetchAll($select);
    }

}
