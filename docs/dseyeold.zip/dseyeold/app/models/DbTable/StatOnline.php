<?php

/*
 * модель статистики по онлайну
 */
class App_Model_DbTable_StatOnline extends Mylib_DbTable_Cached
{

    protected $_name = 'stat_online';
    protected $_primary = array('id_version', 'date');
    protected $_cacheName = 'default';


    /*
     * чистим старые данные
     */
    public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date < CURDATE() - INTERVAL ? DAY', $days ) );
    }

    
    public function addStat($idV, $count)
    {
        return $this->insert( array(
            'id_version' => $idV,
            'count' =>  $count ) );
    }

    /*
     * количество игроков online
     * по часам за месяц
     * одна серия
     */
    protected function _getAllOnline( $idV )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser' => 'count',
                            'date' => "DATE_FORMAT( `date` , '%H.%d.%m.%Y' )" ))
                        ->where('id_version = ?', $idV)
                        ->where('date > NOW()- INTERVAL 1 MONTH')
                        ->order("{$this->_name}.date ASC");
        $result = $this->fetchAll($select);

        return (!is_null($result) ) ? $result->toArray() : array();
    }


    /*
     * количество игроков online
     * апроксимация по дням
     * среднее - минимум - максимум
     */
    protected function _getDayOnline( $idV )
    {
        $select = $this->select()
                        ->from($this, array(
                            'round' => "ROUND(AVG(count))",
                            'min' => "MIN(count)",
                            'max' => "MAX(count)",
                            'date' => "DATE_FORMAT( `date` , '%d.%m.%Y' )" ))                                    
                        ->where('id_version = ?', $idV)
                        ->group("DATE_FORMAT( `date` , '%d.%m.%Y' )")
                        ->order("{$this->_name}.date ASC");
        $result = $this->fetchAll($select);
        
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * возвращает последний замер количества онлайна 
     * return int
     */
    protected function _getLastVal($idV)
    {
        $select = $this->select()
                        ->from($this, array('count'))
                        ->where('id_version = ?', $idV)
                        ->order('date DESC')
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? (int)$result->count : 0;
    }

    
    public function prepareForHourGraph($data)
    { 
        $out = new stdClass();
        $out->name = 'Всего';
        $out->realname = 'count';
        $out->visible = true;
        $out->data = array();

        foreach( $data as $val )
            $out->data[] = array($val['date'], $val['ser']);        

        return array($out);
    }
    
    public function prepareForDayGraph($data)
    { 
        $items = array(
            'round' => 'В среднем',
            'min' => 'Минимум',
            'max' => 'Максимум');
        
        $result = array();

        foreach( $items as $realname => $name )
        {
            $$realname = new stdClass();
            $$realname->name = $name;
            $$realname->realname = $realname;
            $$realname->data = array();
            $$realname->visible = true;
            $result[] = $$realname;
        }

        foreach( $data as $val )
            foreach( $items as $realname => $name )
                $$realname->data[] = array($val['date'], $val[$realname]);
        
        return $result;
    }
}