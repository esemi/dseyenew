<?php

/*
 * активация новых юзеров
 */
class App_Model_DbTable_UsersApproved extends Mylib_DbTable_Cached
{
    protected $_name = 'users_approved';
    protected $_cacheName = 'default';


    /*
     * проверка количества запросов на активацию данного юзера
     *
    public function checkCount( $idU, $limit, $hours )
    {
        $select = $this->select()
                ->from( $this, array('count' => 'COUNT(*)') )
                ->where( 'id_user = ?', $idU )
                ->where( "date_create > NOW() - INTERVAL {$hours} HOUR" );
        $res = $this->fetchRow($select);
        
        return ( intval($res->count) < $limit ) ? true : false;
    }*/


    /*
     * поиск id юзера по токену и обновление даты активации токена
     */
    public function findAndUpdToken( $token )
    {
        $select = $this->select()
                ->from( $this, array( 'id', 'id_user' ) )
                ->where( 'token = ?', $token )
                ->where( "date_activate IS NULL" );
        $res = $this->fetchRow($select);

        if( !is_null($res) )
            $this->update(
                    array( 'date_activate' => new Zend_Db_Expr('NOW()') ),
                    array( $this->_db->quoteInto( 'id = ?', $res->id ) ) );

        return ( !is_null($res) ) ? intval($res->id_user) : null;
    }


    /*
     * добавление нового запроса на активацию
     */
    public function add( $idU )
    {
        $token = hash('sha256', uniqid( mt_rand(), true ));
        $this->insert( array( 'id_user' => $idU, 'token' =>  $token ));
        return $token;
    }


}
