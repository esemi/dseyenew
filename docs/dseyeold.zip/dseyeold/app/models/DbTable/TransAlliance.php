<?php

/*
 * переходы игроков по альянсам
 * 
 */
class App_Model_DbTable_TransAlliance extends App_Model_TransAbstract
{

    protected $_name = 'players_trans_alliance';

    /*
     * переходы игрока по альянсам
     */
    protected function _getTransByPlayer( $idP, $limit )
    {
        $select = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array( 'date' => "DATE_FORMAT(`date` , '%H:%i %d.%m.%y')" ))
                ->join(array( 'al1' => 'alliances' ), 'al1.id = old_alliance', array( 'old_id' => 'id', 'old_name' => 'name' ))
                ->join(array( 'al2' => 'alliances' ), 'al2.id = new_alliance', array( 'new_id' => 'id', 'new_name' => 'name' ))
                ->where('id_player = ?', $idP)
                ->order("{$this->_name}.date DESC")
                ->limit($limit);
        return $this->fetchAll($select)->toArray();
    }
    
    
    /*
     * переходы игроков альянса
     */
    protected function _getTransByAlliance( $idA, $limit )
    {        
        $select = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array( 'old_alliance', 'new_alliance', 'date' => "DATE_FORMAT(`date` , '%H:%i %d.%m.%y')" ))
                ->join('players', 'players.id = id_player', array( 'id', 'nik', 'id_rase' ))
                ->join(array( 'al1' => 'alliances' ), 'al1.id = old_alliance', array( 'old_id' => 'id', 'old_name' => 'name' ))
                ->join(array( 'al2' => 'alliances' ), 'al2.id = new_alliance', array( 'new_id' => 'id', 'new_name' => 'name' ))
                ->where("old_alliance = ? OR new_alliance = ?", $idA)
                ->order("{$this->_name}.date  DESC")
                ->limit($limit);            
        return $this->fetchAll($select)->toArray();
    }
    
    
    /*
     * переходы игроков мира
     */
    protected function _getTransByWorld( $idW, $date = null, $returnCount = true, $limit = 10 )
    {
        $data = array( "transes" => array( ), "count" => 0 );

        $select = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array( 'old_alliance', 'new_alliance', 'date' => "DATE_FORMAT(date , '%H:%i')" ))
                ->join("players", "players.id = id_player", array( 'id', 'nik', 'id_rase' ))
                ->join(array( 'al1' => 'alliances' ), 'al1.id = old_alliance', array( 'old_id' => 'id', 'old_name' => 'name' ))
                ->join(array( 'al2' => 'alliances' ), 'al2.id = new_alliance', array( 'new_id' => 'id', 'new_name' => 'name' ))
                ->where("players.id_world = ?", $idW)
                ->order("{$this->_name}.date DESC")
                ->limit($limit);        
        
        if(is_null($date))
            $select->where("DATE({$this->_name}.date) = CURRENT_DATE");
        else
            $select->where("DATE_FORMAT({$this->_name}.date, '%d-%m-%Y') = ?", $date);    
                
                
        if( $returnCount === true  ) 
        {
            $adapter = new Zend_Paginator_Adapter_DbSelect($select);
            $count = (int) $adapter->count();    
        }
        
        if( ($returnCount === true && $count > 0) || $returnCount === false ) 
        {            
            if( isset($count) ) 
                $data["count"] = $count - $limit;                    
            
            $data["transes"] = $this->fetchAll($select)->toArray();            
        }

        return $data;
    }
}