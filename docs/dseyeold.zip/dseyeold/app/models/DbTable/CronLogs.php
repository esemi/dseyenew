<?php

/*
 * модель таблицы логов крона
 */
class App_Model_DbTable_CronLogs extends Mylib_DbTable_Cached
{

    protected $_name = 'cron_logs';
    protected $_cacheName = 'default';

    /*
     * удаляем данные старше N дней
     */
    public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date < NOW() - INTERVAL ? DAY', $days ) );
    }


    /*
     * получить последние логи по типу
     */
    public function getLogsByType( $type, $limit=10 )
    {
        $select = $this->select()
                ->from($this, array('id', 'date', 'size' => 'ROUND(LENGTH(`text`) / 1024)') )
                ->where("type = ?", $type)
                ->order('date DESC')
                ->limit($limit);
        $result = $this->fetchAll($select);

        return (!is_null($result)) ? $result->toArray() : array();
    }

}