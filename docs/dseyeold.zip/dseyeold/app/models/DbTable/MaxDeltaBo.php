<?php

/*
 * макс дельты БО игроков
 * 
 */
class App_Model_DbTable_MaxDeltaBo extends App_Model_MaxDeltaAbstract
{

    protected $_name = 'players_max_bo_delta';

   
}
