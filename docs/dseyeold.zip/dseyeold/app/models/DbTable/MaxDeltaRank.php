<?php

/*
 * макс дельты старого рейтинга игроков
 * 
 */
class App_Model_DbTable_MaxDeltaRank extends App_Model_MaxDeltaAbstract
{

    protected $_name = 'players_max_rank_delta';    
   
}
