<?php

/*
 * модель миров
 */

class App_Model_DbTable_Worlds extends Mylib_DbTable_Cached
{

    protected $_name = 'worlds';

    /*
     * валидация мира по id
     */
    public function validate( $idW )
    {
        $select = $this->select()
                        ->from($this, array( 'id' ))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) && $result->id == $idW ) ? true : false;
    }


    /*
     * паттерн для поиска по сферному форуму
     * зависит от версии игры
     */
    protected function _getForumSearchPattern( $idW )
    {
        $select = $this->select()
                        ->setIntegrityCheck(false)
                        ->from($this, array())
                        ->joinLeft('game_versions', 'id_version = game_versions.id',
                                array( 'url' => 'forum_search_pattern' ))
                        ->where("{$this->_name}.id = ?", $idW)
                        ->limit(1);

        $result = $this->fetchRow($select);

        return $result->url;
    }


    /*
     * мир для обновления РА
     * @return array | null
     */
    public function getOldRaWorld( $hours )
    {
        $select = $this->select()
                        ->from($this, array( 
                            'id', 'dshelp_name',
                            'count' => '(count_voran + count_liens + count_psol)' ))
                        ->where('status = "active"')
                        ->where('dshelp_name IS NOT NULL')
                        ->where("(dshelp_upd < NOW() - INTERVAL {$hours} HOUR) OR (dshelp_upd IS NULL)")
                        ->order('dshelp_upd ASC')
                        ->limit(1);
        $result = $this->fetchRow($select);

        if( !is_null($result) )
        {
            $this->update( array(
                        'dshelp_upd' => new Zend_Db_Expr('NOW()'),
                        'dshelp_status' => 'process' ),
                    $this->_db->quoteInto( 'id = ?', $result->id ));
        }


        return (!is_null($result) ) ? $result->toArray() : null;
    }

    /*
     * обновить дату и статус обновления РА
     */
    public function raStatusUpd( $idW )
    {
        return $this->update(
                array( 'dshelp_status' => 'wait' ),
                $this->_db->quoteInto( 'id = ?', $idW ));
    }


    
    /*
     * мир для обновления новых рейтингов
     * обновляет дату и статус у найденного мира
     * @return array | null
     */
    public function getOldRanksWorld( $hours )
    {
        $select = $this->select()
                        ->from($this, array( 
                            'id', 'name', 'url' => 'CONCAT(new_ranks_rep, new_ranks_url)', 
                            'count' => '(count_voran + count_liens + count_psol)' ))
                        ->joinLeft('game_versions', 'id_version = game_versions.id', array( ))
                        ->where('status = "active"')
                        ->where('new_ranks_url IS NOT NULL')
                        ->where('new_ranks_rep IS NOT NULL')
                        ->where("(new_ranks_upd < NOW() - INTERVAL {$hours} HOUR) OR (new_ranks_upd IS NULL)")
                        ->order('new_ranks_upd ASC')
                        ->limit(1);
        $result = $this->fetchRow($select);        

        return (!is_null($result) ) ? $result->toArray() : null;
    }

    /*
     * обновить дату и статус обновления новых рейтингов
     */
    public function newRanksStatusUpd( $idW, $status )
    {
        $data = array('new_ranks_status' => $status);
        if($status == 'process')
            $data['new_ranks_upd'] = new Zend_Db_Expr('NOW()');
        
        return $this->update( $data, $this->_db->quoteInto( 'id = ?', $idW ));
    }


    /*
     * миры для обновления csv
     * @return array | null
     */
    public function getActive()
    {
        $select = $this->select()
                        ->from($this, array( 'id', 'name' ))
                        ->where('status = "active"');
        $result = $this->fetchAll($select);
        
        return (!is_null($result) ) ? $result->toArray() : null;
    }


    /*
     * имя мира (человекочитаемо)
     */
    protected function _getName( $idW )
    {
        $select = $this->select()
                        ->from($this, array( 'name' ))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? $result->name : 'undefined';
    }

    /*
     * имя мира на дсхелпе
     */
    protected function _getDshelpName( $idW )
    {
        $select = $this->select()
                        ->from($this, array( 'dshelp_name' ))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? $result->dshelp_name : false;
    }

    /*
     * получить текущие свойства конкретного мира
     */
    protected function _getCurProperty( $idW )
    {
        $select = $this->select()
                        ->setIntegrityCheck(false)
                        ->from($this, array( 'name', 'dshelp_name', 'type', 'status',
                            'date_create' => 'FROM_UNIXTIME(`date_create` , \'%d.%m.%Y\')',
                            'date_birth' => 'FROM_UNIXTIME(`date_birth` , \'%d.%m.%Y\')',
                            'date_upd' => 'FROM_UNIXTIME(`date_upd` , \'%H:%i %d.%m\')',
                            'date_delete' => 'FROM_UNIXTIME(`date_delete` , \'%d.%m.%Y\')',
                            'date_dshelp' => 'DATE_FORMAT(`dshelp_upd` , \'%H:%i %d.%m\')',
                            'date_new_ranks' => 'DATE_FORMAT(`new_ranks_upd` , \'%H:%i %d.%m\')',
                            'intro', 'compls_voran', 'compls_liens', 'compls_psol', 'compls_mels',
                            'count_voran', 'count_liens', 'count_psol',
                            'rank_voran', 'rank_liens', 'rank_psol',
                            'bo_voran', 'bo_liens', 'bo_psol',
                            'nra_voran', 'nra_liens', 'nra_psol',
                            'ra_voran', 'ra_liens', 'ra_psol',
                            'count_colony', 'count_alliance',
                            'avg_level_voran', 'avg_level_liens', 'avg_level_psol',
                            'archeology_voran', 'archeology_liens', 'archeology_psol',
                            'building_voran', 'building_liens', 'building_psol',
                            'science_voran', 'science_liens', 'science_psol',

                            'count' => '(count_voran + count_liens + count_psol)',
                            'sum_rank' => '(rank_voran + rank_liens + rank_psol)',
                            'sum_bo' => '(bo_voran + bo_liens + bo_psol)',
                            'sum_nra' => '(nra_voran + nra_liens + nra_psol)',
                            'sum_ra' => '(ra_voran + ra_liens + ra_psol)',
                            'sum_arch' => '(archeology_voran + archeology_liens + archeology_psol)',
                            'sum_build' => '(building_voran + building_liens + building_psol)',
                            'sum_scien' => '(science_voran + science_liens + science_psol)',

                            'avg_level' => 'ROUND((avg_level_voran + avg_level_liens + avg_level_psol) / 3)',
                            'avg_rank' => 'ROUND((rank_voran + rank_liens + rank_psol) / (count_voran + count_liens + count_psol))',
                            'avg_bo' => 'ROUND((bo_voran + bo_liens + bo_psol) / (count_voran + count_liens + count_psol))',
                            'avg_nra' => 'ROUND((nra_voran + nra_liens + nra_psol) / (count_voran + count_liens + count_psol), 1)',
                            'avg_ra' => 'ROUND((ra_voran + ra_liens + ra_psol) / (count_voran + count_liens + count_psol), 1)',
                            'avg_arch' => 'ROUND((archeology_voran + archeology_liens + archeology_psol) / (count_voran + count_liens + count_psol))',
                            'avg_build' => 'ROUND((building_voran + building_liens + building_psol) / (count_voran + count_liens + count_psol))',
                            'avg_scien' => 'ROUND((science_voran + science_liens + science_psol) / (count_voran + count_liens + count_psol))',

                            'avg_rank_voran' => 'ROUND(rank_voran / count_voran)',
                            'avg_rank_liens' => 'ROUND(rank_liens / count_liens)',
                            'avg_rank_psol' => 'ROUND(rank_psol / count_psol)',

                            'avg_bo_voran' => 'ROUND(bo_voran / count_voran)',
                            'avg_bo_liens' => 'ROUND(bo_liens / count_liens)',
                            'avg_bo_psol' => 'ROUND(bo_psol / count_psol)',

                            'avg_nra_voran' => 'ROUND(nra_voran / count_voran, 1)',
                            'avg_nra_liens' => 'ROUND(nra_liens / count_liens, 1)',
                            'avg_nra_psol' => 'ROUND(nra_psol / count_psol, 1)',

                            'avg_ra_voran' => 'ROUND(ra_voran / count_voran, 1)',
                            'avg_ra_liens' => 'ROUND(ra_liens / count_liens, 1)',
                            'avg_ra_psol' => 'ROUND(ra_psol / count_psol, 1)',

                            'avg_arch_voran' => 'ROUND(archeology_voran / count_voran)',
                            'avg_arch_liens' => 'ROUND(archeology_liens / count_liens)',
                            'avg_arch_psol' => 'ROUND(archeology_psol / count_psol)',

                            'avg_build_voran' => 'ROUND(building_voran / count_voran)',
                            'avg_build_liens' => 'ROUND(building_liens / count_liens)',
                            'avg_build_psol' => 'ROUND(building_psol / count_psol)',

                            'avg_scien_voran' => 'ROUND(science_voran / count_voran)',
                            'avg_scien_liens' => 'ROUND(science_liens / count_liens)',
                            'avg_scien_psol' => 'ROUND(science_psol / count_psol)',

                            'people_voran' => 'ROUND( count_voran / ( compls_voran * 6) *100 , 1 )',
                            'people_liens' => 'ROUND( count_liens / ( compls_liens * 6) *100 , 1 )',
                            'people_psol' => 'ROUND( count_psol / ( compls_psol * 6) *100 , 1 )',
                            'people_mels' => 'ROUND( count_colony / ( compls_mels * 6) *100 , 1 )'

                            ))
                        ->joinLeft('game_versions', 'id_version = game_versions.id',
                                array( 'version' => 'name' ))
                        ->where("{$this->_name}.id = ?", $idW)
                        ->limit(1);

        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? $result->toArray() : false;
    }

    
    protected function _getMinStatDate( $idW, $days )
    {
        $select = $this->select()
                        ->from($this, array('date' => "DATE_FORMAT(GREATEST( FROM_UNIXTIME(date_create), NOW() - INTERVAL {$days} DAY), '%d-%m-%Y')"))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return $result->date;        
    }

    /*
     * получить список миров (удалённые тоже)
     */
    protected function _listing()
    {
        $select = $this->select()
                        ->from($this, array( 'id', 'name', 'status' ))
                        ->order('id');
        return $this->fetchAll($select);
    }

    /*
     * получить максимальный комплекс на кольце ()
     */
    protected function _getMaxComple( $idW, $idRing )
    {
        $colums = Array(
            'compls_voran AS num',
            'compls_liens AS num',
            'compls_psol AS num',
            'compls_mels AS num' );

        $select = $this->select()
                        ->from($this, $colums[$idRing - 1])
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (int) $result["num"];
    }
   
  

    /*
     * получить количество альянсов (живых разумеетсо)
     */
    protected function _getAllianceCount( $idW )
    {
        $select = $this->select()
                        ->from($this, array( 'count' => 'count_alliance' ))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (int) $result["count"];
    }

    /*
     * получить общее количество игроков в мире ()
     */
    protected function _getPlayersCount( $idW )
    {
        $select = $this->select()
                        ->from($this, array( '(count_voran + count_liens + count_psol) AS count' ))
                        ->where('id = ?', $idW)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (int) $result["count"];
    }


    /*
     * выбираем максимальный компл в мире
     */
    protected function _getGreatCompl( $idW )
    {
        $select = $this->select()
                       ->from($this, array( 'num' => 'GREATEST( `compls_voran` , `compls_liens` , `compls_psol` , `compls_mels` )' ) )
                       ->where('id = ?', $idW)
                       ->limit(1);
        $result = $this->fetchRow($select);
        return (int) $result['num'];
    }

}
