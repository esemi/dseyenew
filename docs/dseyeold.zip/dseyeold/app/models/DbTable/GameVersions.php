<?php

/*
 * модель версий игры
 */
class App_Model_DbTable_GameVersions extends Mylib_DbTable_Cached
{
    protected $_name = 'game_versions';
    protected $_cacheName = 'default';
        
    /*
     * урлы для статистики онлайна всех доступных версий игры
     */
    protected function _getAllForStat()
    {
        $select = $this->select()
                    ->from($this, array('id','name', 'url' => 'onlinestat_url'))
                    ->where('onlinestat_url IS NOT NULL');

        return $this->fetchAll($select)->toArray();
    }
    
    /*
     * урлы для графика на главной
     */
    protected function _getByName($name)
    {
        $select = $this->select()
                    ->from($this, array('id', 'name', 'url' => 'onlinestat_url'))
                    ->where('name IN (?)', $name);
        return $this->fetchAll($select)->toArray();
    }
}
