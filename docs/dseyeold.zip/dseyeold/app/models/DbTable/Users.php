<?php

/*
 * пользователи
 */
class App_Model_DbTable_Users extends Mylib_DbTable_Cached
{
    protected $_name = 'users';
    protected $_cacheName = 'default';

    /*
     * очистка неактивированных аккаунтов и всех связанных с ними записей
     * * удаляет зависимые связи благодаря ссылочной целостности InnoDB
     */
    public function clearOld( $days )
    {
        return $this->delete( 
                $this->_db->quoteInto('approved = "no" AND date_create < NOW() - INTERVAL ? DAY',$days) 
                );
    }

    /*
     * валидация данных регистрации
     *
     * @return true or string with error text
     */
    public function validateNewUser( $data, $captcha = null )
    {
        //обязательные поля
        if( 
                !isset($data['login']) || !isset($data['pass']) || !isset($data['repass']) || !isset($data['email']) || 
                (!is_null($captcha) && (empty($data['recaptcha_challenge_field']) || empty($data['recaptcha_response_field']) ))
           )
            return 'Не переданны одно или несколько обязательных полей формы.';

        //логин неверен
        if( !$this->_checkLogin($data['login']) )
            return 'Недопустимый логин.';

        //логин уже занят
        $validator = new Zend_Validate_Db_NoRecordExists( array( 'table' => 'users', 'field' => 'login' ) );
        if (!$validator->isValid($data['login']))
            return 'Данный логин уже занят.';

        //пароль неверен
        if( !$this->_checkPass($data['pass']) )
            return 'Недопустимый пароль.';

        //пароли не совпадают
        if( $data['pass'] !== $data['repass'] )
            return 'Пароли не совпадают.';

        //мыло         
        $validMail = new Zend_Validate_EmailAddress( array( 'mx' => true, 'deep' => true ) );
        if( !$validMail->isValid( $data['email'] ) )
            return 'Недопустимый email-адрес.';
        
        //капча
        if(!is_null($captcha))
        {
            $captchaRes = $captcha->verify($data['recaptcha_challenge_field'], $data['recaptcha_response_field']);
            if( !$captchaRes->isValid() )
                return 'Текст с изображения введён неверно';
        }
        
        return true;

    }

    public function validatePass( $pass, $pass2, $idU, $oldPass )
    {
        //пароль неверен
        if( !$this->_checkPass($pass) )
            return 'Некорректное значение нового пароля.';

        //пароли не совпадают
        if( $pass !== $pass2 )
            return 'Пароли не совпадают.';

        //проверим старый пароль
        $select = $this->select()
                    ->from($this, array('id'))
                    ->where('id = ?', $idU)
                    ->where('pass = SHA1( CONCAT( ?, `salt` ) )', $oldPass)
                    ->limit(1);
        
        if( is_null($this->fetchRow($select)) )
            return 'Некорректное значение текущего пароля.';
        

        return true;
    }

    /*
     * поиск неактивированного юзера для повторного письма с активацией
     */
    public function findForApprove( $login, $email )
    {
        $select = $this->select()
                ->from($this, array('id','email','login'))
               ->where('login = ?', $login)
               ->where('email = ?', $email)
               ->where('approved = "no"')
               ->limit(1);

        return $this->fetchRow($select);
    }

    /*
     * поиск активированнного юзера для восстановления пароля
     */
    public function findForRemember( $login, $email )
    {
        $select = $this->select()
                ->from($this, array('id','email','login'))
               ->where('login = ?', $login)
               ->where('email = ?', $email)
               ->where('approved = "yes"')
               ->limit(1);

        return $this->fetchRow($select);
    }


    /*
     * активация аккаунта юзера
     */
    public function approve( $idU )
    {
        return $this->update(
                array( 'approved' =>  'yes' ),
                array( $this->_db->quoteInto( 'id = ?', $idU ) ) );
    }


    /*
     * добавление нового юзера
     */
    public function addNew( $post )
    {
        $salt = md5(uniqid('', true));
        return $this->insert( array(
            'login' => $post['login'],
            'pass' =>  new Zend_Db_Expr( $this->_db->quoteInto("SHA1( CONCAT( ?, '{$salt}') )", $post['pass']) ),
            'salt' => $salt,
            'email' => ($post['email'] == '') ? null : $post['email'],
            'date_create' => new Zend_Db_Expr('NOW()') ));
    }

    /*
     * обновление пароля
     */
    public function updPass( $idU, $newPass = null )
    {
        if( is_null($newPass))
            $newPass = Mylib_Utils::rand_str( 12 );
        
        $this->update(
                array( 'pass' =>  new Zend_Db_Expr( $this->_db->quoteInto("SHA1( CONCAT( ?, `salt`) )", $newPass) ) ),
                array( $this->_db->quoteInto( 'id = ?', $idU ) )
                );
        return $newPass;
    }


    /*
     * обновление времени последнего входа
     */
    public function updLastLogin( $idU )
    {
        return $this->update(
                array('last_login' => new Zend_Db_Expr('NOW()') ),
                array( $this->_db->quoteInto( 'id = ?', $idU ) )
                );
    }


    /*
     * ищет юзера по имени
     */
    public function findByLogin( $login )
    {
        $select = $this->select()
                ->from($this, array('id','email','login', 'approved'))
                ->where('login = ?', $login)
                ->limit(1);

        return $this->fetchRow($select);
    }

    
    /*
     * получает всю инфу по id
     */
    public function getInfo( $idU )
    {
        $select = $this->select();
        $select->from($this, array(
            'id','email','login', 'role',
            'created' => "DATE_FORMAT(`date_create` , '%d.%m.%Y')",
            'last_login' => "DATE_FORMAT(`last_login` , '%H:%i %d.%m.%Y')"))
               ->where('id = ?', $idU)
               ->limit(1);

        $result = $this->fetchRow($select);
        return (is_null($result)) ? null : $result->toArray();
    }
    
    /*
     * регулярки для проверки полей (логин,пароль,...)
     */
    protected function _checkLogin($login)
    {
        return (preg_match('/^[\w]{3,50}$/', $login));
    }
    protected function _checkPass($pass)
    {
        return ( mb_strlen($pass) >= 6 && mb_strlen($pass) <= 50 );
    }
    
}
