<?php

/*
 * переходы игроков по альянсам
 * 
 */
class App_Model_DbTable_TransSots extends App_Model_TransAbstract
{

    protected $_name = 'players_trans_dom';
    protected $_name2 = 'players_trans_colony';
    private $_ring = 0;
    

    
    public function clearOld( $days )
    {
        $where = $this->_db->quoteInto( 'date < NOW() - INTERVAL ? DAY', $days );
        $countDom = $this->delete( $where );
        $countMels = $this->_db->delete($this->_name2, $where);
        
        return array($countDom, $countMels);
    }


    public function setPlayerRing($idRing)
    {
        $this->_ring = intval($idRing);        
    }


    /*
     * переезды игрока 
     */
    protected function _getTransByPlayer( $idP, $limit )
    {
        $selectDom = $this->select()
                ->setIntegrityCheck(false)
                ->from($this,
                        array(
                            'old_adr' => "CONCAT( '{$this->_ring}.', old_compl, '.', old_sota)",
                            'new_adr' => "CONCAT( '{$this->_ring}.', new_compl, '.', new_sota)",
                            'date' => "DATE_FORMAT(`date` , '%H:%i %d.%m.%y')",
                            'sort_date' => 'date'))
                ->where("{$this->_name}.id_player = ?", $idP);
        
        $selectCol = $this->select()
                ->setIntegrityCheck(false)
                ->from($this->_name2,
                        array(
                            'old_adr' => "CONCAT( '4.', old_compl, '.', old_sota)",
                            'new_adr' => "CONCAT( '4.', new_compl, '.', new_sota)",
                            'date' => "DATE_FORMAT(`date` , '%H:%i %d.%m.%y')",
                            'sort_date' => 'date'))
                ->where("{$this->_name2}.id_player = ?", $idP);

        $select = $this->select()
                ->union(array($selectDom, $selectCol))
                ->order("sort_date DESC")
                ->limit( $limit );

        $result = $this->fetchAll($select);

        return ( !is_null($result) ) ? $result->toArray() : array();
    }
    
    /*
     * переезды игроков альянса 
     */
    protected function _getTransByAlliance( $idA, $limit )
    {
        $selectDom = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array(
                    'order_date' => "{$this->_name}.date",
                    'date' => "DATE_FORMAT({$this->_name}.date , '%H:%i %d.%m.%y')", 
                    'id' => 'id_player' ))
                ->join('players', "players.id = id_player",
                        array( 
                            'nik', 'id_rase', 
                            'old_adr' => "CONCAT_WS('.', ring, old_compl, old_sota)",
                            'new_adr' => "CONCAT_WS('.', ring, new_compl, new_sota)" ))
                ->where("players.id_alliance = ?", $idA);

        $selectCol = $this->select()
                ->setIntegrityCheck(false)
                ->from($this->_name2, array( 
                    'order_date' => "{$this->_name2}.date",
                    'date' => "DATE_FORMAT({$this->_name2}.date , '%H:%i %d.%m.%y')",
                    'id' => 'id_player') )
                ->join('players', "players.id = id_player",
                        array(
                            'nik', 'id_rase',
                            'old_adr' => "CONCAT( '4.', old_compl, '.', old_sota)",
                            'new_adr' => "CONCAT( '4.', new_compl, '.', new_sota)" ))
                ->where("players.id_alliance = ?", $idA);

        $select = $this->select()
                ->union(array($selectDom, $selectCol))
                ->order('order_date DESC')
                ->limit($limit);


        return $this->fetchAll($select)->toArray();
    }

     /*
     * переезды игроков мира
     */
    protected function _getTransByWorld( $idW, $date = null, $returnCount = false, $limit = 10 )
    {
        $data = array( "transes" => array( ), "count" => 0 );

        $selectDom = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array(
                    'order_date' => "{$this->_name}.date",
                    'date' => "DATE_FORMAT({$this->_name}.date , '%H:%i')", 
                    'id' => 'id_player') )
                ->join('players', "players.id = id_player", array( 
                    'nik', 'id_rase', 'id_alliance',
                    'old_adr' => "CONCAT_WS('.', ring, old_compl, old_sota)",
                    'new_adr' => "CONCAT_WS('.', ring, new_compl, new_sota)" ))
                ->join('alliances', 'alliances.id = players.id_alliance', array('alliance' => 'name'))
                ->where("players.id_world = ?", $idW);

        $selectCol = $this->select()
                ->setIntegrityCheck(false)
                ->from($this->_name2, array(
                    'order_date' => "{$this->_name2}.date",
                    'date' => "DATE_FORMAT({$this->_name2}.date , '%H:%i')", 
                    'id' => 'id_player') ) 
                ->join('players', "players.id = id_player", array( 
                    'nik', 'id_rase', 'id_alliance',
                    'old_adr' => "CONCAT( '4.', old_compl, '.', old_sota)",
                    'new_adr' => "CONCAT( '4.', new_compl, '.', new_sota)" ))                           
                ->join('alliances', "alliances.id = players.id_alliance", array('alliance' => 'name'))
                ->where("players.id_world = ?", $idW);        
                    
        if(is_null($date))
        {
            $selectDom->where("DATE({$this->_name}.date) = CURRENT_DATE");
            $selectCol->where("DATE({$this->_name2}.date) = CURRENT_DATE");
        }else{
            $selectDom->where("DATE_FORMAT({$this->_name}.date, '%d-%m-%Y') = ?", $date); 
            $selectCol->where("DATE_FORMAT({$this->_name2}.date, '%d-%m-%Y') = ?", $date);  
        }
           
        $select = $this->select()
                ->union(array($selectDom, $selectCol))                
                ->order("order_date DESC")
                ->limit( $limit );
                
        //берём количество общее
        if( $returnCount === true )
        {
            $adapter = new Zend_Paginator_Adapter_DbSelect($select);
            $count = $adapter->count();
        }

        //берём данные ограниченные
        if( ($returnCount === true && $count > 0) || $returnCount === false )
        {
            if(isset($count)) 
                $data["count"] = $count - $limit;            
            
            $data["transes"] = $this->fetchAll($select)->toArray();
        }

        return $data;
    }

   
    
    
}