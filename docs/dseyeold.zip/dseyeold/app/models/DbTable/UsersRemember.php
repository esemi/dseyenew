<?php

/*
 * восстановление пароля пользователей
 */
class App_Model_DbTable_UsersRemember extends Mylib_DbTable_Cached
{
    protected $_name = 'users_remember';
    protected $_cacheName = 'default';


    /*
     * наличие открытой заявки на восстановление
     *
    public function checkCount( $idU, $hours )
    {
        $select = $this->select()
                ->from( $this, array('count' => 'COUNT(*)') )
                ->where( 'id_user = ?', $idU )
                ->where( "date_create > NOW() - INTERVAL {$hours} HOUR" )
                ->where( "date_activate IS NULL" );
        $res = $this->fetchRow($select);
        
        return ( intval($res->count) === 0 ) ? true : false;
    }*/


    /*
     * поиск id юзера по токену восстановления пароля
     */
    public function findAndUpdToken( $token, $hours )
    {
        $select = $this->select()
                ->from( $this, array( 'id', 'id_user' ) )
                ->where( 'token = ?', $token )
                ->where( "date_create > NOW() - INTERVAL {$hours} HOUR" )
                ->where( "date_activate IS NULL" );
        $res = $this->fetchRow($select);

        if( !is_null($res) )
            $this->update(
                    array( 'date_activate' => new Zend_Db_Expr('NOW()') ),
                    array( "id = {$res->id}" ) );

        return ( !is_null($res) ) ? intval($res->id_user) : null;
    }


    /*
     * добавление нового запроса на воостановление пароля
     */
    public function add( $idU )
    {
        $token = hash('sha256', uniqid( mt_rand(), true ));
        $this->insert( array( 'id_user' => $idU, 'token' =>  $token ) );
        return $token;
    }


}
