<?php

/*
 * история пользователей
 */
class App_Model_DbTable_UsersHistory extends Mylib_DbTable_Cached
{
    protected $_name = 'users_history';
    protected $_cacheName = 'default';
    
    /*
     * добавление новой записи в историю юзера
     */
    public function add( $idU, $text, $request )
    {
        $this->insert( array(
            'id_user' => $idU,
            'action' =>  $text,
            'post' => serialize($request->getPost()),
            'agent' => $request->getServer('HTTP_USER_AGENT', 'undefined'),
            'ip' =>  new Zend_Db_Expr( $this->_db->quoteInto("INET_ATON(?)", $request->getClientIp()) ) ));
    }

    /*
     * получить несколько последних записей
     */
    public function lastOf( $idU, $count = 3 )
    {
        $select = $this->select();
        $select->from($this, array( 
                    'action',
                    'ip' => 'INET_NTOA(`ip`)',
                    'date' => 'DATE_FORMAT(`date_create` , \'%H:%i %d.%m.%Y\')' ))
               ->where('id_user = ?', $idU)
               ->order('date_create DESC')
               ->limit( $count );
        return $this->fetchAll($select);
    }

    /*
     * пагинатор полной истории юзера
     */
    public function listAll( $idU, $page, $count = 20 )
    {
        $select = $this->select();
        $select->from($this, array(
                    'action', 'agent',
                    'ip' => 'INET_NTOA(`ip`)',
                    'date' => 'DATE_FORMAT(`date_create` , \'%H:%i:%s %d.%m.%Y\')'))
               ->where('id_user = ?', $idU)
               ->order('date_create DESC');

        $paginator = Zend_Paginator::factory($select);
        $paginator->setCurrentPageNumber($page)
                ->setItemCountPerPage($count)
                ->setPageRange(5);

        return $paginator;
    }

}
