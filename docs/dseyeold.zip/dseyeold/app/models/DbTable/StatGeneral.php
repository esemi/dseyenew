<?php

/*
 * модель статистики миров и альянсов
 */
class App_Model_DbTable_StatGeneral extends Mylib_DbTable_Cached
{

    protected $_name = 'stat_general';

    /*
     * чистим старые данные
     */
    public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date_create < CURDATE() - INTERVAL ? DAY', $days ) );
    }


    /*
     * пришли/ушли за последний месяц
     */
    protected function _getLastIO( $idI, $type = 'w' )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser1' => 'input',
                            'ser2' => 'output',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                        ->where('id_item = ?', $idI)
                        ->where('type = ?', $type)
                        ->order('date_create DESC')
                        ->limit(30);
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * пришли/ушли за всё время (по месяцам)
     */
    protected function _getAllIO( $idI, $type = 'w' )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser1' => 'SUM(input)',
                            'ser2' => 'SUM(output)',
                            'date' => "DATE_FORMAT( `date_create` , '01.%m.%Y' )" ))
                        ->where('id_item = ?', $idI)
                        ->where('type = ?', $type)
                        ->group("DATE_FORMAT( `date_create` , '%m.%Y' )")
                        ->order('date_create DESC')
                        ->limit(6);
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * количество игроков
     */
    protected function _getCountPlayers( $idI, $type = 'w' )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser1' => '(count_voran + count_liens + count_psol)',
                            'ser2' => 'count_voran',
                            'ser3' => 'count_liens',
                            'ser4' => 'count_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                        ->where('id_item = ?', $idI)
                        ->where('type = ?', $type)
                        ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * количество колоний
     */
    protected function _getCountColonies( $idI, $type = 'w' )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser1' => 'count_colony',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                        ->where('id_item = ?', $idI)
                        ->where('type = ?', $type)
                        ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * количество альянсов
     */
    protected function _getCountAlliances( $idI, $type = 'w' )
    {
        $select = $this->select()
                        ->from($this, array(
                            'ser1' => 'count_alliance',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                        ->where('id_item = ?', $idI)
                        ->where('type = ?', $type)
                        ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общий рейтинг
     */
    protected function _getSumRank($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(rank_voran + rank_liens + rank_psol)',
                            'ser2' => 'rank_voran',
                            'ser3' => 'rank_liens',
                            'ser4' => 'rank_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средний рейтинг
     */
    protected function _getAvgRank($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((rank_voran + rank_liens + rank_psol) / (count_voran + count_liens + count_psol)), 0)',
                            'ser2' => 'IFNULL( ROUND(rank_voran / count_voran), 0)',
                            'ser3' => 'IFNULL( ROUND(rank_liens / count_liens), 0)',
                            'ser4' => 'IFNULL( ROUND(rank_psol / count_psol), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общий БО
     */
    protected function _getSumBO($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(bo_voran + bo_liens + bo_psol)',
                            'ser2' => 'bo_voran',
                            'ser3' => 'bo_liens',
                            'ser4' => 'bo_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средний БО
     */
    protected function _getAvgBO($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((bo_voran + bo_liens + bo_psol) / (count_voran + count_liens + count_psol)), 0)',
                            'ser2' => 'IFNULL( ROUND(bo_voran / count_voran), 0)',
                            'ser3' => 'IFNULL( ROUND(bo_liens / count_liens), 0)',
                            'ser4' => 'IFNULL( ROUND(bo_psol / count_psol), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общий НРА
     */
    protected function _getSumNRA($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(nra_voran + nra_liens + nra_psol)',
                            'ser2' => 'nra_voran',
                            'ser3' => 'nra_liens',
                            'ser4' => 'nra_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средний НРА
     */
    protected function _getAvgNRA($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((nra_voran + nra_liens + nra_psol) / (count_voran + count_liens + count_psol), 1), 0)',
                            'ser2' => 'IFNULL( ROUND(nra_voran / count_voran, 1), 0)',
                            'ser3' => 'IFNULL( ROUND(nra_liens / count_liens, 1), 0)',
                            'ser4' => 'IFNULL( ROUND(nra_psol / count_psol, 1), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общий РА
     */
    protected function _getSumRA($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(ra_voran + ra_liens + ra_psol)',
                            'ser2' => 'ra_voran',
                            'ser3' => 'ra_liens',
                            'ser4' => 'ra_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средний РА
     */
    protected function _getAvgRA($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((ra_voran + ra_liens + ra_psol) / (count_voran + count_liens + count_psol), 1), 0)',
                            'ser2' => 'IFNULL( ROUND(ra_voran / count_voran, 1), 0)',
                            'ser3' => 'IFNULL( ROUND(ra_liens / count_liens, 1), 0)',
                            'ser4' => 'IFNULL( ROUND(ra_psol / count_psol, 1), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средний уровень
     */
    protected function _getAvgLevel($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((avg_level_voran + avg_level_liens + avg_level_psol) / 3), 0)',
                            'ser2' => 'avg_level_voran',
                            'ser3' => 'avg_level_liens',
                            'ser4' => 'avg_level_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }


    /*
     * общая археология
     */
    protected function _getSumArch($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(archeology_voran + archeology_liens + archeology_psol)',
                            'ser2' => 'archeology_voran',
                            'ser3' => 'archeology_liens',
                            'ser4' => 'archeology_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средняя археология
     */
    protected function _getAvgArch($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((archeology_voran + archeology_liens + archeology_psol) / (count_voran + count_liens + count_psol)), 0)',
                            'ser2' => 'IFNULL( ROUND(archeology_voran / count_voran), 0)',
                            'ser3' => 'IFNULL( ROUND(archeology_liens / count_liens), 0)',
                            'ser4' => 'IFNULL( ROUND(archeology_psol / count_psol), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общее строительство
     */
    protected function _getSumBuild($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(building_voran + building_liens + building_psol)',
                            'ser2' => 'building_voran',
                            'ser3' => 'building_liens',
                            'ser4' => 'building_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * среднее строительство
     */
    protected function _getAvgBuild($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((building_voran + building_liens + building_psol) / (count_voran + count_liens + count_psol)), 0)',
                            'ser2' => 'IFNULL( ROUND(building_voran / count_voran), 0)',
                            'ser3' => 'IFNULL( ROUND(building_liens / count_liens), 0)',
                            'ser4' => 'IFNULL( ROUND(building_psol / count_psol), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * общая наука
     */
    protected function _getSumScien($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => '(science_voran + science_liens + science_psol)',
                            'ser2' => 'science_voran',
                            'ser3' => 'science_liens',
                            'ser4' => 'science_psol',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * средняя наука
     */
    protected function _getAvgScien($idI, $type = 'w')
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser1' => 'IFNULL( ROUND((science_voran + science_liens + science_psol) / (count_voran + count_liens + count_psol)), 0)',
                            'ser2' => 'IFNULL( ROUND(science_voran / count_voran), 0)',
                            'ser3' => 'IFNULL( ROUND(science_liens / count_liens), 0)',
                            'ser4' => 'IFNULL( ROUND(science_psol / count_psol), 0)',
                            'date' => "DATE_FORMAT( `date_create` , '%d.%m.%Y' )" ))
                       ->where('id_item = ?', $idI)
                       ->where('type = ?', $type)
                       ->order('date_create DESC');
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

}