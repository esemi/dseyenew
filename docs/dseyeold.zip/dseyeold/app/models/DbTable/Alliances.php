<?php

class App_Model_DbTable_Alliances extends Mylib_DbTable_Cached
{

    protected $_name = 'alliances';

    /*
     * листинг альянсов мира 
     */
    protected function _listWorldAlliances( $idW, $page, $countItem, $sort, $count = 20 )
    {
        $select = $this->select()
                ->from($this, array( 'id', 'name',
                    'count' => '(count_voran + count_liens + count_psol)',
                    'rank' => '(rank_voran + rank_liens + rank_psol)',
                    'bo' => '(bo_voran + bo_liens + bo_psol)',
                    'nra' => '(nra_voran + nra_liens + nra_psol) / (count_voran + count_liens + count_psol)',
                    'ra' => '(ra_voran + ra_liens + ra_psol) / (count_voran + count_liens + count_psol)',
                    'arch' => '(archeology_voran + archeology_liens + archeology_psol)',
                    'build' => '(building_voran + building_liens + building_psol)',
                    'scien' => '(science_voran + science_liens + science_psol)' ))
                ->where("status = 'active'")
                ->where('id_world = ?', $idW);

        $this->_sortDecode($select, $sort);

        $paginator = Zend_Paginator::factory($select);
        $paginator->getAdapter()->setRowCount($countItem);
        $paginator->setCurrentPageNumber($page)
                ->setItemCountPerPage($count)
                ->setPageRange(5);

        return $paginator;
    }

    /*
     * id-name альянсов для фильтра в поиске
     */
    protected function _getFilterAlliance( $idW, $count = 20 )
    {
        $select = $this->select();
        $select->from($this, array( 'id', 'name' ))
                ->where("status = 'active'")
                ->where('id_world = ?', $idW)
                ->order('(rank_voran + rank_liens + rank_psol) DESC')
                ->limit($count);
        $result = $this->fetchAll($select);

        $out = array();
        foreach ($result as $val)
            $out[$val['id']] = $val['name'];
        
        return $out;
    }


    /*
     * количество игроков в альянсе
     */
    protected function _getPlayersCount( $idA )
    {
        $select = $this->select()
                        ->from($this,
                               array( 'count' => '(count_voran + count_liens + count_psol)' ))
                        ->where('id = ?', $idA)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? (int) $result->count : 0;
    }

    /*
     * получить имя альянса по id
     */
    protected function _getName( $idA )
    {
        $select = $this->select()
                        ->from($this, array( 'name' ))
                        ->where('id = ?', $idA)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? $result->name : 'undefined';
    }

    /*
     * существует ли альянс с таким id в этом мире
     */
    public function validate( $idA, $idW )
    {
        $select = $this->select()
                        ->from($this, array( 'id' ))
                        ->where('id_world = ?', $idW)
                        ->where('id = ?', $idA)
                        ->limit(1);
        $result = $this->fetchRow($select);
        return ( !is_null($result) ) ? true : false;
    }

    /*
     * получить текущие свойства конкретного альянса
     */
    protected function _getCurProperty( $idA )
    {
        $select = $this->select()
                        ->from($this, array( 'name', 'status',
                            'FROM_UNIXTIME(`date_birth` , \'%d.%m.%Y\') as date_birth',
                            'FROM_UNIXTIME(`date_upd` , \'%H:%i %d.%m.%Y\') as date_upd',
                            'FROM_UNIXTIME(`date_delete` , \'%d.%m.%Y\') as date_delete',

                            'count' => '(count_voran + count_liens + count_psol)',

                            'sum_rank' => '(rank_voran + rank_liens + rank_psol)',
                            'sum_bo' => '(bo_voran + bo_liens + bo_psol)',
                            'sum_nra' => '(nra_voran + nra_liens + nra_psol)',
                            'sum_ra' => '(ra_voran + ra_liens + ra_psol)',
                            'sum_arch' => '(archeology_voran + archeology_liens + archeology_psol)',
                            'sum_build' => '(building_voran + building_liens + building_psol)',
                            'sum_scien' => '(science_voran + science_liens + science_psol)',

                            'avg_level' => 'ROUND((avg_level_voran + avg_level_liens + avg_level_psol) / 3 )',

                            'avg_rank' => 'ROUND((rank_voran + rank_liens + rank_psol) / (count_voran + count_liens + count_psol))',
                            'avg_bo' => 'ROUND((bo_voran + bo_liens + bo_psol) / (count_voran + count_liens + count_psol))',
                            'avg_nra' => 'ROUND((nra_voran + nra_liens + nra_psol) / (count_voran + count_liens + count_psol))',
                            'avg_ra' => 'ROUND((ra_voran + ra_liens + ra_psol) / (count_voran + count_liens + count_psol))',
                            'avg_arch' => 'ROUND((archeology_voran + archeology_liens + archeology_psol) / (count_voran + count_liens + count_psol))',
                            'avg_build' => 'ROUND((building_voran + building_liens + building_psol) / (count_voran + count_liens + count_psol))',
                            'avg_scien' => 'ROUND((science_voran + science_liens + science_psol) / (count_voran + count_liens + count_psol))'))
                        ->where('id = ?', $idA)
                        ->limit(1);

        $result = $this->fetchRow($select);
        return (!is_null($result) ) ? $result->toArray() : false;
    }

    /*
     * расшифровка столбца сортировки
     */
    private function _sortDecode($select, $sort)
    {
        switch ($sort)
        {
            case 'count':
                $select->order('count DESC');
                break;
            case 'count_r':
                $select->order('count ASC');
                break;
            case 'rank':
                $select->order('rank DESC');
                break;
            case 'rank_r':
                $select->order('rank ASC');
                break;
            case 'bo':
                $select->order('bo DESC');
                break;
            case 'bo_r':
                $select->order('bo ASC');
                break;
            case 'nra':
                $select->order('nra DESC');
                break;
            case 'nra_r':
                $select->order('nra ASC');
                break;
            case 'ra':
                $select->order('ra DESC');
                break;
            case 'ra_r':
                $select->order('ra ASC');
                break;
            case 'arch':
                $select->order('arch DESC');
                break;
            case 'arch_r':
                $select->order('arch ASC');
                break;
            case 'build':
                $select->order('build DESC');
                break;
            case 'build_r':
                $select->order('build ASC');
                break;
            case 'scien':
                $select->order('scien DESC');
                break;
            case 'scien_r':
                $select->order('scien ASC');
                break;
        }

    }
}
