<?php

/*
 * модель статистики игроков (занимает дохера так что даже без кеша)
 */
class App_Model_DbTable_StatPlayers extends Mylib_DbTable_Cached 
{

    protected $_name = 'stat_players';


    /*
     * добавляем округлённые по дням значения (для ротации)
     */
    public function addRotated( $days )
    {
        return $this->_db->query(
                "INSERT INTO {$this->_name}
                    SELECT NULL AS id, `id_player` , 
                           ROUND( AVG( `mesto` ) ) AS `mesto` , 
                           ROUND( AVG( `rank` ) ) AS `rank` , 
                           AVG( `bo` ) AS `bo` , 
                           ROUND( AVG( `nra` ) ) AS `nra` , 
                           AVG( `ra` ) AS `ra` , 
                           ROUND( AVG( `level` ) ) AS `level` , 
                           ROUND( AVG( `archeology` ) ) AS `archeology` , 
                           ROUND( AVG( `building` ) ) AS `building` ,
                           ROUND( AVG( `science` ) ) AS `science` ,
                           SUM( `delta_rank` ) AS `delta_rank` ,
                           SUM( `delta_bo` ) AS `delta_bo` ,
                           DATE_FORMAT( `date_create` , '%Y-%m-%d' ) AS `date_create` ,
                           1 AS rotated
                    FROM {$this->_name}
                    WHERE `date_create` < CURDATE( ) - INTERVAL :day DAY AND rotated =0
                    GROUP BY id_player, DATE_FORMAT( {$this->_name}.`date_create` , '%d.%m.%Y' )",
                array('day' => $days) );
    }


    /*
     * удаляем остатки от неокруглённых данных
     */
    public function clearRotated( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date_create < CURDATE() - INTERVAL ? DAY AND rotated = 0', $days ) );
    }


    /*
     * чистим старые данные
     */
    public function clearOld( $days )
    {
        return $this->delete( $this->_db->quoteInto( 'date_create < CURDATE() - INTERVAL ? DAY', $days ) );
    }


    /*
     * статистика для графиков
     */
    protected function _getStat($type ,$idP)
    {
        $select = $this->select()
                       ->from($this, array(
                            'ser' => $type,
                            'date' => "DATE_FORMAT( `date_create` , '%H.%d.%m.%Y' )" ))
                       ->where('id_player = ?', $idP)
                       ->order("date_create ASC");
        $result = $this->fetchAll($select);
        return (!is_null($result) ) ? $result->toArray() : array();
    }

    /*
     * преобразует данные в формат для сводного графика игрока
     */
    public function prepareForSingleGraph($type, $data)
    {
        $items = array(
            'rank' => 'Рейтинг',
            'bo' => 'БО',
            'nra' => 'НРА',
            'ra' => 'РА',
            'archeology' => 'Археология',
            'building' => 'Строительство',
            'science' => 'Наука',
            'mesto' => 'Место',
            'level' => 'Уровень');

        $out = new stdClass();
        $out->name = $items[$type];
        $out->realname = $type;
        $out->visible = true;
        $out->data = array();

        foreach( $data as $val )
            $out->data[] = array($val['date'], $val['ser']);        

        return array($out);
    }


    /*
     * статистика для сборного графика
     */
    protected function _getSummaryStat($idP)
    {
        $select = $this->select()
                       ->from($this, array(
                            'mesto', 'rank', 'bo', 'nra', 'ra', 'level',
                            'archeology', 'building', 'science',
                            'date' => "DATE_FORMAT( `date_create` , '%H.%d.%m.%Y' )" ))
                       ->where('id_player = ?', $idP)
                       ->order("date_create ASC");
        $result = $this->fetchAll($select);
        
        if(count($result) == 0)
            return false;

        $res = new stdClass();
        $res->data = $result->toArray();
        $res->borders = $this->_getSummaryMinMax($idP);
        
        return $res;
    }

    /*
     * получить минимальные и максимальные значения полей статистики
     */
    protected function _getSummaryMinMax($idP)
    {
        $select = $this->select()
                       ->from($this, array(
                            'mesto_min' => 'MIN(`mesto`)',
                            'rank_min' => 'MIN(`rank`)',
                            'bo_min' => 'MIN(`bo`)',
                            'nra_min' => 'MIN(`nra`)',
                            'ra_min' => 'MIN(`ra`)',
                            'level_min' => 'MIN(`level`)',
                            'archeology_min' => 'MIN(`archeology`)',
                            'building_min' => 'MIN(`building`)',
                            'science_min' => 'MIN(`science`)',

                            'mesto_max' => 'MAX(`mesto`)',
                            'rank_max' => 'MAX(`rank`)',
                            'bo_max' => 'MAX(`bo`)',
                            'nra_max' => 'MAX(`nra`)',
                            'ra_max' => 'MAX(`ra`)',
                            'level_max' => 'MAX(`level`)',
                            'archeology_max' => 'MAX(`archeology`)',
                            'building_max' => 'MAX(`building`)',
                            'science_max' => 'MAX(`science`)' ))
                       ->where('id_player = ?', $idP)
                       ->limit(1);
        return $this->fetchRow($select)->toArray();
    }


    /*
     * преобразует данные в формат для сводного графика игрока
     */
    public function prepareForSummaryGraph($data)
    {
        $items = array(
            'rank' => 'Рейтинг',
            'bo' => 'БО',
            'nra' => 'НРА',
            'ra' => 'РА',
            'archeology' => 'Археология',
            'building' => 'Строительство',
            'science' => 'Наука',
            //'mesto' => 'Место',
            'level' => 'Уровень',
            );
        
        $result = array();

        foreach( $items as $realname => $name )
        {
            $$realname = new stdClass();
            $$realname->name = $name;
            $$realname->realname = $realname;
            $$realname->data = array();
            $$realname->visible = (count($result) < 2 );
            $result[] = $$realname;
        }

        foreach( $data as $val )
            foreach( $items as $realname => $name )
                $$realname->data[] = array($val['date'], $val[$realname]);
        
        return $result;
    }

    
    /*
     * возвращает данные для csv новых рейтингов
     * @return paginator
     */
    public function getDataForCsv($idW, $limit)
    {
        $select = $this->select()
                ->setIntegrityCheck(false)
                ->from($this, array(
                    'id_player', 'archeology', 'building', 'science', 'date_create' ))
                ->join('players', "players.id = {$this->_name}.id_player", array())                
                ->where("players.id_world = ?", $idW)
                ->where("players.status = 'active'")
                ->order("{$this->_name}.id_player ASC")
                ->order("{$this->_name}.date_create DESC");
                
        $paginator = Zend_Paginator::factory($select);
        $paginator->setItemCountPerPage($limit);
        
        return $paginator;
    }

}