<?php

/* 
 * работает с логами кроновских скриптов
 * пишет в БД или файл
 *  Zend_Registry::get('log')
 */
class App_Model_CronlogMapper
{    
    protected $_type = null;
    protected $_db = null;
    protected $_mctimeStart = 0;
    protected $_timeStart = 0;

    public function __construct()
    {
        $opt =  Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('cronlog');
        
        $this->_mctimeStart = microtime(1);
        $this->_timeStart = time();
        $this->_db = new App_Model_DbTable_CronLogs();
        $this->_type = $opt['type'];
    }
    
    /*
     * сохранить лог
     */
    public function save($txt, $type)
    {
        $action = Zend_Controller_Front::getInstance()->getRequest()->getActionName();
        $txt .= $this->_getStat();
        
        switch ($this->_type)
        {
            case 'db':
                $this->_db->insert(array( 'type' => $type, 'text' => $txt ));                    
                echo date("d_F_Y__H:i")." {$action} log has been writen to DB\n";
            break;
            
            case 'file':                
                $handle = fopen( APPLICATION_PATH . "/logs/{$action}_" . date("d_F_Y__H-i", $this->_timeStart) . '.html' , 'w' );
                fwrite( $handle,  $txt);
                fclose( $handle );
                echo date("d_F_Y__H:i")." {$action} log file has been wrote\n";
            break;
            
            case 'text':  
                $txt = str_replace(array('<br>', '<br/>'), "\n", $txt); 
                echo $txt;  
            break;

            default : 
                echo "{$txt}\n";
            break;
        }
    }


    public function _getStat()
    {
       $profiler = Zend_Db_Table_Abstract::getDefaultAdapter()->getProfiler();       
       return sprintf("<br>time= %.4f; memory= %.4f; memory peak= %.4f; query_count= %d; query_time= %.4f <br>",
               microtime(1) - $this->_mctimeStart,
               memory_get_usage()/1024/1024,
               memory_get_peak_usage()/1024/1024, 
               $profiler->getTotalNumQueries(),
               $profiler->getTotalElapsedSecs());
    }
}
?>
