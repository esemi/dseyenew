<?php

/* 
 * простенький мапер
 * для доступа к адресу картинки с графиком РА игрока
 * для доступа и парсинга страниц с РА игроков по мирам
 */
class App_Model_DshelpMapper
{
    protected $_cache = null;
    protected $_nameW = '';
    protected $_errorData = '';
    protected $_userAgent = null;
    protected $_dataImg = null;
    protected $_prefixImg = 'dshelp_img_addr';


    public function __construct( $nameW )
    {
        $this->_nameW = $nameW;
        $this->_setCache();
        $this->_userAgent = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getOption('botname');
    }


    protected function _setCache()
    {
         $this->_cache = Zend_Controller_Front::getInstance()
                                ->getParam('bootstrap')
                                ->getResource('cachemanager')
                                ->getCache('long');
    }

    public function getErrors()
    {
        return $this->_errorData;
    }


    /*
     * получить хеш первой страницы
     */
    public function getFirstPage()
    {
        $url = $this->_prepareLinkPlayers( 0 );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->_userAgent);
        $response = iconv("Windows-1251", "UTF-8", curl_exec($ch));
        $err = curl_error($ch);
        curl_close($ch);

        if( $err != '' )
        {
            $this->_errorData .= "{$url} - {$err}<br>";
            return false;
        }else{
            return $response;
        }
    }


    /*
     * получить страницу со списком игроков
     */
    public function getPageSource( $num )
    {
        $url = $this->_prepareLinkPlayers( $num );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->_userAgent);
        $response = iconv("Windows-1251", "UTF-8", curl_exec($ch));
        $err = curl_error($ch);
        curl_close($ch);
        
        if( $err != '' )
        {
            $this->_errorData .= "{$url} - {$err}<br>";
            return false;
        }else{
            return $response;
        }

    }

    
    /*
     * парсинг страницы игроков строки с параметрами игроков
     */
    public function parsePlayersPage( $source )
    {
        //ищем наш кусочек таблички
        $pos = strpos( $source, '<table summary="" border="1" cellpadding="1" cellspacing="0">');
        $offset = strpos( $source, '</table>', $pos) - $pos;
        return explode('</tr>', substr($source, $pos, $offset));
    }

    /*
     * парсинг строки на ник и РА
     */
    public function parsePlayersStr( $str )
    {
        $values = explode('</td>',  str_replace(' ', '', $str));
        
        //не битая ли строка
        if( count($values) != 9 )
        {
            echo "строка битая" . count($values);
            return false;
        }

        //выдираем ник
        $nik = preg_match('/index.html>[\w]{3,50}<\/a>/', $values[1], $matches);
        if( !isset($matches[0]) )
        {            
            echo "ник не найден {$values[1]}";
            return false;
        }
        
        $nik = substr($matches[0], 11, -4);
        if( !preg_match('/^[\w]{3,50}$/i',$nik) )
        {
            echo "стрёмный ник {$nik}";
            return false;
        }

        //выдираем РА
        $ra = substr($values[5],13);
        if( !preg_match( '/^[\d]{1,3}(|[.][\d]{1,2})$/',$ra) )
        {
            echo "стрёный РА {$ra}";
            return false;
        }

        return array( $nik, $ra );
    }


    /*
     * получить урл на картинку с графиком
     */
    public function getUrl( $nik, $idP )
    {
        if ( !$url = $this->_getImgFromCache( $idP ) )
            $url = $this->_getImgFromHttp( $nik, $idP );
        return $url;
    }
        


    /*
     * получаем данные с сайта либо false
     */
    protected function _getImgFromHttp( $nameP, $idP )
    {
        $url = $this->_prepareLinkImg( $nameP );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_USERAGENT, $this->_userAgent);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        
        if( $err != '' )
        {
            $this->_errorData .= "{$url} - {$err}<br>";
            return false;
        }
        
        $this->_dataImg = $this->_parseImg( $response );

        if( $this->_dataImg != false )
            $this->_saveImgToCache( $idP );
        
        return $this->_dataImg;
    }


    /*
     * получаем ссылку из кеша либо false
     */
    protected function _getImgFromCache( $idP )
    {
        return ( is_null($this->_cache) ) ?
                false 
                :
                $this->_cache->load("{$this->_prefixImg}_{$idP}");
    }


    /*
     * сохраняем данные в мемкеш
     */
    protected function _saveImgToCache( $idP )
    {
        $this->_cache->save($this->_dataImg, "{$this->_prefixImg}_{$idP}");
    }

    /*
     * составляем ссылку для запроса картинки
     */
    protected function _prepareLinkImg( $nameP )
    {
        return "http://dshelp.info/{$this->_nameW}/player/{$nameP}/index.html";
    }

    /*
     * составляем ссылку для запроса страницы с игроками
     */
    protected function _prepareLinkPlayers( $num )
    {
        return "http://dshelp.info/{$this->_nameW}/players/{$num}/index.html";
    }

    /*
     * парсим ответ и отдаём ссылку
     */
    protected function _parseImg( $data )
    {
        preg_match( "/http:\/\/dshelp\.info\/{$this->_nameW}\/[\d]+\/g20.png/", $data, $matches);
        return (count($matches)) ? array_shift($matches) : false;
    }


    


}
?>
