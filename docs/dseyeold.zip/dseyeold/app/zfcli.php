<?php

define('APPLICATION_ENV','cli');

define('APPLICATION_PATH', realpath(dirname(__FILE__)));

define('ZEND_PATH', realpath(dirname(__FILE__) . '/../../Zend'));

define('WWW_PATH', realpath(dirname(__FILE__) . '/../www') );

define('LOG_PATH', realpath(dirname(__FILE__) . '/../../logs/dseye'));

set_include_path(implode(PATH_SEPARATOR, array(
    ZEND_PATH,
    get_include_path()
)));


// Zend_Application
require_once 'Zend/Application.php';

$application = new Zend_Application(
    APPLICATION_ENV,
    APPLICATION_PATH . '/configs/application.ini'
);


try
{
    $opts = new Zend_Console_Getopt(
        array(
            'help|h' => 'Displays usage information.',
            'action|a=s' => 'onlinestat | dshelpra | newranks | csv | scavenger',
        )
    );
    $opts->parse();
    
}catch (Zend_Console_Getopt_Exception $e) {
    exit($e->getMessage() ."\n\n". $e->getUsageMessage());
}

if(isset($opts->h))
    exit($opts->getUsageMessage());


switch ($opts->a)
{
    //сборщик мусора и ротатор статистики
    case 'scavenger':
        $request = new Zend_Controller_Request_Simple('scavenger','cli');
    break;

    //сбор статистики по онлайну
    case 'onlinestat':
        $request = new Zend_Controller_Request_Simple('onlinestat','cli');
    break;
    
    //обновление РА игроков одного мира
    case 'dshelpra':
        $request = new Zend_Controller_Request_Simple('dshelpra','cli');
    break;

    //обновление новых рейтингов игроков одного мира
    case 'newranks':
        $request = new Zend_Controller_Request_Simple('newranks','cli');
    break;

    //обновление собственных csv
    case 'csv':
        $request = new Zend_Controller_Request_Simple('csv','cli');
    break;
   
}

if(!isset($request))
    exit('Запрос не составлен (Cli error)');


$front = $application->getBootstrap()
        ->bootstrap('frontController')
        ->getResource('frontController');

$front->setRequest($request)
      ->setResponse(new Zend_Controller_Response_Cli())
      ->setRouter(new Mylib_Router_Cli())
      ->throwExceptions(true);

$application->bootstrap()
            ->run();


?>
