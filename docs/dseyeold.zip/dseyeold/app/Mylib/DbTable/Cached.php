<?php

/**
 * Кеширующая прослойка для zend_db_table
 *
 * @desc кэш работает через __call метод
 _{method} для получения данных из БД
 */
abstract class Mylib_DbTable_Cached extends Zend_Db_Table_Abstract
{
    protected $_cache = null,
              $_cacheName = 'up';

    public function init()
    {
        parent::init();
        $this->_setCache();
    }

    protected function _setCache()
    {
        $this->_cache = Zend_Controller_Front::getInstance()
                                ->getParam('bootstrap')
                                ->getResource('cachemanager')
                                ->getCache($this->_cacheName);
    }
    
    /*
     * проверяет, существует ли метод "_{$method}"
     * пробует считать из кеша
     * сохраняет в кеш
     * кидает исключения
     */
    public function __call( $method, $opt)
    {   
        $signature = "{$this->_name}_{$method}_" . md5(serialize($opt)); //сигнатура метода по опциям
        $methodDB = "_{$method}"; //имя метода обращения к ДБ

        if( !method_exists($this, $methodDB) )
            throw new Exception("Method {$methodDB} for DB not found! Cache crash =(");

        if( !( $data = $this->_cache->load($signature) ) )
        {
            $data = call_user_func_array(array($this, $methodDB), $opt);
            $this->_cache->save($data, $signature);
        }

        return $data;
    }

}
