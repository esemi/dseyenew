<?php
/*
 * добавляет js код для построения графиков
 * по мирам, альянсам, игрокам и онлайн статистики (кроме живого графика)
 * (данные + вызов функции)
 */

class Zend_View_Helper_AddGraphCode extends Zend_View_Helper_Abstract
{
    /*
     * $delta = array(date=>value)
     *
     * $opt = array(
     *    type - (bar|line|area|customOnline)
     *    series - array
     *    isset(hideRase)
     *    isset(delta) 
     * )
     */
    public function AddGraphCode( $opt, $data, $delta = array() )
    {
        if( count($data) == 0 )
            return false;

        //цветовая гамма
        if($opt['type'] == 'bar')
        {
            $color = "['#4f7942','#c41e3a']";
        }else{
            $color = "['#3d261f','#ff6f00','#136100','#050094']";
        }

        $this->view->headScript()->captureStart(); ?>

        jQuery(document).ready(function()
        {
            var legend = <?php echo (count($opt['series']) != 0) ? 'true' : 'false'; ?>;
            var graphSeries = [
                <?php for($i=1;$i<=$opt['count'];$i++) : ?>
                    {
                      name: '<?php echo ( isset($opt['series'][$i-1])  ) ? $opt['series'][$i-1] : 'Всего'; ?>',
                      data:
                      [
                        <?php
                        foreach( $data as $val )
                        {
                            //расшифровываем дату
                            $date = $this->_decodeDate( $val['date'] );
                            echo "[ {$date}, {$val["ser{$i}"]} ],";                            
                        }
                        ?>
                      ],
                      visible: <?php echo ( ($i > 1) && isset($opt['hideRase']) && $opt['hideRase'] == true) ? 'false' : 'true'; ?>
                    },
                <?php endfor; ?>
            ];
            
            var deltaHash = makeDeltaHash([
                <?php
                if( isset($opt['delta']) )
                {
                    foreach($delta as $deltaDate => $deltaVal)
                    {
                        echo "{ date:" . $this->_decodeDate($deltaDate) . ", ser:0, val: {$deltaVal}},";
                    }
                }
                ?>
            ]);
        <?php

        $zoom = ( isset($opt['zoom']) ) ? $opt['zoom'] : 7;


        switch ($opt['type'])
        {
            case 'bar':
                   echo  "drawColumnGraph('graph-container', '{$opt['name']}', '{$opt['dateFormat']}', graphSeries, {$color} , legend);";
            break;
            case 'line':
                   echo  "drawStatGraphLine('graph-container', '{$opt['name']}', '{$opt['dateFormat']}', graphSeries, {$opt['reduce']}, {$color} , legend, {$zoom}, deltaHash);";
            break;
            case 'area':
                   echo  "drawStatGraphFill('graph-container', '{$opt['name']}', '{$opt['dateFormat']}', graphSeries, {$opt['reduce']}, {$color} , legend, {$zoom}, deltaHash);";
            break;
            case 'customOnline':
                   echo  "drawStatGraphFill('graph-container', '{$opt['name']}', '{$opt['dateFormat']}', graphSeries, {$opt['reduce']}, {$color} , legend, 1, deltaHash);";
            break;
        }
        echo '});';
        $this->view->headScript()->captureEnd();
    }
    

    /*
     * расшифровка даты в формат UTC
     */
    private function _decodeDate($date)
    {
        $date = explode('.',$date);
        //var_dump($date);
        if(count($date) == 3){ //дни
            $date[1] = $date[1]-1;
            return "Date.UTC( {$date[2]}, {$date[1]}, {$date[0]}, 00, 00)";
        }elseif(count($date) == 4){ // +часы
            $date[2] = $date[2]-1;
            return "Date.UTC( {$date[3]}, {$date[2]}, {$date[1]}, {$date[0]}, 00)";
        }else{ // +минуты
            $date[3] = $date[3]-1;
            return "Date.UTC( {$date[4]}, {$date[3]}, {$date[2]},  {$date[1]}, {$date[0]})";
        }
    }
    

}
