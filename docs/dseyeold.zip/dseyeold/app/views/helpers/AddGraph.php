<?php
/*
 * добавляет js код для загрузки и построения графиков
 * @param type string {player|online}
 */
class Zend_View_Helper_AddGraph extends Zend_View_Helper_Abstract
{
    public function addGraph( $type )
    {
        $this->view->headScript()->captureStart();
        echo "jQuery(document).ready(function(){";

        switch( $type )
        {
            case 'player':
                echo "jQuery('.js-graph-menu-player li:first').trigger('click');";
                break;
            case 'online':
                echo "jQuery('.js-graph-menu-online li:first').trigger('click');";
                break;
            case 'live':
                echo "loadAndDrawLiveGraph();";
                break;
            default:
                throw new Exception('Error type in view helper "addGraph"');
                break;
        }

        echo "});";
        $this->view->headScript()->captureEnd();
    }    

}
