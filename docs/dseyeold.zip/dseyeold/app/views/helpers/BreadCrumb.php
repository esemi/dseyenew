<?php
class Zend_View_Helper_BreadCrumb extends Zend_View_Helper_Abstract
{
    public function breadCrumb( $crumbs )
    {
        if( !is_array($crumbs) || count($crumbs) == 0 )
            throw new Exception( 'Error crumbs array in breadCrumb helper' );

        $str = implode(' &mdash; ', $crumbs);

        printf('<div class="main-width rubber-block"><h2 class="mrg-left-21 small-title mrg-bottom-13">%s</h2></div>',$str);
    }


}
