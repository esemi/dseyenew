<?php
class Zend_View_Helper_PrintDelta extends Zend_View_Helper_Abstract
{
    public function printDelta( $delta )
    {
        //цвет дельты
        $class = '';
        if( $delta != 0 )
            $class = ($delta > 0) ? 'color-green' : 'color-red';

        //само значение        
        $delta = ( $delta > 0 ) ?
                '+' . $this->view->NumFormat($delta)
                :
                $this->view->NumFormat($delta);


        printf('<span class="%s">%s</span>', $class, $delta);
    }
}
