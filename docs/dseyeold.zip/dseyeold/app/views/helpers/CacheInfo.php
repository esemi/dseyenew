<?php

class Zend_View_Helper_CacheInfo extends Zend_View_Helper_Abstract
{
    public function CacheInfo()
    {
        $manager = Zend_Controller_Front::getInstance()->getParam('bootstrap')->getResource('cachemanager');

        return sprintf('Кеш релевантен до %s', date('H:i d.m.Y', time() + $manager->getCache('up')->getOption('lifetime')) );
    }
}
