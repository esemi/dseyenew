jQuery(document).ready(function()
{
        loadImage = '<img src="/img/load.gif" />';

        //редирект по мирам из выпадающего списка
        jQuery('.js-world-select').change(function()
        {
            var href = jQuery(this).val();
            if( typeof href != 'undefined' )
                location = href;
        });
        
           
        //переход вверх страницы
        jQuery(".js-get-top").click(function()
        {
            window.scroll(0,0);
        });


        //фокус на поле формы
        jQuery('.js-form-focus:first').focus();


        //тултипс с вопросительной инфой
        jQuery(".js-quest-tooltip").tooltip(
        {
            bodyHandler: function(){return jQuery(this).attr('tooltip');},
            delay: 0,
            track: true,
            extraClass: "quest-tooltip"
        });
        
/**кластеризация********************************************************************/
        //открыть предварительное исследование
        jQuery('.js-clust-toggle').click(function()
        {
           jQuery(".js-clust-hide").toggle(); 
        });
        
        //выбор мира
        jQuery('.js-clust-select').change(function()
        {
            var path = '/clusters/';
            var name = jQuery(this).val();
            if( typeof name == 'undefined' )
                return;
            
            var cont = jQuery(".js-clust-computed"); 
            
            cont.hide(); 
            
            var adr = ['_dendro.png','_mst.png','_clusters_count.png'];
            var i =0;
            cont.children('a').each(function()
            {   
                var tmp = path + name + adr[i];
                this.href = tmp;
                this.children[0].src = tmp;
                i++;
            });
            
            var hrefs = cont.find('.js-clust-csv a');             
            hrefs[0].href = path + name + '_result.csv';
            hrefs[1].href = path + name + '_hierarhy.csv';
            hrefs[2].href = path + name + '_graph.csv';
            hrefs[3].href = path + name + '_kmeans.csv';
            
            cont.show();
        });

/**о проекте************************************************************************/
        //открыть-закрыть техническую информацию
        jQuery(".js-slider").click(function()
        {
            jQuery(this).toggleClass('color-logo');
            jQuery(this).toggleClass('pseudo');
            jQuery(this).parent().children('div').slideToggle("normal");
        });



        //тултипс с подробностями по фидбеку
        jQuery(".js-feedback-tooltip").tooltip(
        {
            bodyHandler: function(){
                return jQuery(this).next(".hide").html();
            },
            delay: 0,
            track: true,
            extraClass: "feedback-tooltip"
        });
        

        //фидбек +1
        jQuery(".js-feedback").click(function()
        {
            var idF = jQuery(this).parent().parent().attr('idF');

            jQuery(".js-feedback-result").html(loadImage);

            jQuery.post('/ajax/feedback/',
            {
                'idF': idF,
                'format': 'json'
            },
            function(data){
                jQuery(".js-feedback").addClass('feedback-off');                
                jQuery(".js-feedback").removeClass('js-feedback feedback-on');
                jQuery(".js-feedback-result").html(data.result);
            },
            'json');
        });

/**новости**************************************************************************/
        //открыть-закрыть новость
        jQuery(".js-news").click(function()
        {
            toggleNews(this, 'toggle');
        });

        //открываем блок при переходе к новости с другой страницы
        var idN  = parseInt( document.location.hash.substr(5), 10);
        var node = document.getElementsByName('item' + idN);
        if ( idN != '' && node.length === 1)
        {
            toggleNews(node[0].parentNode, 'toggle');
        }


        //открыть все новости
        jQuery(".js-open-all-news").click(function()
        {
            jQuery(".js-news").each(function()
            {
                toggleNews(this, 'open');
            });
        });

        //закрыть все новости
        jQuery(".js-close-all-news").click(function()
        {
            jQuery(".js-news").each(function()
            {
                toggleNews(this, 'close');
            });
        });

/*контакты**************************************************************************/
        //связаться с нами
        jQuery("#js-form").submit(function()
        {
            if( formValidate() === false )
                return false;

            //jQuery(this).find(".js-form-button").attr("disabled",true);

            var contact = jQuery(this).find('[name="contact"]').val();
            var text = jQuery(this).find('[name="text"]').val();

            jQuery(".js-form-result").html(loadImage);

            jQuery.post('/ajax/form/',
            {
                'contact': contact,
                'text': text,
                'format': 'json'
            },
            function(data)
            {
                //jQuery("#js-form [name=text], #js-form [name=type], #js-form [name=contact]").val("");
                jQuery(".js-form-result").html(data.result);
            },
            'json');

            return false;
        });

/**статистика онлайна***************************************************************/
    //меню по графикам статистики онлайна
    jQuery('.js-graph-menu-online li').click(function()
    {        
        loadAndDrawOnlineGraph(jQuery(this));
    });


/**изменения мира*******************************************************************/
        //создаём датапикер для быстрого перехода
        if (typeof minDate != 'undefined' && typeof worldID != 'undefined')
        {
            jQuery('#js-datepicker').datepicker(
            {
                dateFormat: 'dd-mm-yy',
                firstDay: 1,
                hideIfNoPrevNext: true,
                minDate: minDate,
                maxDate: "Today",
                onSelect: function(dateText, inst)
                {
                    if( /^[\d]{2}-[\d]{2}-[\d]{4}$/.test(dateText) === true )
                    {
                        location = '/world/'+worldID+'/history/'+dateText+'/view.html';
                    }else{
                        alert('error 408');
                    }

                }
            });
        }
                    
        



/**поиск игроков********************************************************************/
        //быстрый поиск по нику (по миру и глобальный в сервисах)

        //проверка на частые запросы
        var postSearch = null;
        var lockMicroTime = 0;      

        jQuery(".js-search-term").bind("keyup change", function()
        {
            //новый локтайм и внутреннее время
            lockMicroTime = new Date().getTime();
            var innerTime = lockMicroTime;
            var target = this;
           
            //ждём 200 милисекунд и запускаем запрос с проверками
            //@TODO переписать на замыкание (IE8 bug =( )
            setTimeout(function()
            {   
                if(lockMicroTime != innerTime)
                    return false;
                
                var idW = jQuery(target).attr('idW');
                var term = jQuery.trim( jQuery(target).val() );
                var result = jQuery(".js-search-result");
                var colSpan = ( typeof idW == 'undefined') ? 5 : 6;
                result.parent().removeClass('hide');

                if( /^[\wА-ЯЁа-яё\s.-]{3,30}$/.test(term) !== true )
                {
                    result.html('<tr><td colspan="'+colSpan+'">Такое условие поиска недопустимо.</td></tr>');
                    return false;
                }

                //обрубаем лишние запросы
                if (postSearch != null)
                    postSearch.abort();

                result.html('<tr><td colspan="'+colSpan+'">'+loadImage+'</td></tr>');

                postSearch = jQuery.post('/ajax/search/',
                {
                    'idW': ( typeof idW == 'undefined') ? 0 : idW,
                    'term': term,
                    'format': 'html'
                },
                function(data){
                    postSearch = null;
                    result.html(data);
                },
                'html');

            },200);

        });



        //toggle быстрый
        jQuery(".js-fast-search-slider").click(function()
        {
            jQuery('.js-full-search-form').slideUp('fast');
            jQuery('.js-fast-search-form').slideToggle("normal");
        });
        //toggle расширенный
        jQuery(".js-full-search-slider").click(function()
        {
            jQuery('.js-fast-search-form').slideUp('fast');
            jQuery('.js-full-search-form').slideToggle("normal");
        });

        //создаём слайдеры
        jQuery(".js-ui-slider" ).each(function()
        {
            drawSlider( this );
        });

        //скрыть\открыть форму выбора фильтров по алам
        jQuery("#alliance").change(function()
        {            
            if( jQuery(this).val() == 'none' )
            {
                jQuery('.js-alliance-filter').slideUp('fast');;
            }else{
                jQuery('.js-alliance-filter').slideDown('fast');
            }

        });


        //проверка сладеров (ручной ввод)
        jQuery(".js-advanced-search").submit(function()
        {
            var result = true;
            jQuery(".js-slider-validate").each(function()
            {
                var min = jQuery(this).find('input:first').val();
                var max = jQuery(this).find('input:last').val();
                    
                if( parseInt(min) < 0 || parseInt(max) < 0 ||
                    parseInt(min) >= parseInt(max) ||
                    /^[0-9]+$/.test(min) != true ||
                    /^[0-9]+$/.test(max) != true )
                {
                    jQuery(this).find('input').addClass('invalid-form');
                    result = false;
                }else{
                    jQuery(this).find('input').removeClass('invalid-form');
                }
            });
            
            return result;
        });


/**карта колец******************************************************************************/

        if (document.getElementById('mycarousel') != null)
        {
            //ширина монитора - кол-во выводимых комплов
            var width = parseInt(jQuery("#mycarousel").width());

            //180 - ширина одного столбца
            //20 - ширина боковых столбцов цифр
            //40 - ширина стрелок по бокам
            var len = Math.floor( ( width - (20*2 + 40*2) ) / 180 );
            len = (len > 4) ? len : 4;


            //создаём и рисуем карту с заданными настройками
            var myCarousel = new Carousel(
                jQuery("#mycarousel .js-map-container"),
                jQuery('.js-map-info'),
                jQuery('#mycarousel .js-map-full-info-window.active'),
                len,
                parseInt(jQuery('.js-map-scroll').val()), 
                worldID, 
                parseInt(jQuery('.js-map-ring').val()), 
                maxCompl );

            //первоначальный инит карты
            myCarousel.draw();
            
            //кнопка "вправо"
            jQuery('.js-map-right').click( function()
            {
                myCarousel.right();
            });

            //кнопка "лево"
            jQuery('.js-map-left').click( function()
            {
                myCarousel.left();
            });

            //быстрый переход
            jQuery('.js-map-ring').change( function()
            {
                myCarousel.changeRing( jQuery('.js-map-ring').val() );
            });

            //изменение скорости прокрутки
            jQuery('.js-map-scroll').change( function()
            {
                myCarousel.changeScroll( jQuery('.js-map-scroll').val() );
            });

            //быстрый переход к комплу
            jQuery('.js-map-goto').bind('change click keyup', function()
            {
                var num = jQuery(this).val();
                //console.log(num);
                if( /^[0-9]+$/.test(num) )
                {
                    myCarousel.goTo( num );
                }
            });

            //переключение активного окошка подробной инфы
            jQuery('.js-map-full-info-window').click( function()
            {                
                jQuery('.js-map-full-info-window').addClass('deactive').removeClass('active');                
                jQuery(this).removeClass('deactive').addClass('active');
                
                jQuery('.js-map-full-info-window[empty].deactive').html('<div class="color-gray-map font-20 text-center mrg-top-75">Нажмите чтобы активировать</div>');         
                jQuery('.js-map-full-info-window[empty].active').html('');
                
                myCarousel.setPlayerInfoBox( jQuery(this) );                
            });
            

        }


/**регистрация юзера******************************************************************/
        //проверка сложности пароля при вводе (в профиле тоже)
        jQuery("input[name='pass']").bind("keyup change click", function()
        {
            var myClass = '';
            var value = jQuery(this).val();
            var res = complexityPass(value);
            
            if( res <= 1 )
                myClass = 'pass-light1';
            else if( res == 2 )
                myClass = 'pass-light2';
            else if( res == 3 )
                myClass = 'pass-light3';
            else if( res == 4 )
                myClass = 'pass-light4';
            else
                myClass = 'pass-light5';

            jQuery('.js-pass-strong').removeClass('pass-light1 pass-light2 pass-light3 pass-light4 pass-light5');
            jQuery('.js-pass-strong').addClass( myClass );            
        });

        //проверка полей формы регистрации
        jQuery("#registerform input[type!='submit']").bind("keyup change click", function()
        {
            var countErr = 0;

            var login = jQuery('#registerform input[name="login"]');
            if( !checkFormInput(/^[\w]{3,50}$/.test( login.val() ), login) )
                countErr++;

            var pass = jQuery('#registerform input[name="pass"]');
            if( !checkFormInput( (pass.val().length >= 6 && pass.val().length <= 50), pass) )
                countErr++;

            var repass = jQuery('#registerform input[name="repass"]');
            if( !checkFormInput( pass.val() == repass.val() , repass) )
                countErr++;

            if(countErr == 0)
                jQuery("#registerform input[type='submit']").removeAttr("disabled");
            else
                jQuery("#registerform input[type='submit']").attr("disabled", "disabled");            
        });


/**профиль юзера******************************************************/

        //проверка паролей при изменении оных в профиле юзера
        jQuery(".js-user-pass-update-form input[type!='submit']").bind("keyup change click", function()
        {
            var countErr = 0;

            var oldpass = jQuery('.js-user-pass-update-form input[name="oldpass"]');
            if( !checkFormInput( (oldpass.val().length >= 6 && oldpass.val().length <= 50), oldpass) )
                countErr++;

            var pass = jQuery('.js-user-pass-update-form input[name="pass"]');
            if( !checkFormInput( (pass.val().length >= 6 && pass.val().length <= 50), pass) )
                countErr++;

            var repass = jQuery('.js-user-pass-update-form input[name="repass"]');
            if( !checkFormInput( pass.val() == repass.val() , repass) )
                countErr++;

            if(countErr == 0)
                jQuery(".js-user-pass-update-form-submit").show();
            else
                jQuery(".js-user-pass-update-form-submit").hide();
        });

        //отправка запроса на изменение пароля и обработка ошибок
        jQuery(".js-user-pass-update-form-submit").click(function()
        {
            if( !confirm( 'Вы уверены, что хотите сменить пароль?' ) )
                return false;
            
            var form = jQuery('.js-user-pass-update-form');
            var result = jQuery(".js-ajax-result");
            
            result.html(loadImage);

            jQuery.post('/ajax/userpassedit/',
            {
                'oldpass': form.find('input[name="oldpass"]').val(),
                'pass': form.find('input[name="pass"]').val(),
                'repass': form.find('input[name="repass"]').val(),
                'csrf': jQuery('#js-csrf-token').val(),
                'format': 'json'
            },
            function(data)
            {
                if( typeof data.error != 'undefined' )
                {
                    printMessage('error', data.error, result);
                }else{
                    printMessage('success', data.success, result);
                    jQuery('.js-user-pass-update-form-show').remove();
                    form.remove();
                }
            },
            'json');
        });

        //показать форму по кнопке изменить
        jQuery('.js-user-pass-update-form-show').click(function()
        {
            jQuery(this).hide();
            jQuery('.js-user-pass-update-form').show();
        });

        //скрыть форму по кнопке отмена
        jQuery('.js-user-pass-update-form-hide').click(function()
        {
            jQuery('.js-user-pass-update-form-show').show();
            jQuery('.js-user-pass-update-form').hide();
        });
        

/**автопоиск авторизованных юзеров*********************************************************/

        //показать форму добавления/редактирования
        jQuery('.js-autosearch-form-show').click(function()
        {
            jQuery('.js-autosearch-form').show();
        });

        //скрыть форму по отмене
        jQuery('.js-autosearch-form-hide').click(function()
        {
            jQuery('.js-autosearch-form').hide();
        });
        
        //сохранить c проверками
        jQuery('.js-autosearch-form-submit').click(function()
        {            
            var result = jQuery(".js-ajax-result");
            var form = jQuery('.js-autosearch-form');

            var type = form.find('input[name="typesearch"]:checked').val();

            var href = null;
            var post = {
                'prop': form.find('input[name="property"]').val(),
                'csrf': jQuery('#js-csrf-token').val(),
                'format': 'json'
            };

            if( type == 'new' )
            {
                href = '/ajax/autosearchsavenew/';
                post['newname'] = form.find('input[name="new_name"]').val();
                post['idW'] = worldID;

                if( !checkFormInput( (post['newname'].length > 0 && post['newname'].length <= 150 ), form.find('input[name="new_name"]') ) )
                    return;                

            }else if( type == 'edit' ){
                href = '/ajax/autosearchsaveas/';
                post['idA'] = form.find('select[name="edit_name"]').val();
            }

            if( href != null )
            {
                result.html(loadImage);

                jQuery.post(href, post, function(data)
                {
                    if( typeof data.error != 'undefined' )
                    {
                        printMessage('error', data.error, result);
                    }else{
                        printMessage('success', data.success, result);
                        jQuery('.js-autosearch').remove();
                    }
                },
                'json');
            }

        });

        //удаление конкретного автопоиска из личного кабинета
        jQuery('.js-autosearch-delete').click( function()
        {
            if( !confirm( 'Вы уверены, что хотите удалить данный автопоиск?' ) )
                return false;

            var container = jQuery(this).parents('li:first');
            var result = jQuery(".js-ajax-result");            
            var idA = jQuery(this).attr('idA');

            result.html(loadImage);

            jQuery.post(
                '/ajax/autosearchdel/',
                {
                    'idA': idA,
                    'csrf': jQuery('#js-csrf-token').val(),
                    'format': 'json'
                },
                function(data)
                {
                    if( typeof data.error != 'undefined' )
                    {
                        printMessage('error', data.error, result);
                    }else{
                        printMessage('success', data.success, result);
                        container.remove();
                    }
                },
                'json');
        });
        
/**списки игроков/алов**************************************************************/

    //выделение строки по клику на неё
    jQuery('.js-table-select tbody tr').live('click', function(e)
    {
        if( e.target.nodeName == 'A' )
            return;

        jQuery(this).toggleClass('select');
    });

    //редирект при изменении количества игроков на странице
    jQuery('.js-count-select').change(function()
    {
        location = jQuery(this).val();
    });

/**страница игрока**********************************************************************/

    //меню по графикам игрока
    jQuery('.js-graph-menu-player li').click(function()
    {
        loadAndDrawPlayerGraph(jQuery(this));
    });
        
    //добавление игрока в мониторинг
    jQuery(".js-monitor-add-player").live('click', function()
    {
        var container = jQuery(".js-monitor-player");
        var result = jQuery(".js-ajax-result");   
        var idP = jQuery(this).attr('idPlayer');

        result.html(loadImage);

        jQuery.post( '/ajax/monitoradd/',
            {
                'idP': idP,
                'csrf': jQuery('#js-csrf-token').val(),
                'format': 'json'
            },
            function(data)
            {
                if( typeof data.error != 'undefined' )
                {
                    printMessage('error', data.error, result);
                }else{
                    printMessage('success', data.html, result);
                    container.remove();
                }
            },
            'json');
    });
    
    //удаление игрока из мониторинга
    jQuery(".js-monitor-del-player").live('click', function()
    {
        if( !confirm( 'Вы уверены, что хотите удалить игрока из мониторинга?' ) )
            return false;
        
        var container = jQuery(".js-monitor-player");
        var result = jQuery(".js-ajax-result");   
        var idP = jQuery(this).attr('idPlayer');

        result.html(loadImage);

        jQuery.post( '/ajax/monitordel/',
            {
                'idP': idP,
                'csrf': jQuery('#js-csrf-token').val(),
                'format': 'json'
            },
            function(data)
            {
                if( typeof data.error != 'undefined' )
                {
                    printMessage('error', data.error, result);
                }else{
                    printMessage('success', data.html, result);
                    container.remove();
                }
            },
            'json');
    });


}); //end of document.ready


//цвета для графиков
//@TODO Убрать зависимость
var colorRed = 'color:#e90000;';
var colorGreen = 'color: #7f881d';
var colorGray = 'color: #a5a5a5;';
var chart = null;
var chartColors =['#3d261f','#ff6f00','#136100','#050094'];




/**functions************************************************************************/

    /*
     * Весь функционал карты игроков
     */
    function Carousel(container, infobox, playerinfo, len, scroll, worldId, ring, maxCompl)
    {
        this.container = jQuery(container); // контейнер с табличкой
        this.infobox = jQuery(infobox);     // контейнер с информацией и лоадгифом
        this.playerbox = jQuery(playerinfo);// контейнер с подробной информацией по игроку

        this.len  = len;                    // количество выводимых комплов
        this.scroll  = scroll;              // количество скролимых коплексов

        this.first     = 1;                 // номер первого видимого комплекса
        this.last      = len;               // номер последнего видимого комплекса
        this.maxCompl  = maxCompl;          // максимальный номер комплекса на кольце
        this.idW       = worldId;           // id мира
        this.ring      = ring;              // id кольца

        //вкл/выкл картинки загрузки в инфобоксе
        this.loadGif = function(bool)
        {
            this.infobox.html( (bool == true) ? loadImage : '');
        }

        //вывести информацию в инфобокс
        this.addInfo = function(str)
        {
            this.infobox.html( str );
        }

        //загружаем и выводим данные
        this.draw = function()
        {
            this.loadGif(true);

            var tmp = this;
            //запрос данных для карусели
            jQuery.post('/ajax/map/',
            {
                'idW': this.idW,
                'ring': this.ring,
                'first': this.first,
                'last':  this.last,
                'format' : 'json'
            },
            function(data)
            {
                if (typeof data.error != 'undefined')
                {
                    tmp.addInfo(data.error);
                    return;
                }
                
                tmp.maxCompl  = parseInt( data.numMax );
                tmp.container.html( data.map );
                tmp.initEvents();
                tmp.loadGif( false );
            },
            'json');
        }

        //жмак "вправо"
        this.right = function()
        {
            if( (this.first + this.scroll) <= this.maxCompl )
            {
                this.first = this.first + this.scroll;
            }else{
                this.first = this.scroll - this.maxCompl + this.first;
            }

            if( (this.last  + this.scroll) <= this.maxCompl )
            {
                this.last = this.last + this.scroll;
            }else{
                this.last = this.scroll - this.maxCompl + this.last;
            }

            this.draw();
        }

        //жмак "влево"
        this.left = function()
        {
            if( (this.first - this.scroll) > 0 )
            {
                this.first = this.first - this.scroll;
            }else{
                this.first = this.maxCompl - this.scroll + this.first;
            }

            if( (this.last  - this.scroll) > 0 )
            {
                this.last  = this.last  - this.scroll;
            }else{
                this.last = this.maxCompl - this.scroll + this.last;
            }

            this.draw();
        }

        //смена кольца
        this.changeRing = function( idR )
        {
            if( !/^[0-9]+$/.test(idR) )
            {
                this.addInfo('Недопустимое значение номера кольца.');
                return;
            }

            this.ring  = parseInt(idR);
            this.first = 1;
            this.last  = this.len;

            this.draw();
        }

        //смена скорости прокрутки
        this.changeScroll = function( num )
        {
            if( !/^[0-9]+$/.test(num) )
            {
                this.addInfo('Недопустимое значение скроллинга');
                return;
            }
            this.scroll = parseInt(num);
        }

        //быстрая прокрутка к заданному комплексу
        this.goTo = function( num )
        {
            if( !/^[0-9]+$/.test(num) )
            {
                this.addInfo('Недопустимое значение номера комплекса');
                return;
            }

            num = parseInt(num);
            var inc = this.len - 1;

            this.first = (num >= this.maxCompl) ? this.maxCompl : num;

            if( (this.first  + inc) <= this.maxCompl )
            {
                this.last = this.first + inc;
            }else{
                this.last = inc  - this.maxCompl + this.first;
            }

            this.draw();
        }

        //инит эвентов
        this.initEvents = function()
        {
            //инит тултипсов
            jQuery('.js-map-icon').tooltip(
            {
                bodyHandler: function(){                    
                    return '<b>' + jQuery(this).attr("name") + '</b>: ' + jQuery(this).attr("value");
                },
                delay: 0,
                track: true,
                extraClass: "map-tooltip"
            });
            
            //инит подробной инфы
            var tmp = this;
            jQuery('.js-map-cell').click( function(e)
            {
                if( e.target.nodeName == 'A' )
                    return;

                tmp.getInfo( jQuery(this).attr('idP') );                
            });
        }

        //получаем подробную инфу
        this.getInfo = function( idP )
        {
            if( !/^[0-9]+$/.test(idP) )
            {
                this.addInfo('Недопустимый идентификатор игрока.');
                return;
            }

            this.loadGif(true);
            var tmp = this;

            //запрос данных по игроку
            jQuery.post('/ajax/playerinfo/',
            {
                'idP': idP,
                'format' : 'json'
            },
            function(data)
            {
                if (typeof data.error != 'undefined')
                {
                    tmp.addInfo(data.error);
                    return;
                }

                tmp.playerbox.html( data.html );
                tmp.playerbox.removeAttr('empty');
                tmp.playerbox.parents('div.hide:first').removeClass('hide');
                tmp.loadGif( false );
            },
            'json');
        }

        //установить новое активное окно подробной инфы
        this.setPlayerInfoBox = function( container )
        {
            this.playerbox = jQuery(container);
        }

    }



    /*
     * печатает в блок ошибку или успешное сообщение
     */
    function printMessage(type, message, container)
    {
        if(type == 'error')
        {
            container.addClass('color-red');
            container.removeClass('color-green');
            container.html(message);
        }else if( type == 'success' ){
            container.removeClass('color-red');
            container.addClass('color-green');
            container.html(message);
        }
    }



    /*
     * чекалка валидности поля формы
     * отмечает поле заранее определёнными классами
     * вернёт true если всё в порядке
     */
    function checkFormInput( valid, element )
    {
        var res = false;
        
        if( valid )
        {
            element.addClass('valid-form');
            element.removeClass('invalid-form');
            res = true;
        }else{
            element.removeClass('valid-form');
            element.addClass('invalid-form');
        }

        return res;
    }

    /*
     *вычисление сложности пароля
     * @return int 0+ степень сложности пароля
     */
    function complexityPass( value )
    {
        var res = Math.floor(value.length /10 );

        if( /[a-z]+/.test( value ) )
            res++;

        if( /[A-Z]+/.test( value ) )
            res++;

        if( /[0-9]+/.test( value ) )
            res++;

        if( /[!@#$%^&*()_+=-]+/.test( value ) )
            res++;

        return res;
    }

    /*
     * рисуем слайдер
     */
    function drawSlider(node)
{
    var name = jQuery(node).attr('name');
    var nodeMin = jQuery('#'+name+'_min');
    var nodeMax = jQuery('#'+name+'_max');
    var max = parseInt(jQuery(node).attr('max'));
    var minVal = parseInt(nodeMin.val());
    var maxVal = parseInt(nodeMax.val());

    //console.log(node,name,max,minVal, maxVal);

    jQuery(node).slider(
    {
        range: true,
        min: 0,
        step: 1,
        max: max,
        values: [ minVal, maxVal ],
        slide: function( event, ui )
        {
            nodeMin.val( parseInt(ui.values[0]) );
            nodeMax.val( parseInt(ui.values[1]) );
        }
    });
}

    /*
     *валидация полей формы обратной связи
     */
    function formValidate()
{
    var valid = true;

    //проверка контактов
    if( !/^[\w\s\-\+@\.\,А-ЯЁа-яё]{5,150}$/.test( jQuery("#js-form [name=contact]").val() ) )
    {
        jQuery("#js-form [name=contact]").addClass('invalid-form');
        jQuery("#js-form [name=contact]").removeClass('valid-form');
        valid = false;
    }else{
        jQuery("#js-form [name=contact]").addClass('valid-form');
        jQuery("#js-form [name=contact]").removeClass('invalid-form');
    }
    //проверка текста
    if( jQuery("#js-form [name=text]").val().length < 10 )
    {
        jQuery("#js-form [name=text]").addClass('invalid-form');
        jQuery("#js-form [name=text]").removeClass('valid-form');
        valid = false;
    }else{
        jQuery("#js-form [name=text]").addClass('valid-form');
        jQuery("#js-form [name=text]").removeClass('invalid-form');
    }
        
    //проверка на спам
    if( is_spam == 'true' )
    {
        //jQuery(".js-form-button").attr("disabled",true);
        jQuery(".js-form-result").text('С вашего IP уже отправлялось сообщение в течении последних 10-ти минут.');
        valid = false;
    }

    return valid;
}

    /*
     * открываем/закрываем новость и меняем цвет заголовка
     */
    function toggleNews(node, action)
{
    if(action == 'toggle')
    {
        jQuery(node).toggleClass('color-logo');
        jQuery(node).toggleClass('bold');
        jQuery(node).toggleClass('pseudo');
        jQuery(node).parent().children('p').slideToggle("normal");
    }else if(action == 'open'){
        jQuery(node).removeClass('pseudo');
        jQuery(node).addClass('color-logo bold');
        jQuery(node).parent().children('p').slideDown("normal");
    }else if(action == 'close'){
        jQuery(node).addClass('pseudo');
        jQuery(node).removeClass('color-logo bold');
        jQuery(node).parent().children('p').slideUp("normal");
    }
}

    /*
     * рисуем column chart
     */
    function drawColumnGraph(divId, title, dateFormat, series, colors, legend)
    {
        var zoom = (dateFormat == '%m.%Y') ? 30 : 7;
        var options = {
            chart:{
                renderTo: divId,
                zoomType: 'xy',
                margin: [30, 10, 30, 40],
                defaultSeriesType: 'column'
            },
            credits:{
                enabled: false
            },
            title:{
                style: {
                    color: '#636363'
                },
                text: title
            },
            colors: colors,
            xAxis:{
                type: 'datetime',
                gridLineWidth: 1,
                maxZoom: zoom * 24 * 3600000,
                lineColor: '#000'
            },
            yAxis:{
                allowDecimals: false,
                min: 0,
                title:{
                    text: null
                },
                labels: {
                    style: {
                        fontSize :'12px'
                    }
                }
            },
            legend:{
                enabled: legend,
                style:{
                    left: '70px',
                    bottom: 'auto',
                    right: 'auto',
                    top: '35px'
                },
                backgroundColor: '#FFFFFF',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip:{
                formatter: function()
                {
                    return '<b>' + Highcharts.dateFormat(dateFormat, this.x) + '</b><br>' + this.series.name + ': ' + this.y;
                }},
            series: series,
            plotOptions: {
                column:{
                    pointPadding: 0,
                    minPointLength: 5
                }/*,
                series: {
                    stacking: 'normal'
                }*/
            }
        };

        chart = new Highcharts.Chart(options);
    }

    /*
     * рисуем zoomable график из линий
     * @var reduce = [0-10] (если 2 -  кк или *1000000)
     */
    function drawStatGraphLine(divId, title, dateFormat, series, reduce, colors, legend, maxzoom, deltaHash )
    {
        var reduceStr = (reduce > 0) ? '\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a'.substr(0, reduce) : '';
        var reduceTtl = (reduce > 0) ? ' ('+reduceStr+')' : '';

        var options = {
            chart: {
                renderTo: divId,
                zoomType: 'xy',
                margin: [30, 10, 60, 60],
                defaultSeriesType: 'line'
            },
            title: {
                style: {
                    color: '#636363'
                },
                text: title + reduceTtl
            },
            legend:{
                enabled: legend
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: maxzoom * 24 * 3600000, // максимальный зум - неделя
                title: {
                    text: null
                }
            },
            yAxis: {
                labels: {
                    style: {
                        fontSize :'10px'
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 0.5,
                title: {
                    text: null
                },
                startOnTick: false,
                showFirstLabel: false
            },
            tooltip: {
                formatter: function()
                {
                    var delta = '';
                    if( typeof deltaHash[ this.series.index +'_'+ this.x] != 'undefined' )
                    {
                        var value = parseInt(deltaHash[ this.series.index +'_'+ this.x]);
                        if ( value > 0 )
                            delta = '<br/><span style="' + colorGreen + '">+' + value + '</span>';
                        else if ( value < 0 )
                            delta = '<br/><span style="' + colorRed + '">' + value + '</span>';
                        else
                            delta = '<br/><span style="' + colorGray + '">Нет изменений</span>';
                    }
                    
                    return '<b>' + Highcharts.dateFormat(dateFormat, this.x) + '</b><br>' + this.series.name + ' : '+ this.y + reduceStr + delta;
                }
            },
            colors: colors,
            plotOptions: {
                lineWidth: 1,
                shadow: false,
                series:{
                    marker: {
                        symbol:'circle',
                        radius: 2
                    }
                },
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            },
            series: series
        };

        chart = new Highcharts.Chart(options);
    }

    /*
     * рисуем zoomable граффик с закрашенными площадями
     * @var reduce = [0-10] (если 2 -  кк или *1000000)
     */
    function drawStatGraphFill(divId, title, dateFormat, series, reduce, colors, legend, maxzoom, deltaHash )
    {        
        var reduceStr = (reduce > 0) ? '\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a\u043a'.substr(0, reduce) : '';
        var reduceTtl = (reduce > 0) ? ' ('+reduceStr+')' : '';

        var options = {
            chart: {
                renderTo: divId,
                margin: [30, 10, 60, 60],
                zoomType: 'xy',
                defaultSeriesType: 'area'
            },
            title: {
                style: {
                    color: '#636363'
                },
                text: title + reduceTtl
            },
            legend:{
                enabled: legend
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: maxzoom * 24 * 3600000, // максимальный зум
                title: {
                    text: null
                }
            },
            yAxis: {
                labels: {
                    style: {
                        fontSize : '10px'
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 1,
                title: {
                    text: null
                },
                startOnTick: false,
                showFirstLabel: false
            },
            tooltip: {
                formatter: function()
                {
                    var delta = '';
                    if( typeof deltaHash != 'undefined' && typeof deltaHash[ this.series.index +'_'+ this.x] != 'undefined' )
                    {
                        var value = parseInt(deltaHash[ this.series.index +'_'+ this.x]);
                        if ( value > 0 )
                            delta = '<br/><span style="' + colorGreen + '">+' + value + '</span>';
                        else if ( value < 0 )
                            delta = '<br/><span style="' + colorRed + '">' + value + '</span>';
                    }
                    return '<b>' + Highcharts.dateFormat(dateFormat, this.x) + '</b><br>' + this.series.name + ' : '+ this.y + reduceStr + delta;
                }
            },
            colors: colors,
            plotOptions: {
                area: {
                    fillOpacity: .50,
                    lineWidth: 1,
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                radius: 4
                            }
                        }
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                }
            },
            series: series
        };

        chart = new Highcharts.Chart(options);
    }

    /*
     * живой график на главной странице
     * @var lastClassic (int) последний замер класики
     * @var lastUnlim (int) последний замер анлима
     */
    function loadAndDrawLiveGraph()
    {
        var lastClassic = jQuery('#graph-container').attr('lastClassic');
        var lastUnlim = jQuery('#graph-container').attr('lastUnlim');
        
        var cyrTime = (new Date()).getTime()+10800000;
        
        var addOnline = function(chrt){
            jQuery.post(
                '/ajax/online/',
                {'format': 'json'},
                function(data)
                {
                    var time = (new Date()).getTime()+10800000;
                    chrt.series[0].addPoint([time ,data.classic], true, true);
                    chrt.series[1].addPoint([time ,data.unlim], true, true);
                }
            ,'json');
        }
        
        var options = {
            chart: {
                renderTo: 'graph-container',
                defaultSeriesType: 'spline',
                margin: [20, 10, 15, 50],
                width: 500,
                height: 200,
                events: {
                    load: function() {
                        var chrt = this;
                        addOnline(chrt);
                        setInterval( function(){
                            addOnline(chrt);
                        }, 10000);
                    }
                }
            },
            title: {
                style: {
                    color: '#636363'
                },
                floating: true,
                align: 'left',
                x: 100,
                y: 5,
                text: 'Игроков в игре'
            },
            credits:{
               enabled: false
            },
            colors: ['#454293','#af345a'],
            plotOptions: {
                spline: {
                    duration: 4000,
                    dashStyle: 'dot',
                    lineWidth: 1
                }
            },
            xAxis: {
               type: 'datetime',
               tickPixelInterval: 100
            },
            yAxis: {
               allowDecimals: false,
               minorTickInterval: 'auto',
               lineColor: '#000',
               lineWidth: 1,
               title: {
                  text: null
               },
               labels: {
                   style: {
                       fontSize :'12px'
                   }
               }
            },
            tooltip: {
               formatter: function() {
                         return Highcharts.dateFormat('%H:%M:%S', this.x) +' - <b>'+this.y+'</b> ';
               }
            },
            legend:{
                enabled: true,
                style:{
                    left: 'auto',
                    bottom: 'auto',
                    right: '60px',
                    top: '-8px'
                },
                backgroundColor: '#FFFFFF',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            exporting: {
               enabled: false
            },
            series:  [
                {
                    name: 'Classic',
                    data: [
                        [ cyrTime-60000 ,lastClassic],
                        [ cyrTime-50000 ,lastClassic],
                        [ cyrTime-40000 ,lastClassic],
                        [ cyrTime-30000 ,lastClassic],
                        [ cyrTime-20000 ,lastClassic],
                        [ cyrTime-10000 ,lastClassic]
                    ]
                },{
                    name: 'Unlim',
                    data: [
                        [ cyrTime-60000 ,lastUnlim],
                        [ cyrTime-50000 ,lastUnlim],
                        [ cyrTime-40000 ,lastUnlim],
                        [ cyrTime-30000 ,lastUnlim],
                        [ cyrTime-20000 ,lastUnlim],
                        [ cyrTime-10000 ,lastUnlim]
                    ]/*,
                    visible: false*/
                }
            ]
        };

        chart = new Highcharts.Chart(options);
    }
    

    /*
     * создаём хеш таблицу из массива данных
     */
    function makeDeltaHash(dataArr)
    {
        var out = {};
        for( var key in dataArr )
        {
            out[dataArr[key]['ser'] +"_"+ dataArr[key]['date']] = dataArr[key]['val'];
        }
        return out;
    }



    /*
     * грузит и рисует график онлайна
     */
    function loadAndDrawOnlineGraph(target)
    {
        if( target.attr('enable') == 1 )
            return;

        var selectClass = jQuery('.js-graph-menu-online').attr('selectclass');

        jQuery('.js-graph-menu-online li').removeClass(selectClass);
        target.addClass(selectClass);

        jQuery('.js-graph-menu-online li').attr('enable',0);
        target.attr('enable',1);

        var container = jQuery('#graph-container');

        printGraphLoad(container);

        jQuery.post(
            '/ajax/graphonline/',
            {
                'format': 'json',
                'type': target.attr('graph'),
                'idV' : target.parent('ul').attr('idVersion')
            },
            function(res)
            {
                if( typeof res.error != 'undefined' )
                {
                    printGraphError(container, res.error );
                }else{
                    container.html();
                    
                    if( res.series.length == 1)
                        drawHourGraphOnline(res.series, target.parent('ul').attr('version'));
                    else
                        drawDayGraphOnline(res.series, target.parent('ul').attr('version'));
                }
            }
            ,'json');
    }

    /*
     * грузит и рисует график игрока
     */
    function loadAndDrawPlayerGraph(target)
    {
        if( target.attr('enable') == 1 )
            return;

        var selectClass = jQuery('.js-graph-menu-player').attr('selectclass');
        var type = target.attr('graph');

        jQuery('.js-graph-menu-player li').removeClass(selectClass);
        target.addClass(selectClass);

        jQuery('.js-graph-menu-player li').attr('enable',0);
        target.attr('enable',1);

        var container = jQuery('#graph-container');

        printGraphLoad(container);

        jQuery.post(
        '/ajax/graphplayer/',
        {
            'format': 'json',
            'type': type,
            'idP' : parseInt( container.attr('iditem') )
        },
        function(res)
        {
            if( typeof res.error != 'undefined' )
            {
                printGraphError(container, res.error );
            }else{
                container.html();

                if(!!res.url)
                    container.html('<img src='+res.url+' alt="График РА игрока с dshelp.info" />');
                else if(res.series.length == 1)
                    drawSingleGraphPlayer( res.series );
                else
                    drawSumGraphPlayer( res.series, res.borders );                
            }
        }
        ,'json');
    }


    //выводит ошибку графика в контейнер
    function printGraphError(container, text)
    {
        container.html('<div class="mrg-top-34 mrg-bottom-44 mrg-left-70"><img src="/img/eye_big.gif" alt="глазик">'+text+'</div>');
    }

    //выводит load.gif графика
    function printGraphLoad(container)
    {
        container.html(loadImage);
    }


    //подготовка данных для графика
    function _prepareGraphData( data )
    {
        var parseDate = function ( str )
        {
            var tmp = str.split('.');
            if( tmp.length == 3){ //дни
                tmp[1] = tmp[1]-1;
                return Date.UTC( tmp[2], tmp[1], tmp[0], 00, 00);
            }else if( tmp.length == 4){ // +часы
                tmp[2] = tmp[2]-1;
                return Date.UTC( tmp[3], tmp[2], tmp[1], tmp[0], 00);
            }else{ // +минуты
                tmp[3] = tmp[3]-1;
                return Date.UTC( tmp[4], tmp[3], tmp[2],  tmp[1], tmp[0] );
            }
        }

        for( var i in data )
        {
            for( var j in data[i].data )
            {
                data[i].data[j][0] = parseDate(data[i].data[j][0]);
                data[i].data[j][1] = Math.round(parseFloat(data[i].data[j][1]) * 100) / 100;
            }
        }
    }

    //вычисляет индексный словарь дельт значений графика
    function _getGraphDelta( data )
    {
        var out = {};

        for( var i in data )
            for( var j = 1; j < data[i].data.length; j++ )
                out[i + '_' + data[i].data[j][0]] = Math.round(parseFloat(data[i].data[j][1] - data[i].data[j-1][1]) * 100) / 100;

        return out;
    }

    //вычисляет индексный словарь исходных значений графика (для нормированных тултипсов)
    function _getGraphSource( data )
    {
        var out = {};

        for( var i in data )
        {
            for( var j in data[i].data )
                out[i + '_' + data[i].data[j][0]] = data[i].data[j][1];
        }

        return out;
    }


    //рисуем сводный график игрока
    function drawSumGraphPlayer(series, borders)
    {
        for(i in borders)
            borders[i] = parseFloat(borders[i]);

        _prepareGraphData( series );
        var delta = _getGraphDelta( series );
        var source = _getGraphSource( series )

        //нормирование серий
        for( var i in series )
        {
            for( var j in series[i].data )
            {
                if(borders[series[i].name + '_max'] == 0.0 || (borders[series[i].realname + '_min'] == borders[series[i].realname + '_max']) )
                    series[i].data[j][1] = 0.0;
                else
                    series[i].data[j][1] = ( (series[i].data[j][1] - borders[series[i].realname + '_min']) / (borders[series[i].realname + '_max'] - borders[series[i].realname + '_min']) ) * 100;                
            }
        }

        var options = {
            chart: {
                renderTo: 'graph-container',
                zoomType: 'xy',
                margin: [10, 10, 80, 60],
                defaultSeriesType: 'line'
            },
            title: {
                text: ''
            },
            legend:{
                enabled: true
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: 3 * 24 * 3600000, 
                title: {
                    text: null
                }
            },
            yAxis: {
                min: -5,
                max: 105,
                labels: {
                    style: {
                        fontSize :'10px'                       
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 0.5,
                title: {
                    text: 'проценты',
                    style: {
                        color: '#6e0022',
                        fontWeight: 'normal'                        
                    },
                    align: 'high'
                },
                startOnTick: false,
                showFirstLabel: false
            },
            tooltip: {
                crosshairs: false,
                shared: false,
                formatter: function()
                {
                    return '<b>' +
                        Highcharts.dateFormat('%H:00 %d.%m.%Y', this.x) +
                        '</b>' +
                        '<br><span style="color:' + this.series.color + ';">' +
                        this.series.name +
                        ' : <b>' +
                        numFormat(source[this.series.index +'_'+ this.x]) +
                        '</b> ' +
                        getDelta(delta, this.series.index +'_'+ this.x);
                }
            },
            plotOptions: {
                lineWidth: 1,
                shadow: false,
                series:{
                    marker: {
                        symbol:'circle',
                        radius: 2
                    }
                },
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            },
            series: series
        };

        
       chart = new Highcharts.Chart(options);
    }

    //рисуем одиночный график игрока
    function drawSingleGraphPlayer(series)
    {
        _prepareGraphData( series );

        var delta = _getGraphDelta( series );
        
        var reversed = (series[0].realname == 'mesto');

        var options = {
            chart: {
                renderTo: 'graph-container',
                zoomType: 'xy',
                margin: [10, 10, 20, 60],
                defaultSeriesType: 'line'
            },
            title: {
                text: ''
            },
            legend:{
                enabled: false
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: 3 * 24 * 3600000,
                title: {
                    text: null
                }
            },
            yAxis: {
                labels: {
                    style: {
                        fontSize :'10px'
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 0.5,
                title: {
                    text: null
                },
                startOnTick: false,
                showFirstLabel: false,
                reversed: reversed
            },
            tooltip: {
                formatter: function()
                {
                    return '<b>' + Highcharts.dateFormat('%H:00 %d.%m.%Y', this.x) + '</b><br>' +
                        '<span style="color:' + this.series.color + ';">' + this.series.name + '</span> : ' +
                        '<b>' + numFormat(this.y) + '</b> ' +
                        getDelta(delta, this.series.index +'_'+ this.x, reversed);
                }
            },
            plotOptions: {
                lineWidth: 1,
                shadow: false,
                series:{
                    marker: {
                        symbol:'circle',
                        radius: 2
                    }
                },
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            },
            series: series
        };

        chart = new Highcharts.Chart(options);
    }

    //рисуем почасовой график онлайна
    function drawHourGraphOnline(series, version)
    {
        _prepareGraphData( series );

        var options = {
            chart: {
                renderTo: 'graph-container',
                margin: [30, 10, 60, 60],
                zoomType: 'x',
                defaultSeriesType: 'area'
            },
            title: {
                style: {
                    color: '#636363'
                },
                text: 'Количество игроков online по часам (' + version + ')'
            },
            legend:{
                enabled: false
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: 1 * 24 * 3600000, // максимальный зум
                title: {
                    text: null
                }
            },
            yAxis: {
                labels: {
                    style: {
                        fontSize : '10px'
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 1,
                title: {
                    text: null
                },
                startOnTick: false,
                showFirstLabel: false
            },
            tooltip: {
                formatter: function()
                {                    
                      return '<b>' + Highcharts.dateFormat('%H:00 %d.%m.%Y', this.x) + '</b><br>' +
                              this.series.name + ': ' + '<b>' + numFormat(this.y) + '</b>';
                }
            },
            colors: chartColors,
            plotOptions: {
                area: {
                    fillOpacity: .50,
                    lineWidth: 1,
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                radius: 4
                            }
                        }
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                }
            },
            series: series
        };

        chart = new Highcharts.Chart(options);
    }

    //рисуем график онлайна за всё время (с агрегацией)
    function drawDayGraphOnline(series, version)
    {
        _prepareGraphData( series );
        
        var options = {
            chart: {
                renderTo: 'graph-container',
                zoomType: 'xy',
                margin: [30, 10, 60, 60],
                defaultSeriesType: 'line'
            },
            title: {
                style: {
                    color: '#636363'
                },
                text: 'Количество игроков online по дням (' + version + ')'
            },
            legend:{
                enabled: true
            },
            credits:{
                enabled: false
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                type: 'datetime',
                maxZoom: 7 * 24 * 3600000, // максимальный зум - неделя
                title: {
                    text: null
                }
            },
            yAxis: {
                labels: {
                    style: {
                        fontSize :'10px'
                    }
                },
                allowDecimals: false,
                minorTickInterval: 'auto',
                lineColor: '#000',
                lineWidth: 0.5,
                title: {
                    text: null
                },
                startOnTick: false,
                showFirstLabel: false
            },
            tooltip: {
                formatter: function()
                {
                    return '<b>' + Highcharts.dateFormat('%d.%m.%Y', this.x) + '</b><br>' +
                            this.series.name + ': ' + '<b>' + numFormat(this.y) + '</b>';
                }
            },
            colors: chartColors,
            plotOptions: {
                lineWidth: 1,
                shadow: false,
                series:{
                    marker: {
                        symbol:'circle',
                        radius: 2
                    }
                },
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            },
            series: series
        };

        chart = new Highcharts.Chart(options);
    }

    //форматирует большие числа в нормальный вид
    function numFormat(number)
    {
        return number.toString().reverse().replace(/(\d{3})(?=\d)/g,'$1`').reverse()

    }

    //возвращает форматированную дельту параметра для графиков из словаря
    function getDelta( hash, index, reversed )
    {
        var delta = '';
        if( typeof reversed === 'undefined' )
            reversed = false;
        
        if( typeof hash[index] === 'undefined' || hash[index] === 0 )
        {
            delta = '(<span style="' + colorGray + '">Без изменений</span>)';
        }else{
            var color = ( reversed === (hash[index] > 0) ) ? colorRed : colorGreen;
            if(hash[index] > 0)
            {
                delta = '(<span style="' + color + '">+' + numFormat(hash[index]) + '</span>)';
            }else if(hash[index] < 0){                
                delta = '(<span style="' + color + '">' + numFormat(hash[index]) + '</span>)';
            }
        }
        return delta;
    }


    String.prototype.reverse=function(){return this.split("").reverse().join("");}
